function [ret] = FcaHHGHK2(UU,Cai,k,Ca_ref,Up,Uca,Omega,mm)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{ca} note that Phi_{ca}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

idx2=find(abs(UU)>=1e-6);
idx=find(abs(UU)<1e-6);

ret = zeros(size(UU));

if (isempty(nonzeros(idx2))==0)

     ret(idx2) = -k./(k+Ca_ref.*Cai(idx2)).*(exp(Omega*Up*(UU(idx2)-Uca))-1).*mm(idx2).^2.*UU(idx2)./(exp(Omega*Up*UU(idx2))-1);
     ret(idx) = -k./(k+Ca_ref.*Cai(idx)).*(exp(Omega*Up*(UU(idx)-Uca))-1).*mm(idx).^2/(Up*Omega);

else

     ret(idx) = -k./(k+Ca_ref.*Cai(idx)).*(exp(Omega*Up*(UU(idx)-Uca))-1).*mm(idx).^2/(Up*Omega);

end;