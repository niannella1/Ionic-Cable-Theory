Xpos=100e-4/lambda;
%Xpos=Xi_k(pp);

f1_na=zeros(size(T));
f2_na=zeros(size(T));
f3_na=zeros(size(T));
f4_na=zeros(size(T));

f1_k=zeros(size(T));
f2_k=zeros(size(T));
f3_k=zeros(size(T));
f4_k=zeros(size(T));

for ii=1:HotSpotNum_na
    zz1=fft(G(Xpos,Xi_na(ii),T));
    UU=Phi(Xi_na(ii),T,u0,up);
    
    zz1_na=fft(Fna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:)));
    zz_na=dT*real(ifft(zz1.*zz1_na));
    f1_na=f1_na+Gna(ii)*Rm/lambda*zz_na;

    zz2_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi1(ii,:));
    zz2=dT*real(ifft(zz1.*zz2_na));
    f2_na=f2_na+Gna(ii)*Rm/lambda*zz2;

    zz3_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi2(ii,:) ...
        +1/2*DDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).^2);
    zz3=dT*real(ifft(zz1.*zz3_na));
    f3_na=f3_na+Gna(ii)*Rm/lambda*zz3;

    zz4_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi3(ii,:)...
        +DDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).*Phi2(ii,:)...
        +1/6*DDDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:),d3mm_dv3(ii,:),d3hh_dv3(ii,:)).*Phi1(ii,:).^3);
    zz4=dT*real(ifft(zz1.*zz4_na));
    f4_na=f4_na+Gna(ii)*Rm/lambda*zz4;
end;


for pp=1:HotSpotNum_k
    zz1=fft(G(Xpos,Xi_k(pp),T));
    UU=Phi(Xi_k(pp),T,u0,up);
    
    zz1_k=fft(Fk(UU+Er/up,up,Phi_k,Omega,nn(pp,:)));
    zz_k=dT*real(ifft(zz1.*zz1_k));
    f1_k=f1_k+Gk(pp)*(Rm/lambda)*zz_k;
    
    zz2_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi1(ii+pp,:));
    zz2_k=dT*real(ifft(zz1.*zz2_kk));
    f2_k=f2_k+Gk(pp)*Rm/lambda*zz2_k;
    
    zz3_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi2(ii+pp,:) ...
        +1/2*DDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).^2);
    zz3_k=dT*real(ifft(zz1.*zz3_kk));
    f3_k=f3_k+Gk(pp)*Rm/lambda*zz3_k;
  
    zz4_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi3(ii+pp,:)...
        +DDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).*Phi2(ii+pp,:)...
        +1/6*DDDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:),d3nn_dv3(pp,:)).*Phi1(ii+pp,:).^3);
    zz4_k=dT*real(ifft(zz1.*zz4_kk));
    f4_k=f4_k+Gk(pp)*Rm/lambda*zz4_k;
    
end;


% plot(T,f1_na,T,f2_na,'r',T,f3_na,'g',T,f4_na,'c');
% figure;
% plot(T,f1_k,T,f2_k,'c',T,f3_k,'g',T,f4_k,'r');
% figure;
% plot(T,up*(Phi(Xpos,T,u0,up)+f1_na+f2_na+f3_na+f4_na),'g',T,up*Phi(Xpos,T,u0,up),'r');grid;
% figure;
% plot(T,up*(Phi(Xpos,T,u0,up)+f1_k+f2_k+f3_k+f4_k),'b',T,up*Phi(Xpos,T,u0,up),'r');grid;
% figure;
% plot(T,up*(f1_na+f2_na+f3_na+f4_na+f1_k+f2_k+f3_k+f4_k),'b',T,up*Phi(Xpos,T,u0,up),'r');grid;
% figure;
% epsilon=0.01;
% plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon^4*f4_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k+epsilon^4*f4_k),'b',T,up*(Phi(Xpos,T,u0,up)+f1_na),'y',T,up*f1_na,'c',T,up*f1_k,'g',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
epsilon=10;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon*f1_k),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;
figure;
epsilon=0.01;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon*f1_k+epsilon^2*f2_k),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;
figure;
epsilon=0.01;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;
figure;
epsilon=0.06;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon^4*f4_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k+epsilon^4*f4_k),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;

%integrand1(s,t,ss,x,xi,u0,up,Una,Omega,mm,hh);
