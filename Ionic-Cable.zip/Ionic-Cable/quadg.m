function int = quadg(fun,xlow,xhigh,tol,trace,varargin)
%usage:  int = quadg('Fun',xlow,xhigh)
%or
%	 int = quadg('Fun',xlow,xhigh,tol)
%or
%	 int = quadg('Fun',xlow,xhigh,tol,trace)
%or
%	 int = quadg('Fun',xlow,xhigh,[],[],p1,...)
%or
%	 int = quadg('Fun',xlow,xhigh,tol,[],p1,...)
%or
%	 int = quadg('Fun',xlow,xhigh,tol,trace,p1,...)
%
% This function works just like QUAD or QUAD8 but uses a Gaussian quadrature
% integration scheme.  Use this routine instead of QUAD or QUAD8:
%
%   if higher accuracy is desired (this works best if the function,
%	    'Fun', can be approximated by a power series)
%   or if many similar integrations are going to be done (I think less
%	    function evaluations will typically be done, but the
%	    integration points and the weights must be calculated.
%	    These are saved between integrations so when QUADG
%	    is called again, the points and weights are all ready
%	    known.)
%   or if the function evaluations are time consuming.
%
% Note that if there are discontinuities the integral should be broken up
% into separate pieces.  And if there are singularities, a more
% appropriate integration quadrature should be used (such as the
% Gauss-Chebyshev).


if nargin<4
  tol=1e-3;
elseif isempty(tol),
  tol=1e-3;
end
if nargin<5
  trace=0;
elseif isempty(trace),
  trace=0;
else,
  trace=1;
end

%setup mapping parameters
jacob=(xhigh-xlow)/2;

%generate the first two sets of integration points and weights
[b2,w2]=grule(2);

x=(b2+1)*jacob+xlow;
y=feval(fun,x,varargin{:});
int_old=sum(w2(:).*y(:))*jacob;
if trace==1,
  x_trace=x(:);
  y_trace=y(:);
end

err=1;
int=int_old;
i=0;
converge='n';
%for i=1:10,
while ((err>abs(tol*int))|(err>abs(tol)^2)),
%for i=1:7,
  i=i+1;
  gnum=2^(i+1);
  [b_gnum,w_gnum]=grule(gnum);
  x=(b_gnum+1)*jacob+xlow;
  y=feval(fun,x,varargin{:});
  int=sum(w_gnum(:).*y(:))*jacob;

  if trace==1,
    x_trace=[x_trace;x(:)];
    y_trace=[y_trace;y(:)];
  end
  if abs(int_old-int) < abs(tol*int) | abs(int_old-int) < abs(tol)^2,
    converge='y';
    break;
  end
  err=abs(int-int_old);
  int_old=int;
end

if converge=='n',
  disp('Integral did not converge--singularity likely')
end

if trace==1,
  plot(x_trace,y_trace,'+')
end

%gnum,i,length(x_trace)
