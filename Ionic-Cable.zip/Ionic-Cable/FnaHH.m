function [ret] = FnaHH(UU,Up,Una,mm,hh)

% Omega - factor scaling U_{peak}
% Una - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = mm.^3.*hh.*(Una-UU);