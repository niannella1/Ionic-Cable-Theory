function [ret] = DDFnaHH(UU,Up,Una,mm,hh,Dmm_dUU,Dhh_dUU,D2mm_dUU2,D2hh_dUU2)

% Omega - factor scaling U_{peak}
% Una - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = 2*(-mm.^3.*Dhh_dUU-3*hh.*mm.^2.*Dmm_dUU)...
    +(Una-UU).*(6*mm.^2.*Dhh_dUU.*Dmm_dUU+mm.^3.*D2hh_dUU2+hh.*(6*mm.*Dmm_dUU.^2+3*mm.^2.*D2mm_dUU2));
