function [ret] = Phi3(t,x,u0,up)

ret = Phi(x,t,u0,up);