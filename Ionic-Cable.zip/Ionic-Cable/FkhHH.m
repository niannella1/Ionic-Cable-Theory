function [ret] = FkhHH(UU,Up,Uk,mm)

% Uk - refers to Phi_{k} note that Phi_{k}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = mm.*(Uk-UU);
