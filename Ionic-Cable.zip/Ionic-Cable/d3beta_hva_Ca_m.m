function [ret] = d3beta_hva_Ca_m(UU,Er,a2,b2,c2,u0,up)

idx=find(abs((UU*up+Er-b2)/c2)<1e-6);
idx2=find(abs((UU*up+Er-b2)/c2)>=1e-6);

ret = zeros(size(UU));

if (isempty(nonzeros(idx2))==0)

    ret(idx2) = -3*a2*(up^3/c2^2)*(...
        2*exp(2*(UU*up+Er-b2)/c2)./(1-exp((UU*up+Er-b2)/c2)).^3 ...
        +exp((UU*up+Er-b2)/c2)./(1-exp((UU*up+Er-b2)/c2)).^2)...
...
        -a2*(up^3/c2^3)*(UU*up+Er-b2).*(...
            6*exp(3*(UU*up+Er-b2)/c2)./(1-exp((UU*up+Er-b2)/c2)).^4 ...
            + 6*exp(2*(UU*up+Er-b2)/c2)./(1-exp((UU*up+Er-b2)/c2)).^3 ...
            + exp((UU*up+Er-b2)/c2)./(1-exp((UU*up+Er-b2)/c2)).^2);
    
else
    
    ret(idx) = 0;
    
end;

