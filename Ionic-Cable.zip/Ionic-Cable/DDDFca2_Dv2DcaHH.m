function [ret] = DDDFca2_Dv2DcaHH(UU,Up,Uca,mm,Dmm_dUU,Dhh_dCa,D2mm_dUU2,D2hh_dUUdCa,D3hh_dUU2dCa)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{na} note that Phi_{ca}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = 2*(-mm.^2.*D2hh_dUUdCa-2*mm.*Dmm_dUU.*Dhh_dCa)...
    +(Uca-UU).*(4*mm.*D2hh_dUUdCa.*Dmm_dUU+mm.^2.*D3hh_dUU2dCa+Dhh_dCa.*(2*Dmm_dUU.^2+2*mm.*D2mm_dUU2));
