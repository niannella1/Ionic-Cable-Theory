function [ret] = DFkca2(UU,Ca,Ca_ref,Up,Uk,Omega,mm_Kca,Dmm_Kca_dUU)

% Omega - factor scaling U_{peak}
% Uk - refers to Phi_{k} note that Phi_{k}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% Ca_ref - refers to a reference calcium concentration
% Ca - refers to the local calcium concentration
% UU - refers to Phi_0(x,t)

if (Ca>=Ca_ref) 

  ret = ((exp(Omega*Up*(UU-Uk))-1).*mm_Kca)./(exp(Omega*Up*UU)-1) ...
        +(exp(Omega*Up*(UU-Uk)).*mm_Kca.*Omega.*Up.*UU)./(exp(Omega*Up*UU)-1) ...
        -((exp(Omega*Up*(UU-Uk))-1).*exp(Omega*Up*UU).*mm_Kca.*Omega.*Up.*UU)./(exp(Omega*Up*UU)-1).^2 ...
        +2*((exp(Omega*Up*(UU-Uk))-1).*Dmm_Kca_dUU.*UU)./(exp(Omega*Up*UU)-1);
  
else

  ret = ((exp(Omega*Up*(UU-Uk))-1).*Ca.*mm_Kca)./(exp(Omega*Up*UU)-1) ...
        +(exp(Omega*Up*(UU-Uk)).*Ca.*mm_Kca.*Omega.*Up.*UU)./(exp(Omega*Up*UU)-1) ...
        -((exp(Omega*Up*(UU-Uk))-1).*exp(Omega*Up*UU).*Ca.*mm_Kca.*Omega.*Up.*UU)./(exp(Omega*Up*UU)-1).^2 ...
        +2*((exp(Omega*Up*(UU-Uk))-1).*Ca.*Dmm_Kca_dUU.*UU)./(exp(Omega*Up*UU)-1);

end;