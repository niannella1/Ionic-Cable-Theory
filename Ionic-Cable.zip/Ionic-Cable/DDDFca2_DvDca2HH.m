function [ret] = DDDFca2_DvDca2HH(UU,Up,Uca,mm,Dmm_dUU,D2hh_dCa2,D3hh_dUUdCa2)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{na} note that Phi_{ca}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = -mm.^2.*D2hh_dCa2+mm.^2.*D3hh_dUUdCa2.*(Uca-UU)+2*mm.*D2hh_dCa2.*Dmm_dUU.*(Uca-UU);