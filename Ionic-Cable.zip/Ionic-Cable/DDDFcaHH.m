function [ret] = DDDFcaHH(UU,Up,Uca,mm,Dmm_dUU,D2mm_dUU2,D3mm_dUU3)

% Omega - factor scaling U_{peak}
% Una - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = 2*mm.*D3mm_dUU3.*(Uca-UU) -6*Dmm_dUU.^2 -6*mm.*D2mm_dUU2 +6*Dmm_dUU.*D2mm_dUU2.*(Uca-UU);
