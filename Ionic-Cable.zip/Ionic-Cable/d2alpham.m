function [ret] = d2alpham(x,t,Er,a1,b1,c1,u0,up)

idx=find(abs((b1-Phi(x,t,u0,up)*up-Er)./c1)<1e-6);
idx2=find(abs((b1-Phi(x,t,u0,up)*up-Er)./c1)>=1e-6);

ret = zeros(size(t));

if (isempty(nonzeros(idx2))==0)

    ret(idx2) = -2*a1*(up^2/c1)*exp(-(Phi(x,t(idx2),u0,up)*up+Er-b1)/c1)./(1.0-exp(-(Phi(x,t(idx2),u0,up)*up+Er-b1)/c1)).^2 ...
       + a1*up^2/c1^2*(Phi(x,t(idx2),u0,up)*up+Er-b1).*(...
                        2*exp(-2*(Phi(x,t(idx2),u0,up)*up+Er-b1)/c1)./(1.0-exp(-(Phi(x,t(idx2),u0,up)*up+Er-b1)/c1)).^3 ...
                        + exp(-(Phi(x,t(idx2),u0,up)*up+Er-b1)/c1)./(1.0-exp(-(Phi(x,t(idx2),u0,up)*up+Er-b1)/c1)).^2);
    ret(idx) = a1*up^2/(6*c1);

else
    
    ret(idx) = a1*up^2/(6*c1);

end;