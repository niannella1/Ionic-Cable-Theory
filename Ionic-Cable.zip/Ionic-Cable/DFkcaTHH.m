function [ret] = DFkcaTHH(UU,Cai,Ca_ref,Ukca,mm,Dmm_dUU)

% Ukca - refers to Phi_{kca} note that Phi_{kca}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

idx2=find(Ca_ref.*Cai<0.002);
idx=find(Ca_ref.*Cai>=0.002);

ret = zeros(size(UU));

if (isempty(nonzeros(idx2))==0)

  ret(idx2) = Ca_ref*Cai(idx2)/0.002.*(-mm(idx2)+Dmm_dUU(idx2).*(Ukca-UU(idx2)));
  ret(idx) = -mm(idx)+Dmm_dUU(idx).*(Ukca-UU(idx));

else

  ret(idx) = -mm(idx)+Dmm_dUU(idx).*(Ukca-UU(idx));

end;