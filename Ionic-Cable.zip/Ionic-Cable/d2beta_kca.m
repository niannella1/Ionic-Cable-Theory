function [ret] = d2beta_kca(x,t,Er,a1,b1,c1,a2,b2,c2,u0,up)

idx=find(Phi(x,t,u0,up)*up>-10);
idx2=find(Phi(x,t,u0,up)*up<=-10);

ret = zeros(size(t));

if (isempty(nonzeros(idx2))==0)

    ret(idx2) = a2*(up/c2)^2*exp(-(Phi(x,t(idx2),u0,up)*up+Er+b2)/c2)-a1*up^2*(1/c1-1/c2)^2*exp((Phi(x,t(idx2),u0,up)*up+Er+b1)/c1-(Phi(x,t(idx2),u0,up)*up+Er+b2)/c2);

else

    ret(idx) = 0;

end;