function [ret] = d2alpha_hvam(x,t,Er,a1,b1,c1,u0,up)

ret = a1*2*(up/c1)^2*exp(-2*(Phi(x,t,u0,up)*up+Er-b1)/c1)./(1.0+exp(-(Phi(x,t,u0,up)*up+Er-b1)/c1)).^3 ...
        -a1*(up/c1)^2*exp(-(Phi(x,t,u0,up)*up+Er-b1)/c1)./(1.0+exp(-(Phi(x,t,u0,up)*up+Er-b1)/c1)).^2;
