clear; close all;

g1=10.0;
g2=0.0043;
g3=0.0025;
% Poznanski parameters
% a1=0.5;
% b1=-70;
% c1=0.00001;
% a2=0.05;
% b2=-70;
% c2=0.01;
% Er=-70;

% a1=0.36;
% b1=-92;
% c1=3;
% a2=0.4;
% b2=-83;
% c2=20;
% Er=-70;


% Mainen parameters
a1=0.182;
b1=-35;
c1=9;
a2=0.124;
b2=-35;
c2=9;
Er=-70;

% a3=0.1;
% b3=-60;
% c3=6;
% th1=10^3;
% Phi_na=135;
% u0=5.12;
% up=1;

a3=0.8;
b3=-70;
c3=10.0;
th1=10^3;
Phi_na=135;
u0=5.12;
up=88.38928681566553; %1;

mu0=0.0005;
Rm=40000;
Cm=1e-6;
tau=Rm*Cm*1000;

t=linspace(0,6,1000);
dt=t(2)-t(1);

plot(t,Phi(0,t,u0,up),'r',t,Phi(0.3,t,u0,up),'g',t,Phi(1,t,u0,up),'b');grid;title('V(x,t)')

figure;
plot(t,alpham(0,t,Er,a1,b1,c1,u0,up),'r',t,alpham(0.3,t,Er,a1,b1,c1,u0,up),'g',t,alpham(1,t,Er,a1,b1,c1,u0,up),'b');grid;title('\alpha_m(x,t)');


pos=0.0;
for i=1:length(t)
  zz=zeros(size(t,1),size(t,2)-i);
  Kjk(i,:) = [dt*(alpham(pos,t(1:i),Er,a1,b1,c1,u0,up)+betam(pos,t(1:i),Er,a2,b2,c2,u0,up)) zz];
end;

%psi0=alpham(pos,t,Er,a1,b1,c1,u0,up)';
psi0=tau*fm(pos,t,dt,Er,a1,b1,c1,u0,up)';

%mmu=psi0;

err=1;

figure;
j=-1;

%mmu=inv(eye(length(t))+tau*Kjk)*psi0;

mmu(1)=alpham(pos,t(1),Er,a1,b1,c1,u0,up)/(alpham(pos,t(1),Er,a1,b1,c1,u0,up)+betam(pos,t(1),Er,a1,b1,c1,u0,up));

while(err>1e-6)
    j=j+1;
    psi=mmu;
    
%    mmu=psi0-tau*Kjk*mmu;
  
    for i=2:length(t)
%          mmu(i)=psi0(i)-tau*Kjk(i,1:i)*mmu(1:i);
       mmu(i)=((psi0(i)+psi0(i-1))/2-tau/2*(Kjk(i-1,1:i-1)+Kjk(i,1:i-1))*mmu(1:i-1))./(1+tau/2*Kjk(i,i));
    end;

    err=sum(abs((mmu-psi)./mmu));
    
    plot(t,mmu);grid;title('\mu(x,t) via solving the integral equation');
    pause(0.0001);
    
end;  
    

pos=0;
 
figure;
plot(t,betam(0,t,Er,a2,b2,c2,u0,up),'r',t,betam(0.3,t,Er,a2,b2,c2,u0,up),'g',t,betam(1,t,Er,a2,b2,c2,u0,up),'b');grid;title('\beta_m(x,t)')

figure;
plot(t,alpham(0,t,Er,a1,b1,c1,u0,up)+betam(0,t,Er,a2,b2,c2,u0,up),'r',t,alpham(0.3,t,Er,a1,b1,c1,u0,up)+betam(0.3,t,Er,a2,b2,c2,u0,up),'g',t,alpham(1.0,t,Er,a1,b1,c1,u0,up)+betam(1,t,Er,a2,b2,c2,u0,up),'b');grid;title('\alpha_m(x,t)+\beta_m(x,t)');

figure;
plot(t,fm(0,t,dt,Er,a1,b1,c1,u0,up),'r',t,fm(0.3,t,dt,Er,a1,b1,c1,u0,up),'g',t,fm(1.0,t,dt,Er,a1,b1,c1,u0,up),'b');grid;title('f_m(x,t)')

figure;
plot(t,hm(0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'r',t,hm(0.3,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'g',t,hm(1.0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'b');grid;title('h_m(x,t)');

figure;
plot(t,gm(0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'r',t,gm(0.3,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'g',t,gm(1.0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'b');grid;title('g_m(x,t)');

figure;
plot(t,wm(0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'r',t,wm(0.3,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'g',t,wm(1.0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'b');grid;title('w_m(x,t)');

figure;
plot(t,rm(0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'r',t,rm(0.3,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'g',t,rm(1.0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'b');grid;title('r_m(x,t)');

figure;
plot(t,pm(0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'r',t,pm(0.3,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'g',t,pm(1.0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'b');grid;title('w_m(x,t)');

figure;
plot(t,qm(0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'r',t,qm(0.3,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'g',t,qm(1.0,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'b');grid;title('r_m(x,t)');


figure;
plot(t,mu(0,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'r',t,mu(0.3,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'g',t,mu(1.0,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'b');grid;title('\mu(x,t)')

ah0=a3*(1-mu0);

figure;
plot(t,alphah(0,t,a3,ah0,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'r',t,alphah(0.3,t,a3,ah0,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'g',t,alphah(1,t,a3,ah0,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'b');grid;title('\alpha_h(x,t)');

figure;
plot(t,betah(0,t,g1,g2,g3,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'r',t,betah(0.3,t,g1,g2,g3,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'g',t,betah(1,t,g1,g2,g3,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'b');grid;title('\beta_h(x,t)');

neta0=0.8249;

figure;
plot(t,neta(0,t,neta0,g1,g2,g3,a3,ah0,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'r',t,neta(0.3,t,neta0,g1,g2,g3,a3,ah0,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'g',t,neta(1,t,neta0,g1,g2,g3,a3,ah0,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up),'b');grid;title('\eta(x,t)');

y=alpham(pos,t,Er,a1,b1,c1,u0,up);
y2=betam(pos,t,Er,a1,b1,c1,u0,up);
vv=zeros(size(t));
neta_app=neta(pos,t,neta0,g1,g2,g3,a3,ah0,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up);
mu_app=mu(pos,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up);

vv(1)=y(1)/(y(1)+y2(1));
for i=2:length(t)
%    vv(i)=vv(i-1)+dt*tau*y(i-1)-dt*tau*(alpham(pos,t(i-1),Er,a1,b1,c1,u0,up)+betam(pos,t(i-1),Er,a2,b2,c2,u0,up))*vv(i-1);
   vv(i)=(vv(i-1)+dt/2*tau*(y(i-1)+y(i))-dt/2*tau*(alpham(pos,t(i-1),Er,a1,b1,c1,u0,up)+betam(pos,t(i-1),Er,a2,b2,c2,u0,up))*vv(i-1))/...
       (1+dt/2*tau*(alpham(pos,t(i),Er,a1,b1,c1,u0,up)+betam(pos,t(i),Er,a2,b2,c2,u0,up)));
end;

figure;
plot(t,vv);grid;title('\mu(x,t) via solving the ODE: v is given');

a3h = a3*(1-vv);
b3h = g1*vv.^3+3*g2*vv.^2.*(1-vv)+3*g3*vv.*(1-vv).^2;
nn = a3h./(a3h+b3h);

figure;
plot(t,nn);grid;title('\eta(x,t) via solving the ODE: v is given');

figure;
plot(t,abs(nn-neta_app));grid;title('absolute error b/t ODE \eta(x,t) & approximation');

figure;
plot(t,abs((nn-neta_app)./nn));grid;title('relative error b/t ODE \eta(x,t) & approximation');

figure;
plot(t,abs(vv-mu_app));grid;title('absolute error b/t ODE \mu(x,t) & approximation');

figure;
plot(t,abs((vv-mu_app)./vv));grid;title('relative error b/t ODE \mu(x,t) & approximation');
