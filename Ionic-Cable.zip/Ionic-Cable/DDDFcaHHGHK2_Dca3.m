function [ret] = DDDFcaHHGHK2_Dca3(UU,Cai,k,Ca_ref,Cao,Up,Uca,Omega,mm)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{ca} note that Phi_{ca}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

idx2=find(abs(UU)>=1e-6);
idx=find(abs(UU)<1e-6);

ret = zeros(size(UU));

if (isempty(nonzeros(idx2))==0)

     ret(idx2) = -k*mm(idx2).^2.*(6*Ca_ref^3/Cao*exp(Omega*Up*UU(idx2)).*UU(idx2)./(k+Ca_ref.*Cai(idx2)).^3 ...
     -6*Ca_ref^3.*UU(idx2)./(k+Ca_ref.*Cai(idx2)).^4.*(exp(Omega*Up*(UU(idx2)-Uca))-1))./(exp(Omega*Up*UU(idx2))-1);

     ret(idx) = -k*mm(idx).^2.*(6*Ca_ref^3/Cao*exp(Omega*Up*UU(idx))./(k+Ca_ref.*Cai(idx)).^3+...
     -6*Ca_ref^3./(k+Ca_ref.*Cai(idx)).^4.*(exp(Omega*Up*(UU(idx)-Uca))-1))./(Omega*Up);

else

     ret(idx) = -k*mm(idx).^2.*(6*Ca_ref^3/Cao*exp(Omega*Up*UU(idx))./(k+Ca_ref.*Cai(idx)).^3+...
     -6*Ca_ref^3./(k+Ca_ref.*Cai(idx)).^4.*(exp(Omega*Up*(UU(idx)-Uca))-1))./(Omega*Up);


end;
