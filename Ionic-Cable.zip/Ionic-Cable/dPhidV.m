clear;close all;

a1=0.182;
b1=-35;
c1=9;
a2=0.124;
b2=-35;
c2=9;
Er=-80;

% a1=0.5;
% b1=-70;
% c1=0.00001;
% a2=0.05;
% b2=-70;
% c2=0.01;
% Er=-70;

u0=5.12;
up=88.38928681566553; %1;

mu0=0.0005;
Rm=25000;
Cm=0.9e-6;
tau=Rm*Cm*1000;

t=linspace(0,6,1000);
dt=t(2)-t(1);

pos=0;

mmu(1)=alpham(pos,t(1),Er,a1,b1,c1,u0,up)/(alpham(pos,t(1),Er,a1,b1,c1,u0,up)+betam(pos,t(1),Er,a1,b1,c1,u0,up));

y=alpham(pos,t,Er,a1,b1,c1,u0,up);
y2=betam(pos,t,Er,a1,b1,c1,u0,up);
vv=zeros(size(t));
vv(1)=mmu(1);
for i=2:length(t)
%    vv(i)=vv(i-1)+dt*tau*y(i-1)-dt*tau*(alpham(pos,t(i-1),Er,a1,b1,c1,u0,up)+betam(pos,t(i-1),Er,a2,b2,c2,u0,up))*vv(i-1);
   vv(i)=(vv(i-1)+dt/2*tau*(y(i-1)+y(i))-dt/2*tau*(alpham(pos,t(i-1),Er,a1,b1,c1,u0,up)+betam(pos,t(i-1),Er,a2,b2,c2,u0,up))*vv(i-1))/...
       (1+dt/2*tau*(alpham(pos,t(i),Er,a1,b1,c1,u0,up)+betam(pos,t(i),Er,a2,b2,c2,u0,up)));
end;

a3=0.8;
b3=-70;
c3=10.0;
g1=1.0;
g2=0.043;
g3=0.025;


y=a3*(1-vv);
y2=g1*vv.^3+3*g2*vv.^2.*(1-vv)+3*g3*vv.*(1-vv).^2;

hh=zeros(size(t));
hh(1)=y(1)/(y(1)+y2(1));
for i=2:length(t)
%    vv(i)=vv(i-1)+dt*tau*y(i-1)-dt*tau*(alpham(pos,t(i-1),Er,a1,b1,c1,u0,up)+betam(pos,t(i-1),Er,a2,b2,c2,u0,up))*vv(i-1);
     hh(i)=(hh(i-1)+dt/2*tau*(y(i-1)+y(i))-dt/2*tau*(y(i-1)+y2(i-1))*hh(i-1))/(1+dt/2*tau*(y(i)+y2(i)));
end;

Vna=135;
Una=Vna/up;
UU=Phi(pos,t,u0,up);

figure;
plot(t,Fna(UU,up,Una,u0,vv,hh));

figure;
plot(t,vv);grid;title('\mu(x,t) via solving the ODE: v is given');

figure;
plot(t,Phi(0,t,u0,up),t,DPhi(0,t,u0,up));grid;

figure;
plot(t,vv./DPhi(0,t,u0,up));

figure;
plot(t,alpham(0,t,Er,a1,b1,c1,u0,up),t,dalpham(0,t,Er,a1,b1,c1,u0,up))

figure;
plot(t,betam(0,t,Er,a1,b1,c1,u0,up),t,dbetam(0,t,Er,a1,b1,c1,u0,up))

yy=dalpham(pos,t,Er,a1,b1,c1,u0,up);
yy2=dbetam(pos,t,Er,a1,b1,c1,u0,up);
vv2=zeros(size(t));
vv2(1)=(dalpham(pos,t(1),Er,a1,b1,c1,u0,up)-(dalpham(pos,t(1),Er,a1,b1,c1,u0,up)+dbetam(pos,t(1),Er,a1,b1,c1,u0,up))*vv(1))/(alpham(pos,t(1),Er,a1,b1,c1,u0,up)+betam(pos,t(1),Er,a1,b1,c1,u0,up));
for i=2:length(t)
    
   vv2(i)=(vv2(i-1)+dt/2*tau*(yy(i-1)+yy(i))-dt/2*tau*(dalpham(pos,t(i-1),Er,a1,b1,c1,u0,up)+dbetam(pos,t(i-1),Er,a2,b2,c2,u0,up))*vv(i-1)...
       -dt/2*tau*(dalpham(pos,t(i),Er,a1,b1,c1,u0,up)+dbetam(pos,t(i),Er,a2,b2,c2,u0,up))*vv(i)...
       -dt/2*tau*(alpham(pos,t(i),Er,a1,b1,c1,u0,up)+betam(pos,t(i),Er,a2,b2,c2,u0,up)).*vv2(i-1))/...
       (1+dt/2*tau*(alpham(pos,t(i),Er,a1,b1,c1,u0,up)+betam(pos,t(i),Er,a2,b2,c2,u0,up)));
end;

figure;
plot(t,vv2);title('vv2')

y=alpham(pos,t,Er,a1,b1,c1,u0,up);
y2=betam(pos,t,Er,a1,b1,c1,u0,up);
vv=zeros(size(t));
vv(1)=mmu(1);
yy=dalpham(pos,t,Er,a1,b1,c1,u0,up);
yy2=dbetam(pos,t,Er,a1,b1,c1,u0,up);
vv2=zeros(size(t));
vv2(1)=(dalpham(pos,t(1),Er,a1,b1,c1,u0,up)-(dalpham(pos,t(1),Er,a1,b1,c1,u0,up)+dbetam(pos,t(1),Er,a1,b1,c1,u0,up))*vv(1))/(alpham(pos,t(1),Er,a1,b1,c1,u0,up)+betam(pos,t(1),Er,a1,b1,c1,u0,up));

for i=2:length(t)
    
   vv(i)=(vv(i-1)+dt/2*tau*(y(i-1)+y(i))-dt/2*tau*(alpham(pos,t(i-1),Er,a1,b1,c1,u0,up)+betam(pos,t(i-1),Er,a2,b2,c2,u0,up))*vv(i-1))/...
         (1+dt/2*tau*(alpham(pos,t(i),Er,a1,b1,c1,u0,up)+betam(pos,t(i),Er,a2,b2,c2,u0,up)));

   vv2(i)=(vv2(i-1)+dt/2*tau*(yy(i-1)+yy(i))-dt/2*tau*(dalpham(pos,t(i-1),Er,a1,b1,c1,u0,up)+dbetam(pos,t(i-1),Er,a2,b2,c2,u0,up))*vv(i-1)...
       -dt/2*tau*(dalpham(pos,t(i),Er,a1,b1,c1,u0,up)+dbetam(pos,t(i),Er,a2,b2,c2,u0,up))*vv(i)...
       -dt/2*tau*(alpham(pos,t(i),Er,a1,b1,c1,u0,up)+betam(pos,t(i),Er,a2,b2,c2,u0,up)).*vv2(i-1))/...
       (1+dt/2*tau*(alpham(pos,t(i),Er,a1,b1,c1,u0,up)+betam(pos,t(i),Er,a2,b2,c2,u0,up)));
end;

figure;
plot(t,vv2);grid;

figure;
plot(t,tau*(y-(y+y2).*vv)./DPhi(0,t,u0,up));grid;