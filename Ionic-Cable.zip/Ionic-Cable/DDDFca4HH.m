function [ret] = DDDFca4HH(UU,Cai,Ca_ref,Uca,mm,hh,Dmm_dUU,Dhh_dUU,D2mm_dUU2,D2hh_dUU2,D3mm_dUU3,D3hh_dUU3)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{ca} note that Phi_{ca}U_{peak} 
% is the calcium reversal or equilibrium potential
% UU - refers to Phi_0(x,t)

% ret = 1./(1+Ca_ref*Cai./5e-4).*(3*(-4*mm.*Dmm_dUU.*Dhh_dUU-mm.^2.*D2hh_dUU2-hh.*(2*Dmm_dUU.^2+2*mm.*D2mm_dUU2))...
%       +(Uca-UU).*(6*mm.*Dmm_dUU.*D2hh_dUU2+3*Dhh_dUU.*(2*Dmm_dUU.^2+2*mm.*D2mm_dUU2)...
%       +mm.^2.*D3hh_dUU3+hh.*(6*Dmm_dUU.*D2mm_dUU2+2*mm.*D3mm_dUU3)));

  ret = (0.002/Ca_ref)./(0.002/Ca_ref+Cai).*(3*(-4*mm.*Dmm_dUU.*Dhh_dUU-mm.^2.*D2hh_dUU2-hh.*(2*Dmm_dUU.^2+2*mm.*D2mm_dUU2))...
      +(Uca-UU).*(6*mm.*Dmm_dUU.*D2hh_dUU2+3*Dhh_dUU.*(2*Dmm_dUU.^2+2*mm.*D2mm_dUU2)...
      +mm.^2.*D3hh_dUU3+hh.*(6*Dmm_dUU.*D2mm_dUU2+2*mm.*D3mm_dUU3)));
