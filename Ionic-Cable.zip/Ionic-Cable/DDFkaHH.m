function [ret] = DDFkaHH(UU,Up,Uka,mm,hh,Dmm_dUU,Dhh_dUU,D2mm_dUU2,D2hh_dUU2)

% Una - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = 2*(-mm.^4.*Dhh_dUU-4*hh.*mm.^3.*Dmm_dUU)...
    +(Uka-UU).*(8*mm.^3.*Dhh_dUU.*Dmm_dUU+mm.^4.*D2hh_dUU2...
    +hh.*(12*mm.^2.*Dmm_dUU.^2+4*mm.^3.*D2mm_dUU2));
