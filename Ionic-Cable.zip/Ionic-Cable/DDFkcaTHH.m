function [ret] = DDFkcaTHH(UU,Cai,Ca_ref,Ukca,Dmm_dUU,D2mm_dUU2)

% Ukca - refers to Phi_{kca} note that Phi_{kca}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

idx2=find(Ca_ref.*Cai<0.002);
idx=find(Ca_ref.*Cai>=0.002);

ret = zeros(size(UU));

if (isempty(nonzeros(idx2))==0)

   ret(idx2) = Ca_ref*Cai(idx2)/0.002.*(-2*Dmm_dUU(idx2)+D2mm_dUU2(idx2).*(Ukca-UU(idx2)));
   ret(idx) = -2*Dmm_dUU(idx)+D2mm_dUU2(idx).*(Ukca-UU(idx));
   
else
    
   ret(idx) = -2*Dmm_dUU(idx)+D2mm_dUU2(idx).*(Ukca-UU(idx));
    
end;