function [ret] = DDFca2_DvDca2(UU,Up,Uca,Omega,mm,Dmm_dUU,D2hh_dCa2,D3hh_dUUdCa2)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{ca} note that Phi_{ca}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

idx2=find(abs(UU)>=1e-6);
idx=find(abs(UU)<1e-6);

ret = zeros(size(UU));

if (isempty(nonzeros(idx2))==0)

    ret(idx2) = -((exp(Omega*Up*(UU(idx2)-Uca))-1).*mm(idx2).^2.*D2hh_dCa2(idx2)./(exp(Omega*Up*UU(idx2))-1) ...
      +exp(Omega*Up*(UU(idx2)-Uca)).*mm(idx2).^2.*D2hh_dCa2(idx2).*Omega.*Up.*UU(idx2)./(exp(Omega*Up*UU(idx2))-1)...
      -exp(Omega*Up*UU(idx2)).*(exp(Omega*Up*(UU(idx2)-Uca))-1).*mm(idx2).^2.*D2hh_dCa2(idx2).*Omega.*Up.*UU(idx2)./(exp(Omega*Up*UU(idx2))-1).^2 ...
      +(exp(Omega*Up*(UU(idx2)-Uca))-1).*mm(idx2).^2.*D3hh_dUUdCa2(idx2).*UU(idx2)./(exp(Omega*Up*UU(idx2))-1) ...
      +2*(exp(Omega*Up*(UU(idx2)-Uca))-1).*mm(idx2).*Dmm_dUU(idx2).*D2hh_dCa2(idx2).*UU(idx2)./(exp(Omega*Up*UU(idx2))-1));
else
    
    ret(idx)=-((exp(Omega*Up*(UU(idx)-Uca))-1).*mm(idx).^2.*D2hh_dCa2(idx)./(exp(Omega*Up*UU(idx))-1)...
      +exp(Omega*Up*(UU(idx)-Uca)).*mm(idx).^2.*D2hh_dCa2(idx)...
      -exp(Omega*Up*UU(idx)).*(exp(Omega*Up*(UU(idx)-Uca))-1).*mm(idx).^2.*D2hh_dCa2(idx).*Omega.*Up.*UU(idx)./(exp(Omega*Up*UU(idx))-1).^2 ...
      +(exp(Omega*Up*(UU(idx)-Uca))-1).*mm(idx).^2.*D3hh_dUUdCa2(idx)./(Omega*Up) ...
      +2*(exp(Omega*Up*(UU(idx)-Uca))-1).*mm(idx).*Dmm_dUU(idx).*D2hh_dCa2(idx)./(Omega*Up));

end;
