function [ret] = Phin(x,t,u0,up)

ret2=zeros(size(t));

idx=find(t>=0);

if (isempty(nonzeros(idx))==0) 
    ret2(idx) = (50.0*u0/(up*sqrt(pi))).*(4.*x.*sqrt(t(idx)).*exp(-x.^2./(4*t(idx))).*(0.75*exp(-2*t(idx))-1.5*exp(-4*t(idx))-...
        0.05*exp(-1.2*t(idx)))+sqrt(pi)*erfc(x./(2*sqrt(t(idx)))).*((3-1.5*x.^2).*exp(-2*t(idx))-(2-3*x.^2).*exp(-4*t(idx))-...
        (1-0.1*x.^2).*exp(-1.2*t(idx))));
end;

ret = ret2-70*ones(size(ret2));