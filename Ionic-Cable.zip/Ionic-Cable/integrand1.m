%function ret = integrand1(s,t,x,xi,u0,up,UU,Una,Omega,mm,hh);
function ret = integrand1(s,t,ss,x,xi,u0,up,Una,Er,Omega,mm,hh);

%plot(hh);

UU=Phi(xi,s,u0,up);

mmi=interp1(ss,mm,s,'spline');
hhi=interp1(ss,hh,s,'spline');

%ret = G(x,xi,t-s);
ret = G(x,xi,t-s).*Fna(UU,up,Una,Omega,mmi,hhi);

%plot(s,ret)
% pause(1)