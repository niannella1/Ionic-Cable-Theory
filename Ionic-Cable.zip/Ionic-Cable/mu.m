function [ret] = mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)

idx = find(t>=0);
idx2 = find(t<0);

ret = zeros(size(t));

if (isempty(nonzeros(idx))==0)

     ret = tau*fm(x,t,dt,Er,a1,b1,c1,u0,up)-tau^2*gm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)+tau^3*rm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up);
%     ret = tau*fm(x,t,dt,Er,a1,b1,c1,u0,up)-tau^2*gm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)+tau^3*rm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)-tau^4*qm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up);
%      ret = (tau)*fm(x,t,dt,Er,a1,b1,c1,u0,up)-(tau)^2*gm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)+(tau)^3*rm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)...
%          -(tau)^4*qm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)+(tau)^5*tm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)-(tau)^6*vm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up);
  
else
    
    ret(idx2) = mu0;
        
end;

