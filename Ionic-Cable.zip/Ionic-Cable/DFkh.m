function [ret] = DFkh(UU,Up,Uk,Omega,mm,Dmm_dUU)

% Omega - factor scaling U_{peak}
% Uk - refers to Phi_{k} note that Phi_{k}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

idx2=find(abs(UU)>=1e-6);
idx=find(abs(UU)<1e-6);

ret = zeros(size(UU));

if (isempty(nonzeros(idx2))==0)

    ret(idx2) = -((exp(Omega*Up*(UU(idx2)-Uk))-1).*mm(idx2)./(exp(Omega*Up*UU(idx2))-1)...
      +exp(Omega*Up*(UU(idx2)-Uk)).*mm(idx2).*Omega.*Up.*UU(idx2)./(exp(Omega*Up*UU(idx2))-1)...
      -exp(Omega*Up*UU(idx2)).*(exp(Omega*Up*(UU(idx2)-Uk))-1).*mm(idx2).*Omega.*Up.*UU(idx2)./(exp(Omega*Up*UU(idx2))-1).^2 ...
      +(exp(Omega*Up*(UU(idx2)-Uk))-1).*Dmm_dUU(idx2).*UU(idx2)./(exp(Omega*Up*UU(idx2))-1));
  
else
    
    ret(idx) = -((exp(Omega*Up*(UU(idx)-Uk))-1).*mm(idx)./(exp(Omega*Up*UU(idx))-1)...
        +exp(Omega*Up*(UU(idx)-Uk)).*mm(idx) ...
              -exp(Omega*Up*UU(idx)).*(exp(Omega*Up*(UU(idx)-Uk))-1).*nn(idx).*Omega.*Up.*UU(idx)./(exp(Omega*Up*UU(idx))-1).^2 ...
        +(exp(Omega*Up*(UU(idx)-Uk))-1).*Dmm_dUU(idx).*UU(idx)./(exp(Omega*Up*UU(idx))-1));
end;