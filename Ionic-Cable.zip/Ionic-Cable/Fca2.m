function [ret] = Fca2(UU,Up,Uca,Omega,mm,hh)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

idx2=find(abs(UU)>=1e-6);
idx=find(abs(UU)<1e-6);

ret = zeros(size(UU));

if (isempty(nonzeros(idx2))==0)

    ret(idx2) = -(exp(Omega*Up*(UU(idx2)-Uca))-1).*mm(idx2).^2.*hh(idx2).*UU(idx2)./(exp(Omega*Up*UU(idx2))-1);

else
    
    ret(idx) = -(exp(Omega*Up*(UU(idx)-Uca))-1).*mm(idx).^2.*hh(idx)/(Up*Omega);

end;