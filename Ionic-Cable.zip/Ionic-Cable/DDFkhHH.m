function [ret] = DDFkhHH(UU,Up,Uk,mm,Dmm_dUU,D2mm_dUU2)

% Uk - refers to Phi_{k} note that Phi_{k}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = -2*Dmm_dUU+D2mm_dUU2.*(Uk-UU);
