function [ret] = fm(x,t,dt,Er,a1,b1,c1,u0,up)

% ret = cumsum(dt*alpham(x,t,Er,a1,b1,c1,u0,up));

X=zeros(size(t));
fn=alpham(x,t,Er,a1,b1,c1,u0,up);
X(1)=fn(1)/(fn(1)+betam(x,t(1),Er,a1,b1,c1,u0,up));

for i=2:length(t)
    X(i)=X(i-1)+dt*fn(i); % Rectangular
end;

ret = X;
