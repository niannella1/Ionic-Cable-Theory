function [ret] = DDFkHH(UU,Up,Uk,nn,Dnn_dUU,D2nn_dUU2)

% Uk - refers to Phi_{k} note that Phi_{k}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)


ret = -2*Dnn_dUU+D2nn_dUU2.*(Uk-UU);
