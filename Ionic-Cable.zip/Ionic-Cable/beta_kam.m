function [ret] = beta_kam(x,t,Er,a2,b2,c2,u0,up)

% idx=find(abs((Phi(x,t,u0,up)*up+Er-b2)/c2)<1e-6);
% idx2=find(abs((Phi(x,t,u0,up)*up+Er-b2)/c2)>=1e-6);
% 
% ret = zeros(size(t));
% 
% if (isempty(nonzeros(idx2))==0)

    ret = a2*exp((Phi(x,t,u0,up)*up+Er+b2)/c2);

% else
%     
%     ret(idx) = a2*c2;
%     
% end;

