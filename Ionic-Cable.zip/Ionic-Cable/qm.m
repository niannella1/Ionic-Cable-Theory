function [ret] = qm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)

% ret = cumsum(dt*pm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up));

X(1)=0;
fn=pm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up);

for i=2:length(t)
    X(i)=X(i-1)+dt*fn(i); % Rectangular
end;

ret = X;