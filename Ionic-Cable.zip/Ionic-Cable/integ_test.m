%clear;close all;

t=linspace(0,10,1000);
T=t(2)-t(1);

% fn=-2*t.*exp(-t.^2);
% intfn=exp(-t.^2);

fn=2*t.*exp(-t.^2);
intfn=-exp(-t.^2);

X1=zeros(size(t));
X2=X1;
X3=X1;
X4=X1;
X1(1)=intfn(1);
X2(1)=intfn(1);
X3(1)=intfn(1);
X4(1)=intfn(1);

% T-integration from Mathematica
for i=2:length(t)
    X1(i)=X1(i-1)+T*fn(i-1); % Euler
    X2(i)=X2(i-1)+T*(fn(i)/2+fn(i-1)/2); % Trapezoidal
    X3(i)=X3(i-1)+T*fn(i); % Rectangular
    X4(i)=X4(i-1)+T*(3/2*fn(i)-fn(i-1)/2); % Adams
end;

for i=1:length(t) 
    XX1(i)=X1(i)-X1(1);
    XX2(i)=X2(i)-X2(1);
    XX3(i)=X3(i)-X3(1);
    XX4(i)=X4(i)-X4(1);
end;

figure;
plot(t,fn,t,X1,'r',t,intfn,'g',t,XX1,'c');

figure;
plot(t,fn,t,X2,'r',t,intfn,'g',t,XX1,'c');

figure;
plot(t,fn,t,X3,'r',t,intfn,'g',t,XX1,'c');

figure;
plot(t,fn,t,X4,'r',t,intfn,'g',t,XX1,'c');
