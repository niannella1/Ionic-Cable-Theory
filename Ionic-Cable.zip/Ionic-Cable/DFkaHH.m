function [ret] = DFkaHH(UU,Up,Uka,mm,hh,Dmm_dUU,Dhh_dUU)

% Una - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = -mm.^4.*hh+mm.^4.*Dhh_dUU.*(Uka-UU)+4*mm.^3.*Dmm_dUU.*hh.*(Uka-UU);
