function [ret] = alpha_hvam(x,t,Er,a1,b1,c1,u0,up)

ret = a1./(1.0+exp(-(Phi(x,t,u0,up)*up+Er-b1)/c1));