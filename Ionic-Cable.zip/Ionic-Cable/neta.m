function [ret] = neta(x,t,neta0,g1,g2,g3,a3,ah0,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)

idx = find(t>=0);
idx2 = find(t<0);

ret = zeros(size(t));

if (isempty(nonzeros(idx))==0)

    ret = alphah(x,t,a3,ah0,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)./(alphah(x,t,a3,ah0,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)+betah(x,t,g1,g2,g3,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up));
      
else
    
    ret(idx2) = neta0;
    
end;