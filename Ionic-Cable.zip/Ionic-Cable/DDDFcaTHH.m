function [ret] = DDDFcaTHH(UU,Uca,mm,Dmm_dUU,D2mm_dUU2,D3mm_dUU3)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{ca} note that Phi_{ca}U_{peak} 
% is the calcium reversal or equilibrium potential
% UU - refers to Phi_0(x,t)

ret = -6*Dmm_dUU.^2-6*mm.*D2mm_dUU2+(Uca-UU).*(6*Dmm_dUU.*D2mm_dUU2+2*mm.*D3mm_dUU3);
