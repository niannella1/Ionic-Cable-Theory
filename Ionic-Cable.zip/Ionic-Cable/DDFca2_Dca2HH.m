function [ret] = DDFca2_Dca2HH(UU,Up,Uca,mm,D2hh_dCa2)

% Omega - factor scaling U_{peak}
% Una - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = mm.^2.*D2hh_dCa2.*(Uca-UU);