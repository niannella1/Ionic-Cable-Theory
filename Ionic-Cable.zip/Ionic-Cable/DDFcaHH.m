function [ret] = DDFcaHH(UU,Up,Uca,mm,Dmm_dUU,D2mm_dUU2)

% Omega - factor scaling U_{peak}
% Una - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = 2*mm.*D2mm_dUU2.*(Uca-UU)-4*mm.*Dmm_dUU+2*Dmm_dUU.^2.*(Uca-UU);
