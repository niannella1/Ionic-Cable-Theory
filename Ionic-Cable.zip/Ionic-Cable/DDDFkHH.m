function [ret] = DDDFkHH(UU,Up,Uk,nn,Dnn_dUU,D2nn_dUU2,D3nn_dUU3)

% Uk - refers to Phi_{k} note that Phi_{k}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)


ret = -3*D2nn_dUU2+D3nn_dUU3.*(Uk-UU);
