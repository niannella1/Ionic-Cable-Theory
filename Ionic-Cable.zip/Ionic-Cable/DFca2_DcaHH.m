function [ret] = DFca2_DcaHH(UU,Up,Uca,mm,Dhh_dCa)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{na} note that Phi_{ca}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = mm.^2.*Dhh_dCa.*(Uca-UU);