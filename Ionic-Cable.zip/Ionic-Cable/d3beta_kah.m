function [ret] = d3beta_kah(x,t,Er,a2,b2,c2,u0,up)

% idx=find(abs((Phi(x,t,u0,up)*up+Er-b2)/c2)<1e-6);
% idx2=find(abs((Phi(x,t,u0,up)*up+Er-b2)/c2)>=1e-6);
% 
% ret = zeros(size(t));
% 
% if (isempty(nonzeros(idx2))==0)

    ret = a2*(up/c2)^3*exp((Phi(x,t,u0,up)*up+Er+b2)/c2);

% else
%     
%     ret(idx) = a2*c2;
%     
% end;

% ret = -a2./(1+exp(-(Phi(x,t,u0,up)*up+Er-b2)/c2)); %F-H


% uu0=u0;
% 
% idx = find(t>=0);
% idx2 = find(t<0);
% 
% ret=zeros(size(t));
% 
% if (isempty(nonzeros(idx))==0)
% 
%     ret(idx) = g1*mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up).^3+...
%         3*g2*mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up).^2.*(1-mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up))+...
%         3*g3*mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up).*(1-mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)).^2;
%  
% else
%     
%     ret(idx2)= g1*mu(x,t(idx2),mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up).^3+...
%         3*g2*mu(x,t(idx2),mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up).^2.*(1-mu(x,t(idx2),mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up))+...
%         3*g3*mu(x,t(idx2),mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up).*(1-mu(x,t(idx2),mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)).^2;
%     
% end;

% ret= g1*mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up).^3+...
%      3*g2*mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up).^2.*(1-mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up))+...
%      3*g3*mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up).*(1-mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)).^2;
    