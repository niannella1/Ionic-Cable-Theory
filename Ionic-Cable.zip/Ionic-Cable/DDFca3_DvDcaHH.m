function [ret] = DDFca3_DvDcaHH(UU,Cai,A,Uca,mm,hh,Dmm_dUU,Dhh_dCa,D2hh_dUUdCa)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{na} note that Phi_{ca}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = 2*mm.*Dmm_dUU.*Dhh_dCa.*(Uca-UU)+mm.^2.*D2hh_dUUdCa.*(Uca-UU)-mm.^2.*Dhh_dCa-2*mm.*hh.*Dmm_dUU.*A./Cai...
        -mm.^2.*Dhh_dCa.*A./Cai;