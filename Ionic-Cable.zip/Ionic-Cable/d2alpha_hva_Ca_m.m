function [ret] = d2alpha_hva_Ca_m(UU,Er,a1,b1,c1,u0,up)

ret = a1*2*(up/c1)^2*exp(-2*(UU*up+Er-b1)/c1)./(1.0+exp(-(UU*up+Er-b1)/c1)).^3 ...
        -a1*(up/c1)^2*exp(-(UU*up+Er-b1)/c1)./(1.0+exp(-(UU*up+Er-b1)/c1)).^2;
