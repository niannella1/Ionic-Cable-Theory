function [ret] = FkaHH(UU,Up,Uka,mm,hh)

% Una - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = mm.^4.*hh.*(Uka-UU);
