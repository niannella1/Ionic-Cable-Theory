function [ret] = d3hh_inf(x,t,Er,a1,b1,c1,u0,up)

ret = zeros(size(t));
    
ret = -up^3/c1^3*exp((Phi(x,t,u0,up)*up+Er-b1)/c1)./(1.0+exp((Phi(x,t,u0,up)*up+Er-b1)/c1)).^2...
      +4*up^3/c1^3*exp(2*(Phi(x,t,u0,up)*up+Er-b1)/c1)./(1.0+exp((Phi(x,t,u0,up)*up+Er-b1)/c1)).^3...
      -6*up^3/c1^3*exp(3*(Phi(x,t,u0,up)*up+Er-b1)/c1)./(1.0+exp((Phi(x,t,u0,up)*up+Er-b1)/c1)).^4;