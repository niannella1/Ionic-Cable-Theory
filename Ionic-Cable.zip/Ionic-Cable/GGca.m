function [ret] = GGca(x,y,t)

idx=find(t>1e-6);

ret = zeros(size(t));

if (isempty(nonzeros(idx))==0)
    
    ret(idx)=exp(-t(idx))./sqrt(4*pi*t(idx)).*(exp(-(x-y).^2./(4*t(idx)))-exp(-(x+y).^2./(4*t(idx))));

end;