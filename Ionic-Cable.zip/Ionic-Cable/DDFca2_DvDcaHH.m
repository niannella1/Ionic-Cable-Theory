function [ret] = DDFca2_DvDcaHH(UU,Up,Uca,mm,Dmm_dUU,Dhh_dCa,D2hh_dUUdCa)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{na} note that Phi_{ca}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = -mm.^2.*Dhh_dCa+mm.^2.*D2hh_dUUdCa.*(Uca-UU)+2*mm.*Dhh_dCa.*Dmm_dUU.*(Uca-UU);