function [ret] = DDDFcaT_Dca3HH(UU,Cai,Ca_ref,Uca,mm,hh)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{ca} note that Phi_{ca}U_{peak} 
% is the calcium reversal or equilibrium potential
% UU - refers to Phi_0(x,t)

ret = -0*(Ca_ref/5e-4)^3./(1+Ca_ref*Cai./5e-4).^4.*mm.^2.*hh.*(Uca-UU);