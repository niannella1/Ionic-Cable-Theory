function [ret] = tauh(x,t,Er,a1,b1,c1,u0,up)

ret = zeros(size(t));

ret =1./(alphah(x,t,Er,a1,b1,c1,u0,up)+betah(x,t,Er,a1,b1,c1,u0,up));
