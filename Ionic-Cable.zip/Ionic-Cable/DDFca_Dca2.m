function [ret] = DDFca_Dca2(UU,Up,Uca,Omega,mm)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{ca} note that Phi_{ca}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = zeros(size(UU));
