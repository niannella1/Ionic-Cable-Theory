% For HH channels

close all;

% Sodium

figure;hold;
for ii=1:HotSpotNum_na,
UU=Phi(Xi_na(ii),T,u0,up);
plot(T,G(Xpos,Xi_na(ii),T).*(FnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:))))
end

figure;hold;
for ii=1:HotSpotNum_na,
UU=Phi(Xi_na(ii),T,u0,up);
plot(T,G(Xpos,Xi_na(ii),T).*(DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi1(ii,:)))
end

figure;hold;
for ii=1:HotSpotNum_na,
UU=Phi(Xi_na(ii),T,u0,up);
plot(T,G(Xpos,Xi_na(ii),T).*(DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi2(ii,:) ...
        +1/2*DDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).^2))
end

figure;hold;
for ii=1:HotSpotNum_na,
UU=Phi(Xi_na(ii),T,u0,up);
plot(T,G(Xpos,Xi_na(ii),T).*(DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi3(ii,:)...
        +DDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).*Phi2(ii,:)...
        +1/6*DDDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:),d3mm_dv3(ii,:),d3hh_dv3(ii,:)).*Phi1(ii,:).^3))
end

% Delayed rectifier Kdr

figure;hold;
for pp=1:HotSpotNum_k,
UU=Phi(Xi_k(pp),T,u0,up);
plot(T,G(Xpos,Xi_k(pp),T).*(FkHH(UU+Er/up,up,Phi_k,nn(pp,:))))
end

figure;hold;
for pp=1:HotSpotNum_k,
UU=Phi(Xi_k(pp),T,u0,up);
plot(T,G(Xpos,Xi_k(pp),T).*(DFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:)).*Phi1(ii+pp,:)))
end

figure;hold;
for pp=1:HotSpotNum_k,
UU=Phi(Xi_k(pp),T,u0,up);
plot(T,G(Xpos,Xi_k(pp),T).*(DFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:)).*Phi2(ii+pp,:) ...
        +1/2*DDFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).^2))
end

figure;hold;
for pp=1:HotSpotNum_k,
UU=Phi(Xi_k(pp),T,u0,up);
plot(T,G(Xpos,Xi_k(pp),T).*(DFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:)).*Phi3(ii+pp,:)...
        +DDFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).*Phi2(ii+pp,:)...
        +1/6*DDDFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:),d3nn_dv3(pp,:)).*Phi1(ii+pp,:).^3))
end
% 
% % A-current
% 

figure;hold;
for qq=1:HotSpotNum_ka,
UU=Phi(Xi_ka(qq),T,u0,up);
plot(T,G(Xpos,Xi_ka(qq),T).*(FkaHH(UU+Er/up,up,Phi_ka,mm_ka(qq,:),hh_ka(qq,:))))
end;

figure;hold;
for qq=1:HotSpotNum_ka,
UU=Phi(Xi_ka(qq),T,u0,up);
plot(T,G(Xpos,Xi_ka(qq),T).*(DFkaHH(UU+Er/up,up,Phi_ka,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi1(ii+pp+qq,:)))
end;

figure;hold;
for qq=1:HotSpotNum_ka,
UU=Phi(Xi_ka(qq),T,u0,up);
plot(T,G(Xpos,Xi_ka(qq),T).*(DFkaHH(UU+Er/up,up,Phi_ka,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi2(ii+pp+qq,:) ...
        +1/2*DDFkaHH(UU+Er/up,up,Phi_ka,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:)).*Phi1(ii+pp+qq,:).^2))
end;

figure;hold;
for qq=1:HotSpotNum_ka,
UU=Phi(Xi_ka(qq),T,u0,up);
plot(T,G(Xpos,Xi_ka(qq),T).*(DFkaHH(UU+Er/up,up,Phi_ka,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi3(ii+pp+qq,:)...
        +DDFkaHH(UU+Er/up,up,Phi_ka,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:)).*Phi1(ii+pp+qq,:).*Phi2(ii+pp+qq,:)...
        +1/6*DDDFkaHH(UU+Er/up,up,Phi_ka,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:),d3mm_ka_dv3(qq,:),d3hh_ka_dv3(qq,:)).*Phi1(ii+pp+qq,:).^3))
end;
% 
% % H-current
% 

figure;hold;
for rr=1:HotSpotNum_kh,
UU=Phi(Xi_kh(rr),T,u0,up);
plot(T,G(Xpos,Xi_kh(rr),T).*(FkhHH(UU+Er/up,up,Phi_kh,mm_kh(rr,:))))
end

figure;hold;
for rr=1:HotSpotNum_kh,
UU=Phi(Xi_kh(rr),T,u0,up);
plot(T,G(Xpos,Xi_kh(rr),T).*(DFkhHH(UU+Er/up,up,Phi_kh,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi1(ii+pp+qq+rr,:)))
end

figure;hold;
for rr=1:HotSpotNum_kh,
UU=Phi(Xi_kh(rr),T,u0,up);
plot(T,G(Xpos,Xi_kh(rr),T).*(DFkhHH(UU+Er/up,up,Phi_kh,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi2(ii+pp+qq+rr,:) ...
        +1/2*DDFkhHH(UU+Er/up,up,Phi_kh,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:)).*Phi1(ii+pp+qq+rr,:).^2))
end

figure;hold;
for rr=1:HotSpotNum_kh,
UU=Phi(Xi_kh(rr),T,u0,up);
plot(T,G(Xpos,Xi_kh(rr),T).*(DFkhHH(UU+Er/up,up,Phi_kh,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi3(ii+pp+qq+rr,:)...
        +DDFkhHH(UU+Er/up,up,Phi_kh,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:)).*Phi1(ii+pp+qq+rr,:).*Phi2(ii+pp+qq+rr,:)...
        +1/6*DDDFkhHH(UU+Er/up,up,Phi_kh,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:),d3mm_kh_dv3(rr,:)).*Phi1(ii+pp+qq+rr,:).^3))
end

% High Voltage activated (HVA) calcium 

figure;hold;
for ss=1:HotSpotNum_hva,
UU=Phi(Xi_hva(ss),T,u0,up);
plot(T,G(Xpos,Xi_hva(ss),T).*(FcaHH(UU+Er/up,up,Phi_ca,mm_hva(ss,:))))
end

figure;hold;
for ss=1:HotSpotNum_hva,
UU=Phi(Xi_hva(ss),T,u0,up);
plot(T,G(Xpos,Xi_hva(ss),T).*(DFcaHH(UU+Er/up,up,Phi_ca,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi1(ii+pp+qq+rr+ss,:)))
end

figure;hold;
for ss=1:HotSpotNum_hva,
UU=Phi(Xi_hva(ss),T,u0,up);
plot(T,G(Xpos,Xi_hva(ss),T).*(DFcaHH(UU+Er/up,up,Phi_ca,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi2(ii+pp+qq+rr+ss,:) ...
        +1/2*DDFcaHH(UU+Er/up,up,Phi_ca,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).^2))
end

figure;hold;
for pp=1:HotSpotNum_hva,
UU=Phi(Xi_hva(ss),T,u0,up);
plot(T,G(Xpos,Xi_hva(ss),T).*(DFcaHH(UU+Er/up,up,Phi_ca,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi3(ii+pp+qq+rr+ss,:)...
        +DDFcaHH(UU+Er/up,up,Phi_ca,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).*Phi2(ii+pp+qq+rr+ss,:)...
        +1/6*DDDFcaHH(UU+Er/up,up,Phi_ca,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:),d3mm_hva_dv3(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).^3))
end

% BK channels

figure;hold;
for tt=1:HotSpotNum_kca,
UU=Phi(Xi_kca(tt),T,u0,up);
plot(T,G(Xpos,Xi_kca(tt),T).*(FkcaHH(UU+Er/up,up,Phi_kca,mm_kca(tt,:))))
end

figure;hold;
for tt=1:HotSpotNum_kca,
UU=Phi(Xi_kca(tt),T,u0,up);
plot(T,G(Xpos,Xi_kca(tt),T).*(DFkcaHH(UU+Er/up,up,Phi_kca,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:)))
end

figure;hold;
for tt=1:HotSpotNum_kca,
UU=Phi(Xi_kca(tt),T,u0,up);
plot(T,G(Xpos,Xi_kca(tt),T).*(DFkcaHH(UU+Er/up,up,Phi_kca,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi2(ii+pp+qq+rr+ss+tt,:) ...
        +1/2*DDFkcaHH(UU+Er/up,up,Phi_kca,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).^2))
end

figure;hold;
for tt=1:HotSpotNum_kca,
UU=Phi(Xi_kca(tt),T,u0,up);
plot(T,G(Xpos,Xi_kca(tt),T).*(DFkcaHH(UU+Er/up,up,Phi_kca,mm_kca(tt,:),dmm_hva_dv(tt,:)).*Phi3(ii+pp+qq+rr+ss+tt,:)...
        +DDFkcaHH(UU+Er/up,up,Phi_kca,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).*Phi2(ii+pp+qq+rr+ss+tt,:)...
        +1/6*DDDFkcaHH(UU+Er/up,up,Phi_kca,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:),d3mm_kca_dv3(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).^3))
end
