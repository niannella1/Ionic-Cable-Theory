function [ret] = DDDFcaT_Dv2DcaHH(UU,Cai,Ca_ref,Uca,mm,hh,Dmm_dUU,Dhh_dUU,D2mm_dUU2,D2hh_dUU2)

% Omega - factor scaling U_{peak}
% Uca - refers to Phi_{ca} note that Phi_{ca}U_{peak} 
% is the calcium reversal or equilibrium potential
% UU - refers to Phi_0(x,t)

ret = -0*(Ca_ref/5e-4)./(1+Ca_ref*Cai./5e-4).^2.*(2*(-mm.^2.*Dhh_dUU-2*hh.*mm.*Dmm_dUU)...
    +(Uca-UU).*(4*mm.*Dhh_dUU.*Dmm_dUU+mm.^2.*D2hh_dUU2+hh.*(2*Dmm_dUU.^2+2*mm.*D2mm_dUU2)));