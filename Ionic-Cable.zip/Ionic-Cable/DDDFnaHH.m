function [ret] = DDDFnaHH(UU,Up,Una,mm,hh,Dmm_dUU,Dhh_dUU,D2mm_dUU2,D2hh_dUU2,D3mm_dUU3,D3hh_dUU3)

% Omega - factor scaling U_{peak}
% Una - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = 3*(-6*mm.^2.*Dmm_dUU.*Dhh_dUU-mm.^3.*D2hh_dUU2-hh.*(6*mm.*Dmm_dUU.^2+3*mm.^2.*D2mm_dUU2))...
      +(Una-UU).*(9*mm.^2.*Dmm_dUU.*D2hh_dUU2+3*Dhh_dUU.*(6*mm.*Dmm_dUU.^2+3*mm.^2.*D2mm_dUU2)...
      +mm.^3.*D3hh_dUU3+hh.*(6*Dmm_dUU.^3+18*mm.*Dmm_dUU.*D2mm_dUU2+3*mm.^2.*D3mm_dUU3));
