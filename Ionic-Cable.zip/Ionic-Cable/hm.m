function [ret] = hm(x,t,dt,Er,a1,b1,c1,a2,b2,c2,u0,up)

ret = (alpham(x,t,Er,a1,b1,c1,u0,up)+betam(x,t,Er,a2,b2,c2,u0,up)).*fm(x,t,dt,Er,a1,b1,c1,u0,up);