function [ret] = alphah(x,t,Er,a1,b1,c1,u0,up)

idx=find(abs((b1-Phi(x,t,u0,up)*up-Er)./c1)<1e-6);
idx2=find(abs((b1-Phi(x,t,u0,up)*up-Er)./c1)>=1e-6);

ret = zeros(size(t));

if (isempty(nonzeros(idx2))==0)

    ret(idx2) = a1.*(Phi(x,t(idx2),u0,up)*up+Er-b1)./(1.0-exp(-(Phi(x,t(idx2),u0,up)*up+Er-b1)/c1));
%    ret(idx2) = -a1.*(Phi(x,t(idx2),u0,up)*up+Er-b1)./(1.0-exp((Phi(x,t(idx2),u0,up)*up+Er-b1)/c1));  %F-H
    ret(idx)=a1*c1;

else
    
    ret(idx)=a1*c1;

end;

% idx = find(t>=0);
% idx2 = find(t<0);
% 
% ret=zeros(size(t));
% 
% uu0=u0;
% 
% if (isempty(nonzeros(idx))==0)
% 
%     ret = a3*(1-mu(x,t,mu0,tau,dt,Er,a1,b1,c1,a2,b2,c2,u0,up));
%     
% else
%     
%     ret(idx2) = ah0;
%         
% end;    