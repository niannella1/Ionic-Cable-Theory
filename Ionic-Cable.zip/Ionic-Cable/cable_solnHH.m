clear; close all;

% % Mainen parameters - Na
% a1=0.182;
% b1=-35;
% c1=9;
% a2=0.124;
% b2=-35;
% c2=9;
% Er=-80;

% a3=0.024;
% b3=-50;
% c3=5;
% a4=0.0091;
% b4=-75;
% c4=5;
% 
% Mainen parameters - K
a1_n=0.02;
b1_n=20;
c1_n=9;
a2_n=0.002;
b2_n=20;
c2_n=9;
 
%Frankenhaeuser-Huxley parameters

% a1=0.36;
% b1=22;
% c1=3;
% a2=0.4;
% b2=13;
% c2=20;
% Er=0;
% 
% a3=0.1;
% b3=-10;
% c3=6;
a4=4.5;
b4=45;
c4=10;
%  
% a1_n=0.02;
% b1_n=35;
% c1_n=10;
% a2_n=0.05;
% b2_n=10;
% c2_n=10;

a1=0.5;
b1=-70;
c1=0.00001;
a2=0.05;
b2=-70;
c2=0.01;
Er=-80;

a3=0.6;
b3=-70;
c3=10.0;
g0=0.8;
g1=1.0; % 1/msec
g2=1/2.3; % 1/msec
g3=1/4; % 1/msec
Vna=135;
Vk=-10;
u0=5.12;
up=88.38928681566553; %1;

mu0=0.0005;
Rm=500; %units of  ohm cm^2
Ri=70; %units of ohm cm
Cm=0.9e-3; %units of mF/cm^2 corresponds to 0.9e-6 F/cm^2
tau=Rm*Cm; %units of msec
diam=4e-4; %units of cm
lambda=sqrt(Rm*diam/(4*Ri)); %units of cm

t=linspace(0,5,1000); %dimensionless time
dt=t(2)-t(1);
T=t/tau; % msec
dT=(T(2)-T(1));

LL=1000; %um
L=LL*1e-4; %units of cm
x=linspace(0,L,100); %units of cm
X=x/lambda; %dimensionless or electrotonic distance

HotSpotNum_na=40;

gna_dens=100e-12; %S/um^2

gna=18e-12; %units of S, maximum attainable conductance of 18pS for a single Na channel refs [100,107] in Poz

Num_of_chans_na=(gna_dens/gna)*pi*267*(diam*1e4)*HotSpotNum_na;%300;

Ina_chan_dens=Num_of_chans_na*ones(1,HotSpotNum_na)/(pi*diam); 

Gna=gna*Ina_chan_dens; %units of S/cm

% Xin_na=L/lambda;  %position of last hotspot in units of dimensionless distance
Xin_na=267e-4/lambda;  %position of last hotspot in units of dimensionless distance
Xi0_na=Xin_na/HotSpotNum_na; %position of first hotspot in units of dimensionless distance

% Xin_na=350e-4/lambda;  %position of last hotspot in units of dimensionless distance
% Xi0_na=250e-4/lambda

Xi_na=linspace(Xi0_na,Xin_na,HotSpotNum_na); %Positions of hotspots in units of dimensionless distance

Phi_na=Vna/up;

HotSpotNum_k=1;

gk_dens=80e-12; %S/um^2

gk=20e-12; %units of S, maximum attainable conductance of 18pS for a single Na channel refs [100,107] in Poz

Num_of_chans_k=(gk_dens/gk)*pi*267*(diam*1e4)*HotSpotNum_k;

Ik_chan_dens=Num_of_chans_k*ones(1,HotSpotNum_k)/(pi*diam); 

Gk=0*gk*Ik_chan_dens; %units of S/cm

%Xin_k=L/lambda;  %position of last hotspot in units of dimensionless distance
Xin_k=267e-4/lambda;  %position of last hotspot in units of dimensionless distance
Xi0_k=Xin_k/HotSpotNum_k; %position of first hotspot in units of dimensionless distance

Xi_k=linspace(Xi0_k,Xin_k,HotSpotNum_k); %Positions of hotspots in units of dimensionless distance

Phi_k=Vk/up;


F=96480; % Faradays constant Coulomb/mol
R=8.315; % Gas constant J/K/mol
Temp=23; % degC
absT=273.15+Temp; % Absolute temperature K
Omega=F/(R*absT*1000); % units of 1/mV

pow=((Temp-23)/10);
Q10=2.3^pow;


for ii=1:HotSpotNum_na
    
    pos=Xi_na(ii);

    y=Q10*alpham(pos,T,Er,a1,b1,c1,u0,up);
    y2=Q10*betam(pos,T,Er,a2,b2,c2,u0,up);
    yy=Q10*dalpham(pos,T,Er,a1,b1,c1,u0,up);
    yy2=Q10*dbetam(pos,T,Er,a2,b2,c2,u0,up);
    yyy=Q10*d2alpham(pos,T,Er,a1,b1,c1,u0,up);
    yyy2=Q10*d2betam(pos,T,Er,a2,b2,c2,u0,up);
    yyyy=Q10*d3alpham(pos,T,Er,a1,b1,c1,u0,up);
    yyyy2=Q10*d3betam(pos,T,Er,a2,b2,c2,u0,up);

    mmu(1)=y(1)/(y(1)+y2(1));
    vv(1)=(yy(1)-(yy(1)+yy2(1))*mmu(1))/(y(1)+y2(1));
    vv2(1)=(yyy(1)-2*vv(1)*(yy(1)+yy2(1))-mmu(1)*(yyy(1)+yyy2(1)))/(y(1)+y2(1));
    vv3(1)=(yyyy(1)-3*(yy(1)+yy2(1))*vv2(1)-3*(yyy(1)+yyy2(1))*vv(1)-(yyyy(1)+yyyy2(1))*mmu(1))/(y(1)+y2(1));
    
    mm_trans=zeros(size(T));
    mm_trans(1)=mmu(1);
    dmm_dV_trans=zeros(size(t));
    dmm_dV_trans(1)=vv(1);
    d2mm_dV2_trans=zeros(size(t));
    d2mm_dV2_trans(1)=vv2(1);
    d3mm_dV3_trans=zeros(size(t));
    d3mm_dV3_trans(1)=vv3(1);
    

    
    for i=2:length(T)
        mm_trans(i)=(mm_trans(i-1)+dT/2*tau*(y(i-1)+y(i))-dT/2*tau*(y(i-1)+y2(i-1))*mm_trans(i-1))/(1+dT/2*tau*(y(i)+y2(i)));
       
        dmm_dV_trans(i)=(dmm_dV_trans(i-1)+dT/2*tau*(yy(i-1)+yy(i))-dT/2*tau*(yy(i-1)+yy2(i-1))*mm_trans(i-1)...
       -dT/2*tau*(yy(i)+yy2(i))*mm_trans(i)-dT/2*tau*(y(i)+y2(i)).*dmm_dV_trans(i-1))/...
       (1+dT/2*tau*(y(i)+y2(i)));
   
        d2mm_dV2_trans(i)=(d2mm_dV2_trans(i-1)+dT/2*tau*(yyy(i)+yyy(i-1))-dT*tau*(yy(i)+yy2(i)).*dmm_dV_trans(i)...
            -dT*tau*(yy(i-1)+yy2(i-1))*dmm_dV_trans(i-1)-dT/2*tau*(yyy(i)+yyy2(i)).*mm_trans(i)...
            -dT/2*tau*(yyy(i-1)+yyy2(i-1)).*mm_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d2mm_dV2_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));
        
        d3mm_dV3_trans(i)=(d3mm_dV3_trans(i-1)+dT/2*tau*(yyyy(i)+yyyy(i-1))-3*dT/2*tau*(yyy(i)+yyy2(i)).*dmm_dV_trans(i)...
            -3*dT/2*tau*(yyy(i-1)+yyy2(i-1)).*dmm_dV_trans(i-1)-3*dT/2*tau*(yy(i)+yy2(i)).*d2mm_dV2_trans(i)...
            -3*dT/2*tau*(yy(i-1)+yy2(i-1)).*d2mm_dV2_trans(i-1)-dT/2*tau*(yyyy(i)+yyyy2(i)).*mm_trans(i)...
            -dT/2*tau*(yyyy(i-1)+yyyy2(i-1)).*mm_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d3mm_dV3_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));

   end;

      y=Q10*g0*(1-mm_trans);
      y2=Q10*g1*mm_trans.^3+3*g2*mm_trans.^2.*(1-mm_trans)+3*g3*mm_trans.*(1-mm_trans).^2;
    
    
     hh_trans=y./(y+y2);
     hh_trans(1)=0.8249;
 
%     y=Q10*alphah(pos,T,Er,a3,b3,c3,u0,up);
%     y2=Q10*betah(pos,T,Er,a4,b4,c4,u0,up);
    yy=Q10*dalphah(pos,T,Er,a3,b3,c3,u0,up);
    yy2=Q10*dbetah(pos,T,Er,a4,b4,c4,u0,up);
    yyy=Q10*d2alphah(pos,T,Er,a3,b3,c3,u0,up);
    yyy2=Q10*d2betah(pos,T,Er,a4,b4,c4,u0,up);
    yyyy=Q10*d3alphah(pos,T,Er,a3,b3,c3,u0,up);
    yyyy2=Q10*d3betah(pos,T,Er,a4,b4,c4,u0,up);

    
     UU=Phi(pos,T,u0,up);

%      hh_inf=1./(1+exp((UU*up+Er+65)/6.2));

     dhh_inf_dV=-exp((UU*up+Er+65)/6.2)*(up/6.2)./(1+exp((UU*up+Er+65)/6.2)).^2;

     d2hh_inf_dV2=2*exp(2*(UU*up+Er+65)/6.2)*(up/6.2).^2./(1+exp((UU*up+Er+65)/6.2)).^3 ...
         -exp((UU*up+Er+65)/6.2)*(up/6.2).^2./(1+exp((UU*up+Er+65)/6.2)).^2;

     d3hh_inf_dV3=-6*exp(3*(UU*up+Er+65)/6.2)*(up/6.2)^3./(1+exp((UU*up+Er+65)/6.2)).^4 ...
          +6*exp(2*(UU*up+Er+65)/6.2)*(up/6.2)^3./(1+exp((UU*up+Er+65)/6.2)).^3 ...
          -exp((UU*up+Er+65)/6.2)*(up/6.2)^3./(1+exp((UU*up+Er+65)/6.2)).^2;

     tau_hh=1./(y+y2);   

     dtau_hh_dV=-(yy+yy2)./(y+y2).^2;   

     d2tau_hh_dV2=2*(yy+yy2).^2./(y+y2).^3-(yyy+yyy2)./(y+y2).^2;   

     d3tau_hh_dV3=-6*(yy+yy2).^3./(y+y2).^4+6*(yy+yy2).*(yyy+yyy2)./(y+y2).^3 ...
                  -(yyyy+yyyy2)./(y+y2).^2;   

    
    hh_inf=y./(y+y2);

    hh_trans=zeros(size(T));
    hh_trans(1)=hh_inf(1);    
    dhh_dV_trans=zeros(size(T));
    dhh_dV_trans(1)=dhh_inf_dV(1); 
    d2hh_dV2_trans=zeros(size(T));
    d2hh_dV2_trans(1)=d2hh_inf_dV2(1); 
    d3hh_dV3_trans=zeros(size(T));
    d3hh_dV3_trans(1)=d3hh_inf_dV3(1); 
    
    
    
    for i=2:length(T)

      hh_trans(i)=(hh_trans(i-1)+dT/2*tau*hh_inf(i)/tau_hh(i)...
	  +dT/2*tau*(hh_inf(i-1)-hh_trans(i-1))/tau_hh(i-1))...
          /(1+dT*tau/(2*tau_hh(i)));
      
      dhh_dV_trans(i)=(dhh_dV_trans(i-1)+dT/2*tau*dhh_inf_dV(i)/tau_hh(i)...
           +dT/2*tau*((dhh_inf_dV(i-1)-dhh_dV_trans(i-1))/tau_hh(i-1))...
           -dT/2*tau*((hh_inf(i-1)-hh_trans(i-1))/(tau_hh(i-1).^2)).*dtau_hh_dV(i-1)...
	   -dT/2*tau*((hh_inf(i)-hh_trans(i))/(tau_hh(i).^2)).*dtau_hh_dV(i))...
         /(1+dT*tau/(2*tau_hh(i)));


      d2hh_dV2_trans(i)=(d2hh_dV2_trans(i-1)+dT/2*tau*d2hh_inf_dV2(i)/tau_hh(i)...
           +dT/2*tau*((d2hh_inf_dV2(i-1)-d2hh_dV2_trans(i-1))/tau_hh(i-1))...
           -dT*tau*((dhh_inf_dV(i)-dhh_dV_trans(i))/tau_hh(i).^2).*dtau_hh_dV(i)...
           -dT*tau*((dhh_inf_dV(i-1)-dhh_dV_trans(i-1))/tau_hh(i-1).^2).*dtau_hh_dV(i-1)...
	   -dT/2*tau*((hh_inf(i)-hh_trans(i))/tau_hh(i).^2).*d2tau_hh_dV2(i)...
           -dT/2*tau*((hh_inf(i-1)-hh_trans(i-1))/tau_hh(i-1).^2).*d2tau_hh_dV2(i-1)...
	   +dT*tau*((hh_inf(i)-hh_trans(i))/tau_hh(i).^3).*dtau_hh_dV(i).^2 ...
           +dT*tau*((hh_inf(i-1)-hh_trans(i-1))/tau_hh(i-1).^3).*dtau_hh_dV(i-1).^2)...
         /(1+dT*tau/(2*tau_hh(i)));


     d3hh_dV3_trans(i)=(d3hh_dV3_trans(i-1)+dT/2*tau*d3hh_inf_dV3(i)/tau_hh(i)...
           +dT/2*tau*((d3hh_inf_dV3(i-1)-d3hh_dV3_trans(i-1))/tau_hh(i-1))...
           -3*dT/2*tau*((d2hh_inf_dV2(i)-d2hh_dV2_trans(i))/tau_hh(i).^2).*dtau_hh_dV(i)...
           -3*dT/2*tau*((d2hh_inf_dV2(i-1)-d2hh_dV2_trans(i-1))/tau_hh(i).^2).*dtau_hh_dV(i-1)...
           -3*dT/2*tau*((dhh_inf_dV(i)-dhh_dV_trans(i))/tau_hh(i).^2).*d2tau_hh_dV2(i)...
           -3*dT/2*tau*((dhh_inf_dV(i-1)-dhh_dV_trans(i-1))/tau_hh(i-1).^2).*d2tau_hh_dV2(i-1)...
           +3*dT*tau*((dhh_inf_dV(i)-dhh_dV_trans(i))/tau_hh(i).^3).*dtau_hh_dV(i).^2 ...
           +3*dT*tau*((dhh_inf_dV(i-1)-dhh_dV_trans(i-1))/tau_hh(i-1).^3).*dtau_hh_dV(i-1).^2 ...
  	   -dT/2*tau*((hh_inf(i)-hh_trans(i))/tau_hh(i).^2).*d3tau_hh_dV3(i)...
  	   -dT/2*tau*((hh_inf(i-1)-hh_trans(i-1))/tau_hh(i-1).^2).*d3tau_hh_dV3(i-1)...
   	   +3*dT*tau*((hh_inf(i)-hh_trans(i))/tau_hh(i).^3).*d2tau_hh_dV2(i).*dtau_hh_dV(i)...
    	   +3*dT*tau*((hh_inf(i-1)-hh_trans(i-1))/tau_hh(i-1).^3).*d2tau_hh_dV2(i-1).*dtau_hh_dV(i-1)...
           -3*dT*tau*((dhh_inf_dV(i)-dhh_dV_trans(i))/tau_hh(i).^4).*dtau_hh_dV(i).^3 ...
           -3*dT*tau*((dhh_inf_dV(i-1)-dhh_dV_trans(i-1))/tau_hh(i-1).^4).*dtau_hh_dV(i-1).^3)...
         /(1+dT*tau/(2*tau_hh(i)));


    end;

    
    mm(ii,:)=mm_trans;
    dmm_dv(ii,:)=dmm_dV_trans;
    d2mm_dv2(ii,:)=d2mm_dV2_trans;
    d3mm_dv3(ii,:)=d3mm_dV3_trans;
    hh(ii,:)=hh_trans;
    dhh_dv(ii,:)=dhh_dV_trans;
    d2hh_dv2(ii,:)=d2hh_dV2_trans;
    d3hh_dv3(ii,:)=d3hh_dV3_trans;
    
end;

for ii=1:HotSpotNum_k
    
    pos=Xi_k(ii);

    y=Q10*alphan(pos,T,Er,a1_n,b1_n,c1_n,u0,up);
    y2=Q10*betan(pos,T,Er,a2_n,b2_n,c2_n,u0,up);
    yy=Q10*dalphan(pos,T,Er,a1_n,b1_n,c1_n,u0,up);
    yy2=Q10*dbetan(pos,T,Er,a2_n,b2_n,c2_n,u0,up);
    yyy=Q10*d2alphan(pos,T,Er,a1_n,b1_n,c1_n,u0,up);
    yyy2=Q10*d2betan(pos,T,Er,a2_n,b2_n,c2_n,u0,up);
    yyyy=Q10*d3alphan(pos,T,Er,a1_n,b1_n,c1_n,u0,up);
    yyyy2=Q10*d3betan(pos,T,Er,a2_n,b2_n,c2_n,u0,up);
    
    nnu(1)=y(1)/(y(1)+y2(1));
    vv(1)=(yy(1)-(yy(1)+yy2(1))*nnu(1))/(y(1)+y2(1));
    vv2(1)=(yyy(1)-2*vv(1)*(yy(1)+yy2(1))-nnu(1)*(yyy(1)+yyy2(1)))/(y(1)+y2(1));
    vv3(1)=(yyyy(1)-3*(yy(1)+yy2(1))*vv2(1)-3*(yyy(1)+yyy2(1))*vv(1)-(yyyy(1)+yyyy2(1))*nnu(1))/(y(1)+y2(1));
    
    nn_trans=zeros(size(T));
    dnn_dV_trans=zeros(size(t));
    dnn_dV_trans(1)=vv(1);
    d2nn_dV2_trans=zeros(size(t));
    d2nn_dV2_trans(1)=vv2(1);
    d3nn_dV3_trans=zeros(size(t));
    d3nn_dV3_trans(1)=vv3(1);

    nn_trans=zeros(size(T));
    nn_trans(1)=nnu(1);
    for i=2:length(T)
        nn_trans(i)=(nn_trans(i-1)+dT/2*tau*(y(i-1)+y(i))-dT/2*tau*(y(i-1)+y2(i-1))*nn_trans(i-1))/(1+dT/2*tau*(y(i)+y2(i)));
        
        dnn_dV_trans(i)=(dnn_dV_trans(i-1)+dT/2*tau*(yy(i-1)+yy(i))-dT/2*tau*(yy(i-1)+yy2(i-1))*nn_trans(i-1)...
       -dT/2*tau*(yy(i)+yy2(i))*nn_trans(i)-dT/2*tau*(y(i)+y2(i)).*dnn_dV_trans(i-1))/...
       (1+dT/2*tau*(y(i)+y2(i)));
   
        d2nn_dV2_trans(i)=(d2nn_dV2_trans(i-1)+dT/2*tau*(yyy(i)+yyy(i-1))-dT*tau*(yy(i)+yy2(i)).*dnn_dV_trans(i)...
            -dT*tau*(yy(i-1)+yy2(i-1))*dnn_dV_trans(i-1)-dT/2*tau*(yyy(i)+yyy2(i)).*nn_trans(i)...
            -dT/2*tau*(yyy(i-1)+yyy2(i-1)).*nn_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d2nn_dV2_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));
        
        d3nn_dV3_trans(i)=(d3nn_dV3_trans(i-1)+dT/2*tau*(yyyy(i)+yyyy(i-1))-3*dT/2*tau*(yyy(i)+yyy2(i)).*dnn_dV_trans(i)...
            -3*dT/2*tau*(yyy(i-1)+yyy2(i-1)).*dnn_dV_trans(i-1)-3*dT/2*tau*(yy(i)+yy2(i)).*d2nn_dV2_trans(i)...
            -3*dT/2*tau*(yy(i-1)+yy2(i-1)).*d2nn_dV2_trans(i-1)-dT/2*tau*(yyyy(i)+yyyy2(i)).*nn_trans(i)...
            -dT/2*tau*(yyyy(i-1)+yyyy2(i-1)).*nn_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d3nn_dV3_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));

    end;

    nn(ii,:)=nn_trans;
    dnn_dv(ii,:)=dnn_dV_trans;
    d2nn_dv2(ii,:)=d2nn_dV2_trans;
    d3nn_dv3(ii,:)=d3nn_dV3_trans;

end;

% plot(T,Fna(UUi,up,Phi_na,Omega,mm,hh))
% figure;
%f=quadg('integrand1',0,1,1e-6,1,0,0.2,Xi(1),u0,up,UUi,Phi_na,Omega,mm,hh);

Xi_mu=[Xi_na Xi_k];

for jj=1:HotSpotNum_na+HotSpotNum_k

f1_na=zeros(size(T));

for ii=1:HotSpotNum_na
%     zz1=fft(G(Xi_mu(jj),Xi_na(ii),T));
    zz1=G(Xi_mu(jj),Xi_na(ii),T);
    UU=Phi(Xi_na(ii),T,u0,up);
    
%     zz1_na=fft(FnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:)));
%     zz_na=dT*real(ifft(zz1.*zz1_na));
    zz1_na=FnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:));
%     zz_na=dT*conv(zz1,zz1_na);
    zz_na=dT*conv2(zz1,zz1_na);
    zz_na=zz_na(1:length(t));
    
    f1_na=f1_na+Gna(ii)*Rm/lambda*zz_na;
end;

f1_k=zeros(size(T));

for pp=1:HotSpotNum_k
%     zz1=fft(G(Xi_mu(jj),Xi_k(pp),T));
    zz1=G(Xi_mu(jj),Xi_k(pp),T);
    UU=Phi(Xi_k(pp),T,u0,up);

%     zz1_k=fft(FkHH(UU+Er/up,up,Phi_k,nn(pp,:)));
%     zz_k=dT*real(ifft(zz1.*zz1_k));

    zz1_k=FkHH(UU+Er/up,up,Phi_k,nn(pp,:));
    zz_k=dT*conv2(zz1,zz1_k);
    zz_k=zz_k(1:length(t));
    
    f1_k=f1_k+Gk(pp)*(Rm/lambda)*zz_k;

end;
Phi1(jj,:)=f1_na+f1_k;
end;

for jj=1:HotSpotNum_na+HotSpotNum_k

f2_na=zeros(size(T));

for ii=1:HotSpotNum_na
%     zz1=fft(G(Xi_mu(jj),Xi_na(ii),T));
    zz1=G(Xi_mu(jj),Xi_na(ii),T);
    UU=Phi(Xi_na(ii),T,u0,up);
    
%     zz2_na=fft(DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi1(ii,:));
%     zz2=dT*real(ifft(zz1.*zz2_na));

    zz2_na=DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi1(ii,:);
%     zz2=dT*conv(zz1,zz2_na);
    zz2=dT*conv2(zz1,zz2_na);
    zz2=zz2(1:length(t));

    f2_na=f2_na+Gna(ii)*Rm/lambda*zz2;

end;

f2_k=zeros(size(T));

for pp=1:HotSpotNum_k
    zz1=fft(G(Xi_mu(jj),Xi_k(pp),T));
    UU=Phi(Xi_k(pp),T,u0,up);

    zz2_k=fft(DFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:)).*Phi1(ii+pp,:));
    zz2_k=dT*real(ifft(zz1.*zz2_k));
    f2_k=f2_k+Gk(pp)*(Rm/lambda)*zz2_k;

end;
Phi2(jj,:)=f2_na+f2_k;
end;

for jj=1:HotSpotNum_na+HotSpotNum_k

f3_na=zeros(size(T));

for ii=1:HotSpotNum_na
%     zz1=fft(G(Xi_mu(jj),Xi_na(ii),T));
    zz1=G(Xi_mu(jj),Xi_na(ii),T);
    UU=Phi(Xi_na(ii),T,u0,up);
    
%     zz3_na=fft(DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi2(ii,:) ...
%         +1/2*DDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).^2);
%     zz3=dT*real(ifft(zz1.*zz3_na));

    zz3_na=DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi2(ii,:) ...
        +1/2*DDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).^2;
%     zz3=dT*conv(zz1,zz3_na);
    zz3=dT*conv2(zz1,zz3_na);
    zz3=zz3(1:length(t));

    f3_na=f3_na+Gna(ii)*Rm/lambda*zz3;
end;

f3_k=zeros(size(T));

for pp=1:HotSpotNum_k
    zz1=fft(G(Xi_mu(jj),Xi_k(pp),T));
    UU=Phi(Xi_k(pp),T,u0,up);

    zz3_kk=fft(DFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:)).*Phi2(pp+ii,:) ...
        +1/2*DDFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(pp+ii,:).^2);
    zz3_k=dT*real(ifft(zz1.*zz3_kk));
    f3_k=f3_k+Gk(pp)*Rm/lambda*zz3_k;
  
end;
Phi3(jj,:)=f3_na+f3_k;
end;

for jj=1:HotSpotNum_na+HotSpotNum_k

f4_na=zeros(size(T));

for ii=1:HotSpotNum_na
%     zz1=fft(G(Xi_mu(jj),Xi_na(ii),T));
    zz1=G(Xi_mu(jj),Xi_na(ii),T);
    UU=Phi(Xi_na(ii),T,u0,up);
    
%     zz4_na=fft(DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi3(ii,:)...
%         +DDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).*Phi2(ii,:)...
%         +1/6*DDDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:),d3mm_dv3(ii,:),d3hh_dv3(ii,:)).*Phi1(ii,:).^3);
%     zz4=dT*real(ifft(zz1.*zz4_na));

    zz4_na=DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi3(ii,:)...
        +DDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).*Phi2(ii,:)...
        +1/6*DDDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:),d3mm_dv3(ii,:),d3hh_dv3(ii,:)).*Phi1(ii,:).^3;
%     zz4=dT*conv(zz1,zz4_na);
    zz4=dT*conv2(zz1,zz4_na);
    zz4=zz4(1:length(t));

    f4_na=f4_na+Gna(ii)*Rm/lambda*zz4;
end;

f4_k=zeros(size(T));

for pp=1:HotSpotNum_k
    zz1=fft(G(Xi_mu(jj),Xi_k(pp),T));
    UU=Phi(Xi_k(pp),T,u0,up);

    zz4_kk=fft(DFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:)).*Phi3(ii+pp,:) ...
        +DDFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).*Phi2(ii+pp,:) ...
        +1/6*DDDFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:),d3nn_dv3(pp,:)).*Phi1(ii+pp,:).^3);
    zz4_k=dT*real(ifft(zz1.*zz4_kk));
    f4_k=f4_k+Gk(pp)*Rm/lambda*zz4_k;
end;
Phi4(jj,:)=f4_na+f4_k;
end;

%Xpos=267e-4/lambda;
%Xpos=Xi_na(1);

Xpos=[100e-4/lambda 200e-4/lambda 300e-4/lambda];

for xx=1:length(Xpos)

f1_na=zeros(size(T));
f2_na=zeros(size(T));
f3_na=zeros(size(T));
f4_na=zeros(size(T));

f1_k=zeros(size(T));
f2_k=zeros(size(T));
f3_k=zeros(size(T));
f4_k=zeros(size(T));

for ii=1:HotSpotNum_na
%     zz1=fft(G(Xpos,Xi_na(ii),T));
    zz1=G(Xpos(xx),Xi_na(ii),T);
    UU=Phi(Xi_na(ii),T,u0,up);
    
%     zz1_na=fft(FnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:)));
%     zz_na=dT*real(ifft(zz1.*zz1_na));

    zz1_na=FnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:));
%     zz_na=dT*conv(zz1,zz1_na);
    zz_na=dT*conv2(zz1,zz1_na);
    zz_na=zz_na(1:length(t));

    f1_na=f1_na+Gna(ii)*Rm/lambda*zz_na;

%     zz2_na=fft(DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi1(ii,:));
%     zz2=dT*real(ifft(zz1.*zz2_na));

    zz2_na=DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi1(ii,:);
%     zz2=dT*conv(zz1,zz2_na);
    zz2=dT*conv2(zz1,zz2_na);
    zz2=zz2(1:length(t));
    
    f2_na=f2_na+Gna(ii)*Rm/lambda*zz2;

%     zz3_na=fft(DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi2(ii,:) ...
%         +1/2*DDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).^2);
%     zz3=dT*real(ifft(zz1.*zz3_na));

    zz3_na=DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi2(ii,:) ...
        +1/2*DDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).^2;
%     zz3=dT*conv(zz1,zz3_na);
    zz3=dT*conv2(zz1,zz3_na);
    zz3=zz3(1:length(t));

    f3_na=f3_na+Gna(ii)*Rm/lambda*zz3;

%     zz4_na=fft(DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi3(ii,:)...
%         +DDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).*Phi2(ii,:)...
%         +1/6*DDDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:),d3mm_dv3(ii,:),d3hh_dv3(ii,:)).*Phi1(ii,:).^3);
%     zz4=dT*real(ifft(zz1.*zz4_na));

    zz4_na=DFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi3(ii,:)...
        +DDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).*Phi2(ii,:)...
        +1/6*DDDFnaHH(UU+Er/up,up,Phi_na,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:),d3mm_dv3(ii,:),d3hh_dv3(ii,:)).*Phi1(ii,:).^3;
%     zz4=dT*conv(zz1,zz4_na);
    zz4=dT*conv2(zz1,zz4_na);
    zz4=zz4(1:length(t));

    f4_na=f4_na+Gna(ii)*Rm/lambda*zz4;
end;


for pp=1:HotSpotNum_k
%     zz1=fft(G(Xpos,Xi_k(pp),T));
    zz1=G(Xpos(xx),Xi_k(pp),T);
    UU=Phi(Xi_k(pp),T,u0,up);
    
%     zz1_k=fft(FkHH(UU+Er/up,up,Phi_k,nn(pp,:)));
%     zz_k=dT*real(ifft(zz1.*zz1_k));

     zz1_k=FkHH(UU+Er/up,up,Phi_k,nn(pp,:));
     zz_k=dT*conv2(zz1,zz1_k);
     zz_k=zz_k(1:length(t));
     
     f1_k=f1_k+Gk(pp)*(Rm/lambda)*zz_k;
    
%     zz2_kk=fft(DFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:)).*Phi1(ii+pp,:));
%     zz2_k=dT*real(ifft(zz1.*zz2_kk));
%     f2_k=f2_k+Gk(pp)*Rm/lambda*zz2_k;
%     
%     zz3_kk=fft(DFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:)).*Phi2(ii+pp,:) ...
%         +1/2*DDFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).^2);
%     zz3_k=dT*real(ifft(zz1.*zz3_kk));
%     f3_k=f3_k+Gk(pp)*Rm/lambda*zz3_k;
%   
%     zz4_kk=fft(DFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:)).*Phi3(ii+pp,:)...
%         +DDFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).*Phi2(ii+pp,:)...
%         +1/6*DDDFkHH(UU+Er/up,up,Phi_k,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:),d3nn_dv3(pp,:)).*Phi1(ii+pp,:).^3);
%     zz4_k=dT*real(ifft(zz1.*zz4_kk));
%     f4_k=f4_k+Gk(pp)*Rm/lambda*zz4_k;
    
end;

epsilon=0.03;
Phi_VV1(xx,:)=up*(Phi(Xpos(xx),T,u0,up)+epsilon*f1_na+epsilon*f1_k);
epsilon=0.03;
Phi_VV2(xx,:)=up*(Phi(Xpos(xx),T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon*f1_k+epsilon^2*f2_k);
epsilon=0.03;
Phi_VV3(xx,:)=up*(Phi(Xpos(xx),T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k);
epsilon=0.03;
Phi_VV4(xx,:)=up*(Phi(Xpos(xx),T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon^4*f4_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k+epsilon^4*f4_k);

end;


plot(T,f1_na,T,f2_na,'r',T,f3_na,'g',T,f4_na,'c');
figure;
plot(T,f1_k,T,f2_k,'c',T,f3_k,'g',T,f4_k,'r');
figure;
plot(T,up*(Phi(Xpos,T,u0,up)+f1_na+f2_na+f3_na+f4_na),'g',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
plot(T,up*(Phi(Xpos,T,u0,up)+f1_k+f2_k+f3_k+f4_k),'b',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
plot(T,up*(f1_na+f2_na+f3_na+f4_na+f1_k+f2_k+f3_k+f4_k),'b',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
epsilon=0.01;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon^4*f4_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k+epsilon^4*f4_k),'b',T,up*(Phi(Xpos,T,u0,up)+f1_na),'y',T,up*f1_na,'c',T,up*f1_k,'g',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
epsilon=0.01;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon*f1_k),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;
figure;
epsilon=0.01;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon*f1_k+epsilon^2*f2_k),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;
figure;
epsilon=0.01;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;
figure;
epsilon=0.01;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon^4*f4_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k+epsilon^4*f4_k),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;

%integrand1(s,t,ss,x,xi,u0,up,Una,Omega,mm,hh);
