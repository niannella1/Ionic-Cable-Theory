function [ret] = dtauh(x,t,Er,a1,b1,c1,u0,up)

ret = zeros(size(t));

ret =-(dalphah(x,t,Er,a1,b1,c1,u0,up)+dbetah(x,t,Er,a1,b1,c1,u0,up))./(alphah(x,t,Er,a1,b1,c1,u0,up)+betah(x,t,Er,a1,b1,c1,u0,up)).^2;
