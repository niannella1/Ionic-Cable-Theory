function [ret] = d2betah(x,t,Er,a2,b2,c2,u0,up)

idx=find(abs((Phi(x,t,u0,up)*up+Er-b2)/c2)<1e-6);
idx2=find(abs((Phi(x,t,u0,up)*up+Er-b2)/c2)>=1e-6);

ret = zeros(size(t));

if (isempty(nonzeros(idx2))==0)

    ret(idx2) = -2*a2*up^2/c2*exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)./(1-exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)).^2 ...
        -a2*up^2/c2^2*(Phi(x,t(idx2),u0,up)*up+Er-b2).*(...
                        2*exp(2*(Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)./(1-exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)).^3 ...
                        +exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)./(1-exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)).^2);
    ret(idx) = a2*up^2/(6*c2);
    
else
    
    ret(idx) = a2*up^2/(6*c2);
    
end;

