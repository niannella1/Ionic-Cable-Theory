function [ret] = DDDFkaHH(UU,Up,Uka,mm,hh,Dmm_dUU,Dhh_dUU,D2mm_dUU2,D2hh_dUU2,D3mm_dUU3,D3hh_dUU3)

% Una - refers to Phi_{na} note that Phi_{na}U_{peak} 
% is the sodium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = 3*(-8*mm.^3.*Dmm_dUU.*Dhh_dUU-mm.^4.*D2hh_dUU2-hh.*(12*mm.^2.*Dmm_dUU.^2+4*mm.^3.*D2mm_dUU2))...
    +(Uka-UU).*(12*mm.^3.*Dmm_dUU.*D2hh_dUU2+3*Dhh_dUU.*(12*mm.^2.*Dmm_dUU.^2+4*mm.^3.*D2mm_dUU2)...
    +mm.^4.*D3hh_dUU3+hh.*(24*mm.*Dmm_dUU.^3+36*mm.^2.*Dmm_dUU.*D2mm_dUU2+4*mm.^3.*D3mm_dUU3));
