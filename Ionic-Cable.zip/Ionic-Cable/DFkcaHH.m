function [ret] = DFkcaHH(UU,Up,Ukca,mm,Dmm_dUU)

% Ukca - refers to Phi_{kca} note that Phi_{kca}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

ret = -mm+Dmm_dUU.*(Ukca-UU);
