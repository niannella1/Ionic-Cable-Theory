function [ret] = d3beta_hvam(x,t,Er,a2,b2,c2,u0,up)

idx=find(abs((Phi(x,t,u0,up)*up+Er-b2)/c2)<1e-6);
idx2=find(abs((Phi(x,t,u0,up)*up+Er-b2)/c2)>=1e-6);

ret = zeros(size(t));

if (isempty(nonzeros(idx2))==0)

    ret(idx2) = -3*a2*(up^3/c2^2)*(...
        2*exp(2*(Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)./(1-exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)).^3 ...
        +exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)./(1-exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)).^2)...
...
        -a2*(up^3/c2^3)*(Phi(x,t(idx2),u0,up)*up+Er-b2).*(...
            6*exp(3*(Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)./(1-exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)).^4 ...
            + 6*exp(2*(Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)./(1-exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)).^3 ...
            + exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)./(1-exp((Phi(x,t(idx2),u0,up)*up+Er-b2)/c2)).^2);
    
else
    
    ret(idx) = 0;
    
end;

