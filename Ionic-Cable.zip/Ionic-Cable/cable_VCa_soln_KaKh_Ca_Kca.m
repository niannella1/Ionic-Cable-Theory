clear; close all;

% % Mainen parameters - Na
a1=0.182;
b1=-35;
c1=9;
a2=0.124;
b2=-35;
c2=9;
Er=0;

a3=0.024;
b3=-50;
c3=5;
a4=0.0091;
b4=-75;
c4=5;

% Mainen parameters - K
a1_n=0.02;
b1_n=20;
c1_n=9;
a2_n=0.002;
b2_n=20;
c2_n=9;

% Migliore Ka
% Activation variable m
a1_ka=1;
b1_ka=79.7;
c1_ka=12.7;
a2_ka=1;
b2_ka=35.8;
c2_ka=19.7;

% Inactivation variable m
a3_ka=1;
b3_ka=238;
c3_ka=37.5;
a4_ka=1;
b4_ka=46;
c4_ka=5;

% Traub h-current
% Activation variable m
a1_kh=1;
b1_kh=4.6/0.086;
c1_kh=1/0.086;
a2_kh=1;
b2_kh=-1.87/0.07;
c2_kh=1/0.07;

% Traub HVA calcium current
% Activation variable m
a1_hva=1.6;
b1_hva=5;
c1_hva=1/0.072;
a2_hva=0.02;
b2_hva=-8.9;
c2_hva=5;

% Traub KCa BK current
% Activation variable m
a1_kca=0.053;
b1_kca=50;
c1_kca=11;
a2_kca=2;
b2_kca=53.5;
c2_kca=27;

%Frankenhaeuser-Huxley parameters

% a1=0.36;
% b1=22;
% c1=3;
% a2=0.4;
% b2=13;
% c2=20;
% Er=0;
% 
% a3=0.1;
% b3=-10;
% c3=6;
% a4=4.5;
% b4=45;
% c4=10;
%  
% a1_n=0.02;
% b1_n=35;
% c1_n=10;
% a2_n=0.05;
% b2_n=10;
% c2_n=10;

% a1=0.5;
% b1=-70;
% c1=0.00001;
% a2=0.05;
% b2=-70;
% c2=0.01;
% Er=-80;
% 
% a3=0.6;
% b3=-70;
% c3=10.0;
g0=0.8;
g1=1.0; % 1/msec
g2=1/2.3; % 1/msec
g3=1/4; % 1/msec
Vna=55;
Vk=-100;
Vka=Vk;
Vkh=-35;
Vkca=Vk;
Vca=125;
u0=5.12;
up=88.38928681566553; %1;

mu0=0.0005;
Rm=25000; %units of  ohm cm^2
Ri=200; %units of ohm cm
Cm=0.9e-3; %units of mF/cm^2 corresponds to 0.9e-6 F/cm^2
tau=Rm*Cm; %units of msec
diam=1e-4; %units of cm
lambda=sqrt(Rm*diam/(4*Ri)); %units of cm

T=linspace(0,3,1000); %dimensionless time
dT=(T(2)-T(1));
t=T*tau; % msec
dt=t(2)-t(1);

LL=1000; %um
L=LL*1e-4; %units of cm
x=linspace(0,L,100); %units of cm
X=x/lambda; %dimensionless or electrotonic distance

HotSpotNum_na=10;

Num_of_chans_na=174.5;
Ina_chan_dens=Num_of_chans_na*ones(1,HotSpotNum_na)/(pi*diam); 

gna=18e-12; %units of S, maximum attainable conductance of 18pS for a single Na channel refs [100,107] in Poz

Gna=gna*Ina_chan_dens; %units of S/cm

Xin_na=L/lambda;  %position of last hotspot in units of dimensionless distance
Xi0_na=0.05; %position of first hotspot in units of dimensionless distance

% Xin_na=267e-4/lambda;  %position of last hotspot in units of dimensionless distance
% Xi0_na=Xin_na/HotSpotNum_na; %position of first hotspot in units of dimensionless distance

Xi_na=linspace(Xi0_na,Xin_na,HotSpotNum_na); %Positions of hotspots in units of dimensionless distance

Phi_na=Vna/up;

HotSpotNum_k=10;

Num_of_chans_k=125.6;%18*2.5;
Ik_chan_dens=Num_of_chans_k*ones(1,HotSpotNum_k)/(pi*diam); 

gk=20e-12; %units of S, maximum attainable conductance of 18pS for a single Na channel refs [100,107] in Poz

Gk=gk*Ik_chan_dens; %units of S/cm

Xin_k=L/lambda;  %position of last hotspot in units of dimensionless distance
Xi0_k=0.05;

% Xin_k=267e-4/lambda;  %position of last hotspot in units of dimensionless distance
% Xi0_k=Xin_k/HotSpotNum_k; %position of first hotspot in units of dimensionless distance

Xi_k=linspace(Xi0_k,Xin_k,HotSpotNum_k); %Positions of hotspots in units of dimensionless distance

Phi_k=Vk/up;

HotSpotNum_ka=10;

Num_of_chans_ka=60;%18*2.5;
Ika_chan_dens=Num_of_chans_ka*ones(1,HotSpotNum_ka)/(pi*diam); 

gka=20e-12; %units of S, maximum attainable conductance of 18pS for a single Na channel refs [100,107] in Poz

Gka=gka*Ika_chan_dens; %units of S/cm

Xin_ka=L/lambda;  %position of last hotspot in units of dimensionless distance
Xi0_ka=0.05;

% Xin_ka=267e-4/lambda;  %position of last hotspot in units of dimensionless distance
% Xi0_ka=Xin_ka/HotSpotNum_ka; %position of first hotspot in units of dimensionless distance

Xi_ka=linspace(Xi0_ka,Xin_ka,HotSpotNum_ka); %Positions of hotspots in units of dimensionless distance

Phi_ka=Vka/up;

HotSpotNum_kh=10;

Num_of_chans_kh=10;%18*2.5;
Ikh_chan_dens=Num_of_chans_kh*ones(1,HotSpotNum_kh)/(pi*diam); 

gkh=20e-12; %units of S, maximum attainable conductance of 18pS for a single Na channel refs [100,107] in Poz

Gkh=gkh*Ikh_chan_dens; %units of S/cm

Xin_kh=L/lambda;  %position of last hotspot in units of dimensionless distance
Xi0_kh=0.05;

% Xin_kh=267e-4/lambda;  %position of last hotspot in units of dimensionless distance
% Xi0_kh=Xin_kh/HotSpotNum_kh; %position of first hotspot in units of dimensionless distance

Xi_kh=linspace(Xi0_kh,Xin_kh,HotSpotNum_kh); %Positions of hotspots in units of dimensionless distance

Phi_kh=Vkh/up;

% High Voltage Calcium

HotSpotNum_hva=10;

Num_of_chans_hva=62.8;%18*2.5;
Ihva_chan_dens=Num_of_chans_hva*ones(1,HotSpotNum_hva)/(pi*diam); 

ghva=20e-12; %units of S, maximum attainable conductance of 18pS for a single Na channel refs [100,107] in Poz

Ghva=ghva*Ihva_chan_dens; %units of S/cm

Xin_hva=L/lambda;  %position of last hotspot in units of dimensionless distance
Xi0_hva=0.01;

% Xin_kh=267e-4/lambda;  %position of last hotspot in units of dimensionless distance
% Xi0_kh=Xin_kh/HotSpotNum_kh; %position of first hotspot in units of dimensionless distance

Xi_hva=linspace(Xi0_hva,Xin_hva,HotSpotNum_hva); %Positions of hotspots in units of dimensionless distance

Phi_ca=Vca/up;

% BK potassium channel

HotSpotNum_kca=10;

Num_of_chans_kca=10;%18*2.5;
Ikca_chan_dens=Num_of_chans_kca*ones(1,HotSpotNum_kca)/(pi*diam); 

gkca=180e-12; %units of S, maximum attainable conductance of 18pS for a single Na channel refs [100,107] in Poz

Gkca=gkca*Ikca_chan_dens; %units of S/cm

Xin_kca=L/lambda;  %position of last hotspot in units of dimensionless distance
Xi0_kca=0.05;

% Xin_kca=267e-4/lambda;  %position of last hotspot in units of dimensionless distance
% Xi0_kca=Xin_kca/HotSpotNum_kca; %position of first hotspot in units of dimensionless distance

Xi_kca=linspace(Xi0_kca,Xin_kca,HotSpotNum_kca); %Positions of hotspots in units of dimensionless distance

Phi_kca=Vkca/up;

F=96480; % Faradays constant Coulomb/mol
R=8.315; % Gas constant J/K/mol
Temp=23; % degC
absT=273.15+Temp; % Absolute temperature K
Omega=F/(R*absT*1000); % units of 1/mV

pow=((Temp-23)/10);
Q10=2.3^pow;

% Mainen type sodium channel

for ii=1:HotSpotNum_na
    
    pos=Xi_na(ii);

    y=Q10*alpham(pos,T,Er,a1,b1,c1,u0,up);
    y2=Q10*betam(pos,T,Er,a2,b2,c2,u0,up);
    yy=Q10*dalpham(pos,T,Er,a1,b1,c1,u0,up);
    yy2=Q10*dbetam(pos,T,Er,a2,b2,c2,u0,up);
    yyy=Q10*d2alpham(pos,T,Er,a1,b1,c1,u0,up);
    yyy2=Q10*d2betam(pos,T,Er,a2,b2,c2,u0,up);
    yyyy=Q10*d3alpham(pos,T,Er,a1,b1,c1,u0,up);
    yyyy2=Q10*d3betam(pos,T,Er,a2,b2,c2,u0,up);

    mmu(1)=y(1)/(y(1)+y2(1));
    vv(1)=(yy(1)-(yy(1)+yy2(1))*mmu(1))/(y(1)+y2(1));
    vv2(1)=(yyy(1)-2*vv(1)*(yy(1)+yy2(1))-mmu(1)*(yyy(1)+yyy2(1)))/(y(1)+y2(1));
    vv3(1)=(yyyy(1)-3*(yy(1)+yy2(1))*vv2(1)-3*(yyy(1)+yyy2(1))*vv(1)-(yyyy(1)+yyyy2(1))*mmu(1))/(y(1)+y2(1));
    
    mm_trans=zeros(size(T));
    mm_trans(1)=mmu(1);
    dmm_dV_trans=zeros(size(t));
    dmm_dV_trans(1)=vv(1);
    d2mm_dV2_trans=zeros(size(t));
    d2mm_dV2_trans(1)=vv2(1);
    d3mm_dV3_trans=zeros(size(t));
    d3mm_dV3_trans(1)=vv3(1);
    
    for i=2:length(T)
        mm_trans(i)=(mm_trans(i-1)+dT/2*tau*(y(i-1)+y(i))-dT/2*tau*(y(i-1)+y2(i-1))*mm_trans(i-1))/(1+dT/2*tau*(y(i)+y2(i)));
       
        dmm_dV_trans(i)=(dmm_dV_trans(i-1)+dT/2*tau*(yy(i-1)+yy(i))-dT/2*tau*(yy(i-1)+yy2(i-1))*mm_trans(i-1)...
       -dT/2*tau*(yy(i)+yy2(i))*mm_trans(i)-dT/2*tau*(y(i)+y2(i)).*dmm_dV_trans(i-1))/...
       (1+dT/2*tau*(y(i)+y2(i)));
   
        d2mm_dV2_trans(i)=(d2mm_dV2_trans(i-1)+dT/2*tau*(yyy(i)+yyy(i-1))-dT*tau*(yy(i)+yy2(i)).*dmm_dV_trans(i)...
            -dT*tau*(yy(i-1)+yy2(i-1))*dmm_dV_trans(i-1)-dT/2*tau*(yyy(i)+yyy2(i)).*mm_trans(i)...
            -dT/2*tau*(yyy(i-1)+yyy2(i-1)).*mm_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d2mm_dV2_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));
        
        d3mm_dV3_trans(i)=(d3mm_dV3_trans(i-1)+dT/2*tau*(yyyy(i)+yyyy(i-1))-3*dT/2*tau*(yyy(i)+yyy2(i)).*dmm_dV_trans(i)...
            -3*dT/2*tau*(yyy(i-1)+yyy2(i-1)).*dmm_dV_trans(i-1)-3*dT/2*tau*(yy(i)+yy2(i)).*d2mm_dV2_trans(i)...
            -3*dT/2*tau*(yy(i-1)+yy2(i-1)).*d2mm_dV2_trans(i-1)-dT/2*tau*(yyyy(i)+yyyy2(i)).*mm_trans(i)...
            -dT/2*tau*(yyyy(i-1)+yyyy2(i-1)).*mm_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d3mm_dV3_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));

   end;

%       y=Q10*g0*(1-mm_trans);
%       y2=Q10*g1*mm_trans.^3+3*g2*mm_trans.^2.*(1-mm_trans)+3*g3*mm_trans.*(1-mm_trans).^2;
    
    
%     hh_trans=y./(y+y2);
%     hh_trans(1)=0.8249;
 
    y=Q10*alphah(pos,T,Er,a3,b3,c3,u0,up);
    y2=Q10*betah(pos,T,Er,a4,b4,c4,u0,up);
    yy=Q10*dalphah(pos,T,Er,a3,b3,c3,u0,up);
    yy2=Q10*dbetah(pos,T,Er,a4,b4,c4,u0,up);
    yyy=Q10*d2alphah(pos,T,Er,a3,b3,c3,u0,up);
    yyy2=Q10*d2betah(pos,T,Er,a4,b4,c4,u0,up);
    yyyy=Q10*d3alphah(pos,T,Er,a3,b3,c3,u0,up);
    yyyy2=Q10*d3betah(pos,T,Er,a4,b4,c4,u0,up);


    
     UU=Phi(pos,T,u0,up);

     hh_inf=1./(1+exp((UU*up+Er+65)/6.2));

     dhh_inf_dV=-exp((UU*up+Er+65)/6.2)*(up/6.2)./(1+exp((UU*up+Er+65)/6.2)).^2;

     d2hh_inf_dV2=2*exp(2*(UU*up+Er+65)/6.2)*(up/6.2).^2./(1+exp((UU*up+Er+65)/6.2)).^3 ...
         -exp((UU*up+Er+65)/6.2)*(up/6.2).^2./(1+exp((UU*up+Er+65)/6.2)).^2;

     d3hh_inf_dV3=-6*exp(3*(UU*up+Er+65)/6.2)*(up/6.2)^3./(1+exp((UU*up+Er+65)/6.2)).^4 ...
          +6*exp(2*(UU*up+Er+65)/6.2)*(up/6.2)^3./(1+exp((UU*up+Er+65)/6.2)).^3 ...
          -exp((UU*up+Er+65)/6.2)*(up/6.2)^3./(1+exp((UU*up+Er+65)/6.2)).^2;

     tau_hh=1./(y+y2);   

     dtau_hh_dV=-(yy+yy2)./(y+y2).^2;   

     d2tau_hh_dV2=2*(yy+yy2).^2./(y+y2).^3-(yyy+yyy2)./(y+y2).^2;   

     d3tau_hh_dV3=-6*(yy+yy2).^3./(y+y2).^4+6*(yy+yy2).*(yyy+yyy2)./(y+y2).^3 ...
                  -(yyyy+yyyy2)./(y+y2).^2;   

    
%     hh_inf=y./(y+y2);
%     hh_trans(1)=y(1)/(y(1)+y2(1)); 

    hh_trans=zeros(size(T));
    hh_trans(1)=hh_inf(1);    
    dhh_dV_trans=zeros(size(T));
    dhh_dV_trans(1)=dhh_inf_dV(1); 
    d2hh_dV2_trans=zeros(size(T));
    d2hh_dV2_trans(1)=d2hh_inf_dV2(1); 
    d3hh_dV3_trans=zeros(size(T));
    d3hh_dV3_trans(1)=d3hh_inf_dV3(1); 
    
    
    
    for i=2:length(T)

      hh_trans(i)=(hh_trans(i-1)+dT/2*tau*hh_inf(i)/tau_hh(i)...
	  +dT/2*tau*(hh_inf(i-1)-hh_trans(i-1))/tau_hh(i-1))...
          /(1+dT*tau/(2*tau_hh(i)));
      
      dhh_dV_trans(i)=(dhh_dV_trans(i-1)+dT/2*tau*dhh_inf_dV(i)/tau_hh(i)...
           +dT/2*tau*((dhh_inf_dV(i-1)-dhh_dV_trans(i-1))/tau_hh(i-1))...
           -dT/2*tau*((hh_inf(i-1)-hh_trans(i-1))/(tau_hh(i-1).^2)).*dtau_hh_dV(i-1)...
	   -dT/2*tau*((hh_inf(i)-hh_trans(i))/(tau_hh(i).^2)).*dtau_hh_dV(i))...
         /(1+dT*tau/(2*tau_hh(i)));


      d2hh_dV2_trans(i)=(d2hh_dV2_trans(i-1)+dT/2*tau*d2hh_inf_dV2(i)/tau_hh(i)...
           +dT/2*tau*((d2hh_inf_dV2(i-1)-d2hh_dV2_trans(i-1))/tau_hh(i-1))...
           -dT*tau*((dhh_inf_dV(i)-dhh_dV_trans(i))/tau_hh(i).^2).*dtau_hh_dV(i)...
           -dT*tau*((dhh_inf_dV(i-1)-dhh_dV_trans(i-1))/tau_hh(i-1).^2).*dtau_hh_dV(i-1)...
	   -dT/2*tau*((hh_inf(i)-hh_trans(i))/tau_hh(i).^2).*d2tau_hh_dV2(i)...
           -dT/2*tau*((hh_inf(i-1)-hh_trans(i-1))/tau_hh(i-1).^2).*d2tau_hh_dV2(i-1)...
	   +dT*tau*((hh_inf(i)-hh_trans(i))/tau_hh(i).^3).*dtau_hh_dV(i).^2 ...
           +dT*tau*((hh_inf(i-1)-hh_trans(i-1))/tau_hh(i-1).^3).*dtau_hh_dV(i-1).^2)...
         /(1+dT*tau/(2*tau_hh(i)));


     d3hh_dV3_trans(i)=(d3hh_dV3_trans(i-1)+dT/2*tau*d3hh_inf_dV3(i)/tau_hh(i)...
           +dT/2*tau*((d3hh_inf_dV3(i-1)-d3hh_dV3_trans(i-1))/tau_hh(i-1))...
           -3*dT/2*tau*((d2hh_inf_dV2(i)-d2hh_dV2_trans(i))/tau_hh(i).^2).*dtau_hh_dV(i)...
           -3*dT/2*tau*((d2hh_inf_dV2(i-1)-d2hh_dV2_trans(i-1))/tau_hh(i).^2).*dtau_hh_dV(i-1)...
           -3*dT/2*tau*((dhh_inf_dV(i)-dhh_dV_trans(i))/tau_hh(i).^2).*d2tau_hh_dV2(i)...
           -3*dT/2*tau*((dhh_inf_dV(i-1)-dhh_dV_trans(i-1))/tau_hh(i-1).^2).*d2tau_hh_dV2(i-1)...
           +3*dT*tau*((dhh_inf_dV(i)-dhh_dV_trans(i))/tau_hh(i).^3).*dtau_hh_dV(i).^2 ...
           +3*dT*tau*((dhh_inf_dV(i-1)-dhh_dV_trans(i-1))/tau_hh(i-1).^3).*dtau_hh_dV(i-1).^2 ...
  	   -dT/2*tau*((hh_inf(i)-hh_trans(i))/tau_hh(i).^2).*d3tau_hh_dV3(i)...
  	   -dT/2*tau*((hh_inf(i-1)-hh_trans(i-1))/tau_hh(i-1).^2).*d3tau_hh_dV3(i-1)...
   	   +3*dT*tau*((hh_inf(i)-hh_trans(i))/tau_hh(i).^3).*d2tau_hh_dV2(i).*dtau_hh_dV(i)...
    	   +3*dT*tau*((hh_inf(i-1)-hh_trans(i-1))/tau_hh(i-1).^3).*d2tau_hh_dV2(i-1).*dtau_hh_dV(i-1)...
           -3*dT*tau*((dhh_inf_dV(i)-dhh_dV_trans(i))/tau_hh(i).^4).*dtau_hh_dV(i).^3 ...
           -3*dT*tau*((dhh_inf_dV(i-1)-dhh_dV_trans(i-1))/tau_hh(i-1).^4).*dtau_hh_dV(i-1).^3)...
         /(1+dT*tau/(2*tau_hh(i)));


    end;

    
    mm(ii,:)=mm_trans;
    dmm_dv(ii,:)=dmm_dV_trans;
    d2mm_dv2(ii,:)=d2mm_dV2_trans;
    d3mm_dv3(ii,:)=d3mm_dV3_trans;
    hh(ii,:)=hh_trans;
    dhh_dv(ii,:)=dhh_dV_trans;
    d2hh_dv2(ii,:)=d2hh_dV2_trans;
    d3hh_dv3(ii,:)=d3hh_dV3_trans;
    
end;

% Potassium current - delayed rectifer
for ii=1:HotSpotNum_k
    
    pos=Xi_k(ii);

    y=Q10*alphan(pos,T,Er,a1_n,b1_n,c1_n,u0,up);
    y2=Q10*betan(pos,T,Er,a2_n,b2_n,c2_n,u0,up);
    yy=Q10*dalphan(pos,T,Er,a1_n,b1_n,c1_n,u0,up);
    yy2=Q10*dbetan(pos,T,Er,a2_n,b2_n,c2_n,u0,up);
    yyy=Q10*d2alphan(pos,T,Er,a1_n,b1_n,c1_n,u0,up);
    yyy2=Q10*d2betan(pos,T,Er,a2_n,b2_n,c2_n,u0,up);
    yyyy=Q10*d3alphan(pos,T,Er,a1_n,b1_n,c1_n,u0,up);
    yyyy2=Q10*d3betan(pos,T,Er,a2_n,b2_n,c2_n,u0,up);
    
    nnu(1)=y(1)/(y(1)+y2(1));
    vv(1)=(yy(1)-(yy(1)+yy2(1))*nnu(1))/(y(1)+y2(1));
    vv2(1)=(yyy(1)-2*vv(1)*(yy(1)+yy2(1))-nnu(1)*(yyy(1)+yyy2(1)))/(y(1)+y2(1));
    vv3(1)=(yyyy(1)-3*(yy(1)+yy2(1))*vv2(1)-3*(yyy(1)+yyy2(1))*vv(1)-(yyyy(1)+yyyy2(1))*nnu(1))/(y(1)+y2(1));
    
    nn_trans=zeros(size(T));
    nn_trans(1)=nnu(1);
    dnn_dV_trans=zeros(size(t));
    dnn_dV_trans(1)=vv(1);
    d2nn_dV2_trans=zeros(size(t));
    d2nn_dV2_trans(1)=vv2(1);
    d3nn_dV3_trans=zeros(size(t));
    d3nn_dV3_trans(1)=vv3(1);

    for i=2:length(T)
        nn_trans(i)=(nn_trans(i-1)+dT/2*tau*(y(i-1)+y(i))-dT/2*tau*(y(i-1)+y2(i-1))*nn_trans(i-1))/(1+dT/2*tau*(y(i)+y2(i)));
        
        dnn_dV_trans(i)=(dnn_dV_trans(i-1)+dT/2*tau*(yy(i-1)+yy(i))-dT/2*tau*(yy(i-1)+yy2(i-1))*nn_trans(i-1)...
       -dT/2*tau*(yy(i)+yy2(i))*nn_trans(i)-dT/2*tau*(y(i)+y2(i)).*dnn_dV_trans(i-1))/...
       (1+dT/2*tau*(y(i)+y2(i)));
   
        d2nn_dV2_trans(i)=(d2nn_dV2_trans(i-1)+dT/2*tau*(yyy(i)+yyy(i-1))-dT*tau*(yy(i)+yy2(i)).*dnn_dV_trans(i)...
            -dT*tau*(yy(i-1)+yy2(i-1))*dnn_dV_trans(i-1)-dT/2*tau*(yyy(i)+yyy2(i)).*nn_trans(i)...
            -dT/2*tau*(yyy(i-1)+yyy2(i-1)).*nn_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d2nn_dV2_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));
        
        d3nn_dV3_trans(i)=(d3nn_dV3_trans(i-1)+dT/2*tau*(yyyy(i)+yyyy(i-1))-3*dT/2*tau*(yyy(i)+yyy2(i)).*dnn_dV_trans(i)...
            -3*dT/2*tau*(yyy(i-1)+yyy2(i-1)).*dnn_dV_trans(i-1)-3*dT/2*tau*(yy(i)+yy2(i)).*d2nn_dV2_trans(i)...
            -3*dT/2*tau*(yy(i-1)+yy2(i-1)).*d2nn_dV2_trans(i-1)-dT/2*tau*(yyyy(i)+yyyy2(i)).*nn_trans(i)...
            -dT/2*tau*(yyyy(i-1)+yyyy2(i-1)).*nn_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d3nn_dV3_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));

    end;

    nn(ii,:)=nn_trans;
    dnn_dv(ii,:)=dnn_dV_trans;
    d2nn_dv2(ii,:)=d2nn_dV2_trans;
    d3nn_dv3(ii,:)=d3nn_dV3_trans;

end;

% plot(T,Fna(UUi,up,Phi_na,Omega,mm,hh))
% figure;
%f=quadg('integrand1',0,1,1e-6,1,0,0.2,Xi(1),u0,up,UUi,Phi_na,Omega,mm,hh);

% Potassium A-current

for ii=1:HotSpotNum_ka
    
    pos=Xi_ka(ii);

    y=Q10*alpha_kam(pos,T,Er,a1_ka,b1_ka,c1_ka,u0,up);
    y2=Q10*beta_kam(pos,T,Er,a2_ka,b2_ka,c2_ka,u0,up);
    yy=Q10*dalpha_kam(pos,T,Er,a1_ka,b1_ka,c1_ka,u0,up);
    yy2=Q10*dbeta_kam(pos,T,Er,a2_ka,b2_ka,c2_ka,u0,up);
    yyy=Q10*d2alpha_kam(pos,T,Er,a1_ka,b1_ka,c1_ka,u0,up);
    yyy2=Q10*d2beta_kam(pos,T,Er,a2_ka,b2_ka,c2_ka,u0,up);
    yyyy=Q10*d3alpha_kam(pos,T,Er,a1_ka,b1_ka,c1_ka,u0,up);
    yyyy2=Q10*d3beta_kam(pos,T,Er,a2_ka,b2_ka,c2_ka,u0,up);


    
     UU=Phi(pos,T,u0,up);

     mm_ka_inf=1./(1+exp(-(UU*up+Er+60)/8.5));

     dmm_ka_inf_dV=exp(-(UU*up+Er+60)/8.5)*(up/8.5)./(1+exp(-(UU*up+Er+60)/8.5)).^2;

     d2mm_ka_inf_dV2=2*exp(-2*(UU*up+Er+60)/8.5)*(up/8.5).^2./(1+exp(-(UU*up+Er+60)/8.5)).^3 ...
         -exp(-(UU*up+Er+60)/8.5)*(up/8.5).^2./(1+exp(-(UU*up+Er+60)/8.5)).^2;

     d3mm_ka_inf_dV3=6*exp(-3*(UU*up+Er+60)/8.5)*(up/8.5)^3./(1+exp(-(UU*up+Er+60)/8.5)).^4 ...
          -6*exp(-2*(UU*up+Er+60)/8.5)*(up/8.5)^3./(1+exp(-(UU*up+Er+60)/8.5)).^3 ...
          +exp(-(UU*up+Er+60)/8.5)*(up/8.5)^3./(1+exp(-(UU*up+Er+60)/8.5)).^2;

     tau_mm_ka=0.185+0.5./(y+y2);   

     dtau_mm_ka_dV=-0.5*(yy+yy2)./(y+y2).^2;   

     d2tau_mm_ka_dV2=0.5*(2*(yy+yy2).^2./(y+y2).^3-(yyy+yyy2)./(y+y2).^2);   

     d3tau_mm_ka_dV3=0.5*(-6*(yy+yy2).^3./(y+y2).^4+6*(yy+yy2).*(yyy+yyy2)./(y+y2).^3 ...
                  -(yyyy+yyyy2)./(y+y2).^2);   
    
%     hh_inf=y./(y+y2);
%     hh_trans(1)=y(1)/(y(1)+y2(1)); 

    mm_ka_trans=zeros(size(T));
    mm_ka_trans(1)=mm_ka_inf(1);    
    dmm_ka_dV_trans=zeros(size(T));
    dmm_ka_dV_trans(1)=dmm_ka_inf_dV(1); 
    d2mm_ka_dV2_trans=zeros(size(T));
    d2mm_ka_dV2_trans(1)=d2mm_ka_inf_dV2(1); 
    d3mm_ka_dV3_trans=zeros(size(T));
    d3mm_ka_dV3_trans(1)=d3mm_ka_inf_dV3(1); 
    
    
    
    for i=2:length(T)

      mm_ka_trans(i)=(mm_ka_trans(i-1)+dT/2*tau*mm_ka_inf(i)/tau_mm_ka(i)...
	  +dT/2*tau*(mm_ka_inf(i-1)-mm_ka_trans(i-1))/tau_mm_ka(i-1))...
          /(1+dT*tau/(2*tau_mm_ka(i)));
      
      dmm_ka_dV_trans(i)=(dmm_ka_dV_trans(i-1)+dT/2*tau*dmm_ka_inf_dV(i)/tau_mm_ka(i)...
           +dT/2*tau*((dmm_ka_inf_dV(i-1)-dmm_ka_dV_trans(i-1))/tau_mm_ka(i-1))...
           -dT/2*tau*((mm_ka_inf(i-1)-mm_ka_trans(i-1))/(tau_mm_ka(i-1).^2)).*dtau_mm_ka_dV(i-1)...
	   -dT/2*tau*((mm_ka_inf(i)-mm_ka_trans(i))/(tau_mm_ka(i).^2)).*dtau_mm_ka_dV(i))...
         /(1+dT*tau/(2*tau_mm_ka(i)));


      d2mm_ka_dV2_trans(i)=(d2mm_ka_dV2_trans(i-1)+dT/2*tau*d2mm_ka_inf_dV2(i)/tau_mm_ka(i)...
           +dT/2*tau*((d2mm_ka_inf_dV2(i-1)-d2mm_ka_dV2_trans(i-1))/tau_mm_ka(i-1))...
           -dT*tau*((dmm_ka_inf_dV(i)-dmm_ka_dV_trans(i))/tau_mm_ka(i).^2).*dtau_mm_ka_dV(i)...
           -dT*tau*((dmm_ka_inf_dV(i-1)-dmm_ka_dV_trans(i-1))/tau_mm_ka(i-1).^2).*dtau_mm_ka_dV(i-1)...
	   -dT/2*tau*((mm_ka_inf(i)-mm_ka_trans(i))/tau_mm_ka(i).^2).*d2tau_mm_ka_dV2(i)...
           -dT/2*tau*((mm_ka_inf(i-1)-mm_ka_trans(i-1))/tau_mm_ka(i-1).^2).*d2tau_mm_ka_dV2(i-1)...
	   +dT*tau*((mm_ka_inf(i)-mm_ka_trans(i))/tau_mm_ka(i).^3).*dtau_mm_ka_dV(i).^2 ...
           +dT*tau*((mm_ka_inf(i-1)-mm_ka_trans(i-1))/tau_mm_ka(i-1).^3).*dtau_mm_ka_dV(i-1).^2)...
         /(1+dT*tau/(2*tau_mm_ka(i)));


     d3mm_ka_dV3_trans(i)=(d3mm_ka_dV3_trans(i-1)+dT/2*tau*d3mm_ka_inf_dV3(i)/tau_mm_ka(i)...
           +dT/2*tau*((d3mm_ka_inf_dV3(i-1)-d3mm_ka_dV3_trans(i-1))/tau_mm_ka(i-1))...
           -3*dT/2*tau*((d2mm_ka_inf_dV2(i)-d2mm_ka_dV2_trans(i))/tau_mm_ka(i).^2).*dtau_mm_ka_dV(i)...
           -3*dT/2*tau*((d2mm_ka_inf_dV2(i-1)-d2mm_ka_dV2_trans(i-1))/tau_mm_ka(i).^2).*dtau_mm_ka_dV(i-1)...
           -3*dT/2*tau*((dmm_ka_inf_dV(i)-dmm_ka_dV_trans(i))/tau_mm_ka(i).^2).*d2tau_mm_ka_dV2(i)...
           -3*dT/2*tau*((dmm_ka_inf_dV(i-1)-dmm_ka_dV_trans(i-1))/tau_mm_ka(i-1).^2).*d2tau_mm_ka_dV2(i-1)...
           +3*dT*tau*((dmm_ka_inf_dV(i)-dmm_ka_dV_trans(i))/tau_mm_ka(i).^3).*dtau_mm_ka_dV(i).^2 ...
           +3*dT*tau*((dmm_ka_inf_dV(i-1)-dmm_ka_dV_trans(i-1))/tau_mm_ka(i-1).^3).*dtau_mm_ka_dV(i-1).^2 ...
  	   -dT/2*tau*((mm_ka_inf(i)-mm_ka_trans(i))/tau_mm_ka(i).^2).*d3tau_mm_ka_dV3(i)...
  	   -dT/2*tau*((mm_ka_inf(i-1)-mm_ka_trans(i-1))/tau_mm_ka(i-1).^2).*d3tau_mm_ka_dV3(i-1)...
   	   +3*dT*tau*((mm_ka_inf(i)-mm_ka_trans(i))/tau_mm_ka(i).^3).*d2tau_mm_ka_dV2(i).*dtau_mm_ka_dV(i)...
    	   +3*dT*tau*((mm_ka_inf(i-1)-mm_ka_trans(i-1))/tau_mm_ka(i-1).^3).*d2tau_mm_ka_dV2(i-1).*dtau_mm_ka_dV(i-1)...
           -3*dT*tau*((dmm_ka_inf_dV(i)-dmm_ka_dV_trans(i))/tau_mm_ka(i).^4).*dtau_mm_ka_dV(i).^3 ...
           -3*dT*tau*((dmm_ka_inf_dV(i-1)-dmm_ka_dV_trans(i-1))/tau_mm_ka(i-1).^4).*dtau_mm_ka_dV(i-1).^3)...
         /(1+dT*tau/(2*tau_mm_ka(i)));


    end;
    
    
    y=Q10*alpha_kah(pos,T,Er,a3_ka,b3_ka,c3_ka,u0,up);
    y2=Q10*beta_kah(pos,T,Er,a4_ka,b4_ka,c4_ka,u0,up);
    yy=Q10*dalpha_kah(pos,T,Er,a3_ka,b3_ka,c3_ka,u0,up);
    yy2=Q10*dbeta_kah(pos,T,Er,a4_ka,b4_ka,c4_ka,u0,up);
    yyy=Q10*d2alpha_kah(pos,T,Er,a3_ka,b3_ka,c3_ka,u0,up);
    yyy2=Q10*d2beta_kah(pos,T,Er,a4_ka,b4_ka,c4_ka,u0,up);
    yyyy=Q10*d3alpha_kah(pos,T,Er,a3_ka,b3_ka,c3_ka,u0,up);
    yyyy2=Q10*d3beta_kah(pos,T,Er,a4_ka,b4_ka,c4_ka,u0,up);


    
     UU=Phi(pos,T,u0,up);

     hh_ka_inf=1./(1+exp((UU*up+Er+78)/6));

     dhh_ka_inf_dV=-exp((UU*up+Er+78)/6)*(up/6)./(1+exp((UU*up+Er+78)/6)).^2;

     d2hh_ka_inf_dV2=2*exp(2*(UU*up+Er+78)/6)*(up/6).^2./(1+exp((UU*up+Er+78)/6)).^3 ...
         -exp((UU*up+Er+78)/6)*(up/6).^2./(1+exp((UU*up+Er+78)/6)).^2;

     d3hh_ka_inf_dV3=-6*exp(3*(UU*up+Er+78)/6)*(up/6)^3./(1+exp((UU*up+Er+78)/6)).^4 ...
          +6*exp(2*(UU*up+Er+78)/6)*(up/6)^3./(1+exp((UU*up+Er+78)/6)).^3 ...
          -exp((UU*up+Er+78)/6)*(up/6)^3./(1+exp((UU*up+Er+78)/6)).^2;

      
       tau_hh_ka=0.5./(y+y2);   

       dtau_hh_ka_dV=-0.5*(yy+yy2)./(y+y2).^2;   

       d2tau_hh_ka_dV2=0.5*(2*(yy+yy2).^2./(y+y2).^3-(yyy+yyy2)./(y+y2).^2);   

       d3tau_hh_ka_dV3=0.5*(-6*(yy+yy2).^3./(y+y2).^4+6*(yy+yy2).*(yyy+yyy2)./(y+y2).^3 ...
                  -(yyyy+yyyy2)./(y+y2).^2);  
              
       idx2=find(UU*up>-63);
       
       tau_hh_ka(idx2)=9.5;   

       dtau_hh_ka_dV(idx2)=0;   

       d2tau_hh_ka_dV2(idx2)=0;   

       d3tau_hh_ka_dV3(idx2)=0;   
    
%     hh_inf=y./(y+y2);
%     hh_trans(1)=y(1)/(y(1)+y2(1)); 

    hh_ka_trans=zeros(size(T));
    hh_ka_trans(1)=hh_ka_inf(1);    
    dhh_ka_dV_trans=zeros(size(T));
    dhh_ka_dV_trans(1)=dhh_ka_inf_dV(1); 
    d2hh_ka_dV2_trans=zeros(size(T));
    d2hh_ka_dV2_trans(1)=d2hh_ka_inf_dV2(1); 
    d3hh_ka_dV3_trans=zeros(size(T));
    d3hh_ka_dV3_trans(1)=d3hh_ka_inf_dV3(1); 
    
    
    
    for i=2:length(T)

      hh_ka_trans(i)=(hh_ka_trans(i-1)+dT/2*tau*hh_ka_inf(i)/tau_hh_ka(i)...
	  +dT/2*tau*(hh_ka_inf(i-1)-hh_ka_trans(i-1))/tau_hh_ka(i-1))...
          /(1+dT*tau/(2*tau_hh_ka(i)));
      
      dhh_ka_dV_trans(i)=(dhh_ka_dV_trans(i-1)+dT/2*tau*dhh_ka_inf_dV(i)/tau_hh_ka(i)...
           +dT/2*tau*((dhh_ka_inf_dV(i-1)-dhh_ka_dV_trans(i-1))/tau_hh_ka(i-1))...
           -dT/2*tau*((hh_ka_inf(i-1)-hh_ka_trans(i-1))/(tau_hh_ka(i-1).^2)).*dtau_hh_ka_dV(i-1)...
	   -dT/2*tau*((hh_ka_inf(i)-hh_ka_trans(i))/(tau_hh_ka(i).^2)).*dtau_hh_ka_dV(i))...
         /(1+dT*tau/(2*tau_hh_ka(i)));


      d2hh_ka_dV2_trans(i)=(d2hh_ka_dV2_trans(i-1)+dT/2*tau*d2hh_ka_inf_dV2(i)/tau_hh_ka(i)...
           +dT/2*tau*((d2hh_ka_inf_dV2(i-1)-d2hh_ka_dV2_trans(i-1))/tau_hh_ka(i-1))...
           -dT*tau*((dhh_ka_inf_dV(i)-dhh_ka_dV_trans(i))/tau_hh_ka(i).^2).*dtau_hh_ka_dV(i)...
           -dT*tau*((dhh_ka_inf_dV(i-1)-dhh_ka_dV_trans(i-1))/tau_hh_ka(i-1).^2).*dtau_hh_ka_dV(i-1)...
	   -dT/2*tau*((hh_ka_inf(i)-hh_ka_trans(i))/tau_hh_ka(i).^2).*d2tau_hh_ka_dV2(i)...
           -dT/2*tau*((hh_ka_inf(i-1)-hh_ka_trans(i-1))/tau_hh_ka(i-1).^2).*d2tau_hh_ka_dV2(i-1)...
	   +dT*tau*((hh_ka_inf(i)-hh_ka_trans(i))/tau_hh_ka(i).^3).*dtau_hh_ka_dV(i).^2 ...
           +dT*tau*((hh_ka_inf(i-1)-hh_ka_trans(i-1))/tau_hh_ka(i-1).^3).*dtau_hh_ka_dV(i-1).^2)...
         /(1+dT*tau/(2*tau_hh_ka(i)));


     d3hh_ka_dV3_trans(i)=(d3hh_ka_dV3_trans(i-1)+dT/2*tau*d3hh_ka_inf_dV3(i)/tau_hh_ka(i)...
           +dT/2*tau*((d3hh_ka_inf_dV3(i-1)-d3hh_ka_dV3_trans(i-1))/tau_hh_ka(i-1))...
           -3*dT/2*tau*((d2hh_ka_inf_dV2(i)-d2hh_ka_dV2_trans(i))/tau_hh_ka(i).^2).*dtau_hh_ka_dV(i)...
           -3*dT/2*tau*((d2hh_ka_inf_dV2(i-1)-d2hh_ka_dV2_trans(i-1))/tau_hh_ka(i).^2).*dtau_hh_ka_dV(i-1)...
           -3*dT/2*tau*((dhh_ka_inf_dV(i)-dhh_ka_dV_trans(i))/tau_hh_ka(i).^2).*d2tau_hh_ka_dV2(i)...
           -3*dT/2*tau*((dhh_ka_inf_dV(i-1)-dhh_ka_dV_trans(i-1))/tau_hh_ka(i-1).^2).*d2tau_hh_ka_dV2(i-1)...
           +3*dT*tau*((dhh_ka_inf_dV(i)-dhh_ka_dV_trans(i))/tau_hh_ka(i).^3).*dtau_hh_ka_dV(i).^2 ...
           +3*dT*tau*((dhh_ka_inf_dV(i-1)-dhh_ka_dV_trans(i-1))/tau_hh_ka(i-1).^3).*dtau_hh_ka_dV(i-1).^2 ...
  	   -dT/2*tau*((hh_ka_inf(i)-hh_ka_trans(i))/tau_hh_ka(i).^2).*d3tau_hh_ka_dV3(i)...
  	   -dT/2*tau*((hh_ka_inf(i-1)-hh_ka_trans(i-1))/tau_hh_ka(i-1).^2).*d3tau_hh_ka_dV3(i-1)...
   	   +3*dT*tau*((hh_ka_inf(i)-hh_ka_trans(i))/tau_hh_ka(i).^3).*d2tau_hh_ka_dV2(i).*dtau_hh_ka_dV(i)...
    	   +3*dT*tau*((hh_ka_inf(i-1)-hh_ka_trans(i-1))/tau_hh_ka(i-1).^3).*d2tau_hh_ka_dV2(i-1).*dtau_hh_ka_dV(i-1)...
           -3*dT*tau*((dhh_ka_inf_dV(i)-dhh_ka_dV_trans(i))/tau_hh_ka(i).^4).*dtau_hh_ka_dV(i).^3 ...
           -3*dT*tau*((dhh_ka_inf_dV(i-1)-dhh_ka_dV_trans(i-1))/tau_hh_ka(i-1).^4).*dtau_hh_ka_dV(i-1).^3)...
         /(1+dT*tau/(2*tau_hh_ka(i)));


    end;

    
    mm_ka(ii,:)=mm_ka_trans;
    dmm_ka_dv(ii,:)=dmm_ka_dV_trans;
    d2mm_ka_dv2(ii,:)=d2mm_ka_dV2_trans;
    d3mm_ka_dv3(ii,:)=d3mm_ka_dV3_trans;
    hh_ka(ii,:)=hh_ka_trans;
    dhh_ka_dv(ii,:)=dhh_ka_dV_trans;
    d2hh_ka_dv2(ii,:)=d2hh_ka_dV2_trans;
    d3hh_ka_dv3(ii,:)=d3hh_ka_dV3_trans;
    
end;

% Potassium h-current

for ii=1:HotSpotNum_kh
    
    pos=Xi_kh(ii);

    y=Q10*alpha_kh(pos,T,Er,a1_kh,b1_kh,c1_kh,u0,up);
    y2=Q10*beta_kh(pos,T,Er,a2_kh,b2_kh,c2_kh,u0,up);
    yy=Q10*dalpha_kh(pos,T,Er,a1_kh,b1_kh,c1_kh,u0,up);
    yy2=Q10*dbeta_kh(pos,T,Er,a2_kh,b2_kh,c2_kh,u0,up);
    yyy=Q10*d2alpha_kh(pos,T,Er,a1_kh,b1_kh,c1_kh,u0,up);
    yyy2=Q10*d2beta_kh(pos,T,Er,a2_kh,b2_kh,c2_kh,u0,up);
    yyyy=Q10*d3alpha_kh(pos,T,Er,a1_kh,b1_kh,c1_kh,u0,up);
    yyyy2=Q10*d3beta_kh(pos,T,Er,a2_kh,b2_kh,c2_kh,u0,up);


    
     UU=Phi(pos,T,u0,up);

     mm_kh_inf=1./(1+exp((UU*up+Er+75)/5.5));

     dmm_kh_inf_dV=-exp((UU*up+Er+75)/5.5)*(up/5.5)./(1+exp((UU*up+Er+75)/5.5)).^2;

     d2mm_kh_inf_dV2=2*exp(2*(UU*up+Er+75)/5.5)*(up/5.5).^2./(1+exp((UU*up+Er+75)/5.5)).^3 ...
         -exp(-(UU*up+Er+75)/5.5)*(up/5.5).^2./(1+exp((UU*up+Er+75)/5.5)).^2;

     d3mm_kh_inf_dV3=-6*exp(3*(UU*up+Er+75)/5.5)*(up/5.5)^3./(1+exp((UU*up+Er+75)/5.5)).^4 ...
          +6*exp(2*(UU*up+Er+75)/5.5)*(up/5.5)^3./(1+exp((UU*up+Er+75)/5.5)).^3 ...
          -exp((UU*up+Er+75)/8.5)*(up/5.5)^3./(1+exp((UU*up+Er+75)/5.5)).^2;

     tau_mm_kh=1./(y+y2);   

     dtau_mm_kh_dV=-(yy+yy2)./(y+y2).^2;   

     d2tau_mm_kh_dV2=2*(yy+yy2).^2./(y+y2).^3-(yyy+yyy2)./(y+y2).^2;   

     d3tau_mm_kh_dV3=-6*(yy+yy2).^3./(y+y2).^4+6*(yy+yy2).*(yyy+yyy2)./(y+y2).^3 ...
                  -(yyyy+yyyy2)./(y+y2).^2;   
    
%     hh_inf=y./(y+y2);
%     hh_trans(1)=y(1)/(y(1)+y2(1)); 

    mm_kh_trans=zeros(size(T));
    mm_kh_trans(1)=mm_kh_inf(1);    
    dmm_kh_dV_trans=zeros(size(T));
    dmm_kh_dV_trans(1)=dmm_kh_inf_dV(1); 
    d2mm_kh_dV2_trans=zeros(size(T));
    d2mm_kh_dV2_trans(1)=d2mm_kh_inf_dV2(1); 
    d3mm_kh_dV3_trans=zeros(size(T));
    d3mm_kh_dV3_trans(1)=d3mm_kh_inf_dV3(1); 
    
    
    
    for i=2:length(T)

      mm_kh_trans(i)=(mm_kh_trans(i-1)+dT/2*tau*mm_kh_inf(i)/tau_mm_kh(i)...
	  +dT/2*tau*(mm_kh_inf(i-1)-mm_kh_trans(i-1))/tau_mm_kh(i-1))...
          /(1+dT*tau/(2*tau_mm_kh(i)));
      
      dmm_kh_dV_trans(i)=(dmm_kh_dV_trans(i-1)+dT/2*tau*dmm_kh_inf_dV(i)/tau_mm_kh(i)...
           +dT/2*tau*((dmm_kh_inf_dV(i-1)-dmm_kh_dV_trans(i-1))/tau_mm_kh(i-1))...
           -dT/2*tau*((mm_kh_inf(i-1)-mm_kh_trans(i-1))/(tau_mm_kh(i-1).^2)).*dtau_mm_kh_dV(i-1)...
	   -dT/2*tau*((mm_kh_inf(i)-mm_kh_trans(i))/(tau_mm_kh(i).^2)).*dtau_mm_kh_dV(i))...
         /(1+dT*tau/(2*tau_mm_kh(i)));


      d2mm_kh_dV2_trans(i)=(d2mm_kh_dV2_trans(i-1)+dT/2*tau*d2mm_kh_inf_dV2(i)/tau_mm_kh(i)...
           +dT/2*tau*((d2mm_kh_inf_dV2(i-1)-d2mm_kh_dV2_trans(i-1))/tau_mm_kh(i-1))...
           -dT*tau*((dmm_kh_inf_dV(i)-dmm_kh_dV_trans(i))/tau_mm_kh(i).^2).*dtau_mm_kh_dV(i)...
           -dT*tau*((dmm_kh_inf_dV(i-1)-dmm_kh_dV_trans(i-1))/tau_mm_kh(i-1).^2).*dtau_mm_kh_dV(i-1)...
	   -dT/2*tau*((mm_kh_inf(i)-mm_kh_trans(i))/tau_mm_kh(i).^2).*d2tau_mm_kh_dV2(i)...
           -dT/2*tau*((mm_kh_inf(i-1)-mm_kh_trans(i-1))/tau_mm_kh(i-1).^2).*d2tau_mm_kh_dV2(i-1)...
	   +dT*tau*((mm_kh_inf(i)-mm_kh_trans(i))/tau_mm_kh(i).^3).*dtau_mm_kh_dV(i).^2 ...
           +dT*tau*((mm_kh_inf(i-1)-mm_kh_trans(i-1))/tau_mm_kh(i-1).^3).*dtau_mm_kh_dV(i-1).^2)...
         /(1+dT*tau/(2*tau_mm_kh(i)));


     d3mm_kh_dV3_trans(i)=(d3mm_kh_dV3_trans(i-1)+dT/2*tau*d3mm_kh_inf_dV3(i)/tau_mm_kh(i)...
           +dT/2*tau*((d3mm_kh_inf_dV3(i-1)-d3mm_kh_dV3_trans(i-1))/tau_mm_kh(i-1))...
           -3*dT/2*tau*((d2mm_kh_inf_dV2(i)-d2mm_kh_dV2_trans(i))/tau_mm_kh(i).^2).*dtau_mm_kh_dV(i)...
           -3*dT/2*tau*((d2mm_kh_inf_dV2(i-1)-d2mm_kh_dV2_trans(i-1))/tau_mm_kh(i).^2).*dtau_mm_kh_dV(i-1)...
           -3*dT/2*tau*((dmm_kh_inf_dV(i)-dmm_kh_dV_trans(i))/tau_mm_kh(i).^2).*d2tau_mm_kh_dV2(i)...
           -3*dT/2*tau*((dmm_kh_inf_dV(i-1)-dmm_kh_dV_trans(i-1))/tau_mm_kh(i-1).^2).*d2tau_mm_kh_dV2(i-1)...
           +3*dT*tau*((dmm_kh_inf_dV(i)-dmm_kh_dV_trans(i))/tau_mm_kh(i).^3).*dtau_mm_kh_dV(i).^2 ...
           +3*dT*tau*((dmm_kh_inf_dV(i-1)-dmm_kh_dV_trans(i-1))/tau_mm_kh(i-1).^3).*dtau_mm_kh_dV(i-1).^2 ...
  	   -dT/2*tau*((mm_kh_inf(i)-mm_kh_trans(i))/tau_mm_kh(i).^2).*d3tau_mm_kh_dV3(i)...
  	   -dT/2*tau*((mm_kh_inf(i-1)-mm_kh_trans(i-1))/tau_mm_kh(i-1).^2).*d3tau_mm_kh_dV3(i-1)...
   	   +3*dT*tau*((mm_kh_inf(i)-mm_kh_trans(i))/tau_mm_kh(i).^3).*d2tau_mm_kh_dV2(i).*dtau_mm_kh_dV(i)...
    	   +3*dT*tau*((mm_kh_inf(i-1)-mm_kh_trans(i-1))/tau_mm_kh(i-1).^3).*d2tau_mm_kh_dV2(i-1).*dtau_mm_kh_dV(i-1)...
           -3*dT*tau*((dmm_kh_inf_dV(i)-dmm_kh_dV_trans(i))/tau_mm_kh(i).^4).*dtau_mm_kh_dV(i).^3 ...
           -3*dT*tau*((dmm_kh_inf_dV(i-1)-dmm_kh_dV_trans(i-1))/tau_mm_kh(i-1).^4).*dtau_mm_kh_dV(i-1).^3)...
         /(1+dT*tau/(2*tau_mm_kh(i)));


    end;
    
    mm_kh(ii,:)=mm_kh_trans;
    dmm_kh_dv(ii,:)=dmm_kh_dV_trans;
    d2mm_kh_dv2(ii,:)=d2mm_kh_dV2_trans;
    d3mm_kh_dv3(ii,:)=d3mm_kh_dV3_trans;
    
end;


for ii=1:HotSpotNum_hva
    
    pos=Xi_hva(ii);

    y=Q10*alpha_hvam(pos,T,Er,a1_hva,b1_hva,c1_hva,u0,up);
    y2=Q10*beta_hvam(pos,T,Er,a2_hva,b2_hva,c2_hva,u0,up);
    yy=Q10*dalpha_hvam(pos,T,Er,a1_hva,b1_hva,c1_hva,u0,up);
    yy2=Q10*dbeta_hvam(pos,T,Er,a2_hva,b2_hva,c2_hva,u0,up);
    yyy=Q10*d2alpha_hvam(pos,T,Er,a1_hva,b1_hva,c1_hva,u0,up);
    yyy2=Q10*d2beta_hvam(pos,T,Er,a2_hva,b2_hva,c2_hva,u0,up);
    yyyy=Q10*d3alpha_hvam(pos,T,Er,a1_hva,b1_hva,c1_hva,u0,up);
    yyyy2=Q10*d3beta_hvam(pos,T,Er,a2_hva,b2_hva,c2_hva,u0,up);

    mmu_hva(1)=y(1)/(y(1)+y2(1));
    vv(1)=(yy(1)-(yy(1)+yy2(1))*mmu_hva(1))/(y(1)+y2(1));
    vv2(1)=(yyy(1)-2*vv(1)*(yy(1)+yy2(1))-mmu_hva(1)*(yyy(1)+yyy2(1)))/(y(1)+y2(1));
    vv3(1)=(yyyy(1)-3*(yy(1)+yy2(1))*vv2(1)-3*(yyy(1)+yyy2(1))*vv(1)-(yyyy(1)+yyyy2(1))*mmu_hva(1))/(y(1)+y2(1));
    
    mm_hva_trans=zeros(size(T));
    mm_hva_trans(1)=mmu_hva(1);
    dmm_hva_dV_trans=zeros(size(t));
    dmm_hva_dV_trans(1)=vv(1);
    d2mm_hva_dV2_trans=zeros(size(t));
    d2mm_hva_dV2_trans(1)=vv2(1);
    d3mm_hva_dV3_trans=zeros(size(t));
    d3mm_hva_dV3_trans(1)=vv3(1);
    
    for i=2:length(T)
        mm_hva_trans(i)=(mm_hva_trans(i-1)+dT/2*tau*(y(i-1)+y(i))-dT/2*tau*(y(i-1)+y2(i-1))*mm_hva_trans(i-1))/(1+dT/2*tau*(y(i)+y2(i)));
       
        dmm_hva_dV_trans(i)=(dmm_hva_dV_trans(i-1)+dT/2*tau*(yy(i-1)+yy(i))-dT/2*tau*(yy(i-1)+yy2(i-1))*mm_hva_trans(i-1)...
       -dT/2*tau*(yy(i)+yy2(i))*mm_hva_trans(i)-dT/2*tau*(y(i)+y2(i)).*dmm_hva_dV_trans(i-1))/...
       (1+dT/2*tau*(y(i)+y2(i)));
   
        d2mm_hva_dV2_trans(i)=(d2mm_hva_dV2_trans(i-1)+dT/2*tau*(yyy(i)+yyy(i-1))-dT*tau*(yy(i)+yy2(i)).*dmm_hva_dV_trans(i)...
            -dT*tau*(yy(i-1)+yy2(i-1))*dmm_hva_dV_trans(i-1)-dT/2*tau*(yyy(i)+yyy2(i)).*mm_hva_trans(i)...
            -dT/2*tau*(yyy(i-1)+yyy2(i-1)).*mm_hva_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d2mm_hva_dV2_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));
        
        d3mm_hva_dV3_trans(i)=(d3mm_hva_dV3_trans(i-1)+dT/2*tau*(yyyy(i)+yyyy(i-1))-3*dT/2*tau*(yyy(i)+yyy2(i)).*dmm_hva_dV_trans(i)...
            -3*dT/2*tau*(yyy(i-1)+yyy2(i-1)).*dmm_hva_dV_trans(i-1)-3*dT/2*tau*(yy(i)+yy2(i)).*d2mm_hva_dV2_trans(i)...
            -3*dT/2*tau*(yy(i-1)+yy2(i-1)).*d2mm_hva_dV2_trans(i-1)-dT/2*tau*(yyyy(i)+yyyy2(i)).*mm_hva_trans(i)...
            -dT/2*tau*(yyyy(i-1)+yyyy2(i-1)).*mm_hva_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d3mm_hva_dV3_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));

   end;
   
    mm_hva(ii,:)=mm_hva_trans;
    dmm_hva_dv(ii,:)=dmm_hva_dV_trans;
    d2mm_hva_dv2(ii,:)=d2mm_hva_dV2_trans;
    d3mm_hva_dv3(ii,:)=d3mm_hva_dV3_trans;
%     hh_hva(ii,:)=hh_trans;
%     dhh_hva_dv(ii,:)=dhh_dV_trans;
%     d2hh_hva_dv2(ii,:)=d2hh_dV2_trans;
%     d3hh_hva_dv3(ii,:)=d3hh_dV3_trans;
    
end;

% Potassium current - BK channel
for ii=1:HotSpotNum_kca
    
    pos=Xi_kca(ii);

    y=Q10*alpha_kca(pos,T,Er,a1_kca,b1_kca,c1_kca,a2_kca,b2_kca,c2_kca,u0,up);
    y2=Q10*beta_kca(pos,T,Er,a1_kca,b1_kca,c1_kca,a2_kca,b2_kca,c2_kca,u0,up);
    yy=Q10*dalpha_kca(pos,T,Er,a1_kca,b1_kca,c1_kca,a2_kca,b2_kca,c2_kca,u0,up);
    yy2=Q10*dbeta_kca(pos,T,Er,a1_kca,b1_kca,c1_kca,a2_kca,b2_kca,c2_kca,u0,up);
    yyy=Q10*d2alpha_kca(pos,T,Er,a1_kca,b1_kca,c1_kca,a2_kca,b2_kca,c2_kca,u0,up);
    yyy2=Q10*d2beta_kca(pos,T,Er,a1_kca,b1_kca,c1_kca,a2_kca,b2_kca,c2_kca,u0,up);
    yyyy=Q10*d3alpha_kca(pos,T,Er,a1_kca,b1_kca,c1_kca,a2_kca,b2_kca,c2_kca,u0,up);
    yyyy2=Q10*d3beta_kca(pos,T,Er,a1_kca,b1_kca,c1_kca,a2_kca,b2_kca,c2_kca,u0,up);
    
    mmu_kca(1)=y(1)/(y(1)+y2(1));
    vv(1)=(yy(1)-(yy(1)+yy2(1))*mmu_kca(1))/(y(1)+y2(1));
    vv2(1)=(yyy(1)-2*vv(1)*(yy(1)+yy2(1))-mmu_kca(1)*(yyy(1)+yyy2(1)))/(y(1)+y2(1));
    vv3(1)=(yyyy(1)-3*(yy(1)+yy2(1))*vv2(1)-3*(yyy(1)+yyy2(1))*vv(1)-(yyyy(1)+yyyy2(1))*mmu_kca(1))/(y(1)+y2(1));
    
    mm_kca_trans=zeros(size(T));
    mm_kca_trans(1)=mmu_kca(1);
    dmm_kca_dV_trans=zeros(size(t));
    dmm_kca_dV_trans(1)=vv(1);
    d2mm_kca_dV2_trans=zeros(size(t));
    d2mm_kca_dV2_trans(1)=vv2(1);
    d3mm_kca_dV3_trans=zeros(size(t));
    d3mm_kca_dV3_trans(1)=vv3(1);

    for i=2:length(T)
        mm_kca_trans(i)=(nn_trans(i-1)+dT/2*tau*(y(i-1)+y(i))-dT/2*tau*(y(i-1)+y2(i-1))*mm_kca_trans(i-1))/(1+dT/2*tau*(y(i)+y2(i)));
        
        dmm_kca_dV_trans(i)=(dmm_kca_dV_trans(i-1)+dT/2*tau*(yy(i-1)+yy(i))-dT/2*tau*(yy(i-1)+yy2(i-1))*mm_kca_trans(i-1)...
       -dT/2*tau*(yy(i)+yy2(i))*mm_kca_trans(i)-dT/2*tau*(y(i)+y2(i)).*dmm_kca_dV_trans(i-1))/...
       (1+dT/2*tau*(y(i)+y2(i)));
   
        d2mm_kca_dV2_trans(i)=(d2mm_kca_dV2_trans(i-1)+dT/2*tau*(yyy(i)+yyy(i-1))-dT*tau*(yy(i)+yy2(i)).*dmm_kca_dV_trans(i)...
            -dT*tau*(yy(i-1)+yy2(i-1))*dmm_kca_dV_trans(i-1)-dT/2*tau*(yyy(i)+yyy2(i)).*mm_kca_trans(i)...
            -dT/2*tau*(yyy(i-1)+yyy2(i-1)).*mm_kca_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d2mm_kca_dV2_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));
        
        d3mm_kca_dV3_trans(i)=(d3mm_kca_dV3_trans(i-1)+dT/2*tau*(yyyy(i)+yyyy(i-1))-3*dT/2*tau*(yyy(i)+yyy2(i)).*dmm_kca_dV_trans(i)...
            -3*dT/2*tau*(yyy(i-1)+yyy2(i-1)).*dmm_kca_dV_trans(i-1)-3*dT/2*tau*(yy(i)+yy2(i)).*d2mm_kca_dV2_trans(i)...
            -3*dT/2*tau*(yy(i-1)+yy2(i-1)).*d2mm_kca_dV2_trans(i-1)-dT/2*tau*(yyyy(i)+yyyy2(i)).*mm_kca_trans(i)...
            -dT/2*tau*(yyyy(i-1)+yyyy2(i-1)).*mm_kca_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d3mm_kca_dV3_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));

    end;

    mm_kca(ii,:)=mm_kca_trans;
    dmm_kca_dv(ii,:)=dmm_kca_dV_trans;
    d2mm_kca_dv2(ii,:)=d2mm_kca_dV2_trans;
    d3mm_kca_dv3(ii,:)=d3mm_kca_dV3_trans;

end;


Xi_mu=[Xi_na Xi_k Xi_ka Xi_kh Xi_hva Xi_kca];

for jj=1:HotSpotNum_na+HotSpotNum_k+HotSpotNum_ka+HotSpotNum_kh+HotSpotNum_hva+HotSpotNum_kca

f1_na=zeros(size(T));

for ii=1:HotSpotNum_na
    zz1=fft(G(Xi_mu(jj),Xi_na(ii),T));
    UU=Phi(Xi_na(ii),T,u0,up);
    
    zz1_na=fft(Fna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:)));
    zz_na=dT*real(ifft(zz1.*zz1_na));
    f1_na=f1_na+Gna(ii)*Rm/lambda*zz_na;
end;

f1_k=zeros(size(T));

for pp=1:HotSpotNum_k
    zz1=fft(G(Xi_mu(jj),Xi_k(pp),T));
    UU=Phi(Xi_k(pp),T,u0,up);

    zz1_k=fft(Fk(UU+Er/up,up,Phi_k,Omega,nn(pp,:)));
    zz_k=dT*real(ifft(zz1.*zz1_k));
    f1_k=f1_k+Gk(pp)*(Rm/lambda)*zz_k;

end;

f1_ka=zeros(size(T));

for qq=1:HotSpotNum_ka
    zz1=fft(G(Xi_mu(jj),Xi_ka(qq),T));
    UU=Phi(Xi_ka(qq),T,u0,up);

    zz1_ka=fft(Fka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:)));
    zz_ka=dT*real(ifft(zz1.*zz1_ka));
    f1_ka=f1_k+Gka(qq)*(Rm/lambda)*zz_ka;

end;

f1_kh=zeros(size(T));

for rr=1:HotSpotNum_kh
    zz1=fft(G(Xi_mu(jj),Xi_kh(rr),T));
    UU=Phi(Xi_kh(rr),T,u0,up);

    zz1_kh=fft(Fkh(UU+Er/up,up,Phi_kh,Omega,mm(rr,:)));
    zz_kh=dT*real(ifft(zz1.*zz1_kh));
    f1_kh=f1_kh+Gk(rr)*(Rm/lambda)*zz_kh;

end;

f1_hva=zeros(size(T));

for ss=1:HotSpotNum_hva
    zz1=fft(G(Xi_mu(jj),Xi_hva(ss),T));
    UU=Phi(Xi_hva(ss),T,u0,up);
    
    zz1_hva=fft(Fca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:)));
    zz_hva=dT*real(ifft(zz1.*zz1_hva));
    f1_hva=f1_hva+Ghva(ss)*Rm/lambda*zz_hva;
end;

f1_kca=zeros(size(T));

for tt=1:HotSpotNum_kca
    zz1=fft(G(Xi_mu(jj),Xi_kca(tt),T));
    UU=Phi(Xi_kca(tt),T,u0,up);

    zz1_kca=fft(Fkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:)));
    zz_kca=dT*real(ifft(zz1.*zz1_kca));
    f1_kca=f1_kca+Gkca(tt)*(Rm/lambda)*zz_kca;

end;

Phi1(jj,:)=f1_na+f1_k+f1_ka+f1_kh+f1_hva+f1_kca;
end;

for jj=1:HotSpotNum_na+HotSpotNum_k+HotSpotNum_ka+HotSpotNum_kh+HotSpotNum_hva+HotSpotNum_kca


f2_na=zeros(size(T));

for ii=1:HotSpotNum_na
    zz1=fft(G(Xi_mu(jj),Xi_na(ii),T));
    UU=Phi(Xi_na(ii),T,u0,up);
    
    zz2_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi1(ii,:));
    zz2=dT*real(ifft(zz1.*zz2_na));
    f2_na=f2_na+Gna(ii)*Rm/lambda*zz2;

end;

f2_k=zeros(size(T));

for pp=1:HotSpotNum_k
    zz1=fft(G(Xi_mu(jj),Xi_k(pp),T));
    UU=Phi(Xi_k(pp),T,u0,up);

    zz22_k=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi1(ii+pp,:));
    zz2_k=dT*real(ifft(zz1.*zz22_k));
    f2_k=f2_k+Gk(pp)*(Rm/lambda)*zz2_k;

end;

f2_ka=zeros(size(T));

for qq=1:HotSpotNum_ka
    zz1=fft(G(Xi_mu(jj),Xi_ka(qq),T));
    UU=Phi(Xi_ka(qq),T,u0,up);
    
    zz22_ka=fft(DFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi1(ii+pp+qq,:));
    zz2_ka=dT*real(ifft(zz1.*zz22_ka));
    f2_ka=f2_ka+Gka(qq)*Rm/lambda*zz2_ka;

end;

f2_kh=zeros(size(T));

for rr=1:HotSpotNum_kh
    zz1=fft(G(Xi_mu(jj),Xi_kh(rr),T));
    UU=Phi(Xi_kh(rr),T,u0,up);

    zz22_kh=fft(DFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi1(ii+pp+qq+rr,:));
    zz2_kh=dT*real(ifft(zz1.*zz22_kh));
    f2_kh=f2_kh+Gkh(rr)*(Rm/lambda)*zz2_kh;

end;

f2_hva=zeros(size(T));

for ss=1:HotSpotNum_hva
    zz1=fft(G(Xi_mu(jj),Xi_hva(ss),T));
    UU=Phi(Xi_hva(ss),T,u0,up);

    zz22_hva=fft(DFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi1(ii+pp+qq+rr+ss,:));
    zz2_hva=dT*real(ifft(zz1.*zz22_hva));
    f2_hva=f2_hva+Ghva(ss)*(Rm/lambda)*zz2_hva;

end;

f2_kca=zeros(size(T));

for tt=1:HotSpotNum_kca
    zz1=fft(G(Xi_mu(jj),Xi_kca(tt),T));
    UU=Phi(Xi_kca(tt),T,u0,up);

    zz22_kca=fft(DFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:));
    zz2_kca=dT*real(ifft(zz1.*zz22_kca));
    f2_kca=f2_kca+Gkca(tt)*(Rm/lambda)*zz2_kca;

end;

Phi2(jj,:)=f2_na+f2_k+f2_ka+f2_kh+f2_hva+f2_kca;
end;

for jj=1:HotSpotNum_na+HotSpotNum_k+HotSpotNum_ka+HotSpotNum_kh+HotSpotNum_hva+HotSpotNum_kca

f3_na=zeros(size(T));

for ii=1:HotSpotNum_na
    zz1=fft(G(Xi_mu(jj),Xi_na(ii),T));
    UU=Phi(Xi_na(ii),T,u0,up);
    
    zz3_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi2(ii,:) ...
        +1/2*DDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).^2);
    zz3=dT*real(ifft(zz1.*zz3_na));
    f3_na=f3_na+Gna(ii)*Rm/lambda*zz3;
end;

f3_k=zeros(size(T));

for pp=1:HotSpotNum_k
    zz1=fft(G(Xi_mu(jj),Xi_k(pp),T));
    UU=Phi(Xi_k(pp),T,u0,up);

    zz33_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi2(ii+pp,:) ...
        +1/2*DDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).^2);
    zz3_k=dT*real(ifft(zz1.*zz33_kk));
    f3_k=f3_k+Gk(pp)*Rm/lambda*zz3_k;
  
end;

f3_ka=zeros(size(T));

for qq=1:HotSpotNum_ka
    zz1=fft(G(Xi_mu(jj),Xi_ka(qq),T));
    UU=Phi(Xi_ka(qq),T,u0,up);
    
    zz33_ka=fft(DFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi2(ii+pp+qq,:) ...
        +1/2*DDFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:)).*Phi1(ii+pp+qq,:).^2);
    zz3_ka=dT*real(ifft(zz1.*zz33_ka));
    f3_ka=f3_ka+Gka(qq)*Rm/lambda*zz3_ka;
end;

f3_kh=zeros(size(T));

for rr=1:HotSpotNum_kh
    zz1=fft(G(Xi_mu(jj),Xi_kh(rr),T));
    UU=Phi(Xi_kh(rr),T,u0,up);

    zz33_kh=fft(DFkh(UU+Er/up,up,Phi_kh,Omega,nn(rr,:),dnn_dv(rr,:)).*Phi2(ii+pp+qq+rr,:) ...
        +1/2*DDFkh(UU+Er/up,up,Phi_kh,Omega,nn(rr,:),dnn_dv(rr,:),d2nn_dv2(rr,:)).*Phi1(ii+pp+qq+rr,:).^2);
    zz3_kh=dT*real(ifft(zz1.*zz33_kh));
    f3_kh=f3_kh+Gkh(rr)*Rm/lambda*zz3_kh;
  
end;

f3_hva=zeros(size(T));

for ss=1:HotSpotNum_hva
    zz1=fft(G(Xi_mu(jj),Xi_hva(ss),T));
    UU=Phi(Xi_hva(ss),T,u0,up);

    zz33_hva=fft(DFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi2(ii+pp+qq+rr+ss,:) ...
        +1/2*DDFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).^2);
    zz3_hva=dT*real(ifft(zz1.*zz33_hva));
    f3_hva=f3_hva+Ghva(ss)*Rm/lambda*zz3_hva;
  
end;

f3_kca=zeros(size(T));

for tt=1:HotSpotNum_kca
    zz1=fft(G(Xi_mu(jj),Xi_kca(tt),T));
    UU=Phi(Xi_kca(tt),T,u0,up);

    zz33_kca=fft(DFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi2(ii+pp+qq+rr+ss+tt,:) ...
        +1/2*DDFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).^2);
    zz3_kca=dT*real(ifft(zz1.*zz33_kca));
    f3_kca=f3_kca+Gkca(tt)*Rm/lambda*zz3_kca;
  
end;
Phi3(jj,:)=f3_na+f3_k+f3_ka+f3_kh+f3_hva+f3_kca;
end;

for jj=1:HotSpotNum_na+HotSpotNum_k+HotSpotNum_ka+HotSpotNum_kh+HotSpotNum_hva+HotSpotNum_kca

f4_na=zeros(size(T));

for ii=1:HotSpotNum_na
    zz1=fft(G(Xi_mu(jj),Xi_na(ii),T));
    UU=Phi(Xi_na(ii),T,u0,up);
    
    zz4_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi3(ii,:)...
        +DDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).*Phi2(ii,:)...
        +1/6*DDDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:),d3mm_dv3(ii,:),d3hh_dv3(ii,:)).*Phi1(ii,:).^3);
    zz4=dT*real(ifft(zz1.*zz4_na));
    f4_na=f4_na+Gna(ii)*Rm/lambda*zz4;
end;

f4_k=zeros(size(T));

for pp=1:HotSpotNum_k
    zz1=fft(G(Xi_mu(jj),Xi_k(pp),T));
    UU=Phi(Xi_k(pp),T,u0,up);

    zz4_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi3(ii+pp,:) ...
        +DDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).*Phi2(ii+pp,:) ...
        +1/6*DDDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:),d3nn_dv3(pp,:)).*Phi1(ii+pp,:).^3);
    zz4_k=dT*real(ifft(zz1.*zz4_kk));
    f4_k=f4_k+Gk(pp)*Rm/lambda*zz4_k;
end;

f4_ka=zeros(size(T));

for qq=1:HotSpotNum_ka
    zz1=fft(G(Xi_mu(jj),Xi_ka(qq),T));
    UU=Phi(Xi_ka(qq),T,u0,up);
    
    zz44_ka=fft(DFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi3(ii+pp+qq,:)...
        +DDFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:)).*Phi1(ii+pp+qq,:).*Phi2(ii+pp+qq,:)...
        +1/6*DDDFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:),d3mm_ka_dv3(qq,:),d3hh_ka_dv3(qq,:)).*Phi1(ii+pp+qq,:).^3);
    zz4_ka=dT*real(ifft(zz1.*zz44_ka));
    f4_ka=f4_ka+Gka(qq)*Rm/lambda*zz4_ka;
end;

f4_kh=zeros(size(T));

for rr=1:HotSpotNum_kh
    zz1=fft(G(Xi_mu(jj),Xi_kh(rr),T));
    UU=Phi(Xi_kh(rr),T,u0,up);

    zz44_kh=fft(DFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi3(ii+pp+qq+rr,:) ...
        +DDFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:)).*Phi1(ii+pp+qq+rr,:).*Phi2(ii+pp+qq+rr,:) ...
        +1/6*DDDFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:),d3mm_kh_dv3(rr,:)).*Phi1(ii+pp+qq+rr,:).^3);
    zz4_kh=dT*real(ifft(zz1.*zz44_kh));
    f4_kh=f4_kh+Gkh(rr)*Rm/lambda*zz4_kh;
end;

f4_hva=zeros(size(T));

for ss=1:HotSpotNum_hva
    zz1=fft(G(Xi_mu(jj),Xi_kh(ss),T));
    UU=Phi(Xi_kh(ss),T,u0,up);

    zz44_hva=fft(DFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi3(ii+pp+qq+rr+ss,:) ...
        +DDFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).*Phi2(ii+pp+qq+rr+ss,:) ...
        +1/6*DDDFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:),d3mm_hva_dv3(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).^3);
    zz4_hva=dT*real(ifft(zz1.*zz44_hva));
    f4_hva=f4_hva+Ghva(ss)*Rm/lambda*zz4_hva;
end;

f4_kca=zeros(size(T));

for tt=1:HotSpotNum_kca
    zz1=fft(G(Xi_mu(jj),Xi_kca(tt),T));
    UU=Phi(Xi_kca(tt),T,u0,up);

    zz4_kca=fft(DFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi3(ii+pp+qq+rr+ss+tt,:) ...
        +DDFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).*Phi2(ii+pp+qq+rr+ss+tt,:) ...
        +1/6*DDDFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:),d3mm_kca_dv3(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).^3);
    zz4_kca=dT*real(ifft(zz1.*zz4_kca));
    f4_kca=f4_kca+Gkca(tt)*Rm/lambda*zz4_kca;
end;

Phi4(jj,:)=f4_na+f4_k+f4_ka+f4_kh+f4_hva+f4_kca;
end;

Xpos=250e-4/lambda;
%Xpos=150e-4/lambda;
%Xpos=Xi_k(pp);

f1_na=zeros(size(T));
f2_na=zeros(size(T));
f3_na=zeros(size(T));
f4_na=zeros(size(T));

f1_k=zeros(size(T));
f2_k=zeros(size(T));
f3_k=zeros(size(T));
f4_k=zeros(size(T));

f1_ka=zeros(size(T));
f2_ka=zeros(size(T));
f3_ka=zeros(size(T));
f4_ka=zeros(size(T));

f1_kh=zeros(size(T));
f2_kh=zeros(size(T));
f3_kh=zeros(size(T));
f4_kh=zeros(size(T));

f1_hva=zeros(size(T));
f2_hva=zeros(size(T));
f3_hva=zeros(size(T));
f4_hva=zeros(size(T));

f1_kca=zeros(size(T));
f2_kca=zeros(size(T));
f3_kca=zeros(size(T));
f4_kca=zeros(size(T));

for ii=1:HotSpotNum_na
    zz1=fft(G(Xpos,Xi_na(ii),T));
    UU=Phi(Xi_na(ii),T,u0,up);
    
    zz1_na=fft(Fna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:)));
    zz_na=dT*real(ifft(zz1.*zz1_na));
    f1_na=f1_na+Gna(ii)*Rm/lambda*zz_na;

    zz2_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi1(ii,:));
    zz2=dT*real(ifft(zz1.*zz2_na));
    f2_na=f2_na+Gna(ii)*Rm/lambda*zz2;

    zz3_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi2(ii,:) ...
        +1/2*DDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).^2);
    zz3=dT*real(ifft(zz1.*zz3_na));
    f3_na=f3_na+Gna(ii)*Rm/lambda*zz3;

    zz4_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi3(ii,:)...
        +DDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).*Phi2(ii,:)...
        +1/6*DDDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:),d3mm_dv3(ii,:),d3hh_dv3(ii,:)).*Phi1(ii,:).^3);
    zz4=dT*real(ifft(zz1.*zz4_na));
    f4_na=f4_na+Gna(ii)*Rm/lambda*zz4;
end;


for pp=1:HotSpotNum_k
    zz1=fft(G(Xpos,Xi_k(pp),T));
    UU=Phi(Xi_k(pp),T,u0,up);
    
    zz1_k=fft(Fk(UU+Er/up,up,Phi_k,Omega,nn(pp,:)));
    zz_k=dT*real(ifft(zz1.*zz1_k));
    f1_k=f1_k+Gk(pp)*(Rm/lambda)*zz_k;
    
    zz2_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi1(ii+pp,:));
    zz2_k=dT*real(ifft(zz1.*zz2_kk));
    f2_k=f2_k+Gk(pp)*Rm/lambda*zz2_k;
    
    zz3_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi2(ii+pp,:) ...
        +1/2*DDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).^2);
    zz3_k=dT*real(ifft(zz1.*zz3_kk));
    f3_k=f3_k+Gk(pp)*Rm/lambda*zz3_k;
  
    zz4_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi3(ii+pp,:)...
        +DDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).*Phi2(ii+pp,:)...
        +1/6*DDDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:),d3nn_dv3(pp,:)).*Phi1(ii+pp,:).^3);
    zz4_k=dT*real(ifft(zz1.*zz4_kk));
    f4_k=f4_k+Gk(pp)*Rm/lambda*zz4_k;
    
end;

for qq=1:HotSpotNum_ka
    zz1=fft(G(Xpos,Xi_ka(qq),T));
    UU=Phi(Xi_ka(qq),T,u0,up);
    
    zz1_ka=fft(Fka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:)));
    zz_ka=dT*real(ifft(zz1.*zz1_ka));
    f1_ka=f1_ka+Gka(qq)*Rm/lambda*zz_ka;

    zz2_ka=fft(DFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi1(ii+pp+qq,:));
    zz2=dT*real(ifft(zz1.*zz2_ka));
    f2_ka=f2_ka+Gka(qq)*Rm/lambda*zz2;

    zz3_ka=fft(DFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi2(ii+pp+qq,:) ...
        +1/2*DDFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:)).*Phi1(ii+pp+qq,:).^2);
    zz3=dT*real(ifft(zz1.*zz3_ka));
    f3_ka=f3_ka+Gka(qq)*Rm/lambda*zz3;

    zz4_ka=fft(DFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi3(ii+pp+qq,:)...
        +DDFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:)).*Phi1(ii+pp+qq,:).*Phi2(ii+pp+qq,:)...
        +1/6*DDDFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:),d3mm_ka_dv3(qq,:),d3hh_ka_dv3(qq,:)).*Phi1(ii+pp+qq,:).^3);
    zz4=dT*real(ifft(zz1.*zz4_ka));
    f4_ka=f4_ka+Gka(qq)*Rm/lambda*zz4;
end;


for rr=1:HotSpotNum_kh
    zz1=fft(G(Xpos,Xi_k(rr),T));
    UU=Phi(Xi_k(rr),T,u0,up);
    
    zz1_kh=fft(Fkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:)));
    zz_kh=dT*real(ifft(zz1.*zz1_kh));
    f1_kh=f1_kh+Gkh(rr)*(Rm/lambda)*zz_kh;
    
    zz22_kh=fft(DFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi1(ii+pp+qq+rr,:));
    zz2_kh=dT*real(ifft(zz1.*zz22_kh));
    f2_kh=f2_kh+Gkh(rr)*Rm/lambda*zz2_kh;
    
    zz33_kh=fft(DFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi2(ii+pp+qq+rr,:) ...
        +1/2*DDFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:)).*Phi1(ii+pp+qq+rr,:).^2);
    zz3_kh=dT*real(ifft(zz1.*zz33_kh));
    f3_kh=f3_kh+Gkh(rr)*Rm/lambda*zz3_kh;
  
    zz44_kh=fft(DFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi3(ii+pp+qq+rr,:)...
        +DDFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:)).*Phi1(ii+pp+qq+rr,:).*Phi2(ii+pp+qq+rr,:)...
        +1/6*DDDFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:),d3mm_kh_dv3(rr,:)).*Phi1(ii+pp+qq+rr,:).^3);
    zz4_kh=dT*real(ifft(zz1.*zz44_kh));
    f4_kh=f4_kh+Gkh(rr)*Rm/lambda*zz4_kh;
    
end;

for ss=1:HotSpotNum_hva
    zz1=fft(G(Xpos,Xi_hva(ss),T));
    UU=Phi(Xi_hva(ss),T,u0,up);
    
    zz1_hva=fft(Fca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:)));
    zz_hva=dT*real(ifft(zz1.*zz1_hva));
    f1_hva=f1_hva+Ghva(ss)*Rm/lambda*zz_hva;
 
    zz22_hva=fft(DFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi1(ii+pp+qq+rr+ss,:));
    zz2_hva=dT*real(ifft(zz1.*zz22_hva));
    f2_hva=f2_hva+Ghva(ss)*(Rm/lambda)*zz2_hva;
 
    zz33_hva=fft(DFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi2(ii+pp+qq+rr+ss,:) ...
        +1/2*DDFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).^2);
    zz3_hva=dT*real(ifft(zz1.*zz33_hva));
    f3_hva=f3_hva+Ghva(ss)*Rm/lambda*zz3_hva;
   
    zz44_hva=fft(DFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi3(ii+pp+qq+rr+ss,:) ...
        +DDFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).*Phi2(ii+pp+qq+rr+ss,:) ...
        +1/6*DDDFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:),d3mm_hva_dv3(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).^3);
    zz4_hva=dT*real(ifft(zz1.*zz44_hva));
    f4_hva=f4_hva+Ghva(ss)*Rm/lambda*zz4_hva;

end;

for tt=1:HotSpotNum_kca
    zz1=fft(G(Xi_mu(jj),Xi_kca(tt),T));
    UU=Phi(Xi_kca(tt),T,u0,up);

    zz1_kca=fft(Fkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:)));
    zz_kca=dT*real(ifft(zz1.*zz1_kca));
    f1_kca=f1_kca+Gkca(tt)*(Rm/lambda)*zz_kca;
    
    zz22_kca=fft(DFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:));
    zz2_kca=dT*real(ifft(zz1.*zz22_kca));
    f2_kca=f2_kca+Gkca(tt)*(Rm/lambda)*zz2_kca;
    
     zz33_kca=fft(DFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi2(ii+pp+qq+rr+ss+tt,:) ...
        +1/2*DDFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).^2);
    zz3_kca=dT*real(ifft(zz1.*zz33_kca));
    f3_kca=f3_kca+Gkca(tt)*Rm/lambda*zz3_kca;

    
    zz4_kca=fft(DFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi3(ii+pp+qq+rr+ss+tt,:) ...
        +DDFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).*Phi2(ii+pp+qq+rr+ss+tt,:) ...
        +1/6*DDDFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:),d3mm_kca_dv3(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).^3);
    zz4_kca=dT*real(ifft(zz1.*zz4_kca));
    f4_kca=f4_kca+Gkca(tt)*Rm/lambda*zz4_kca;
    
end;

plot(T,f1_na,T,f2_na,'r',T,f3_na,'g',T,f4_na,'c');
figure;
plot(T,f1_k,T,f2_k,'c',T,f3_k,'g',T,f4_k,'r');
figure;
plot(T,up*(Phi(Xpos,T,u0,up)+f1_na+f2_na+f3_na+f4_na),'g',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
plot(T,up*(Phi(Xpos,T,u0,up)+f1_k+f2_k+f3_k+f4_k),'b',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
plot(T,up*(Phi(Xpos,T,u0,up)+f1_ka+f2_ka+f3_ka+f4_ka),'g',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
plot(T,up*(Phi(Xpos,T,u0,up)+f1_kh+f2_kh+f3_kh+f4_kh),'b',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
plot(T,up*(f1_na+f2_na+f3_na+f4_na+f1_k+f2_k+f3_k+f4_k),'b',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
epsilon=0.035;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon^4*f4_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k+epsilon^4*f4_k),'b',T,up*(Phi(Xpos,T,u0,up)+f1_na),'y',T,up*f1_na,'c',T,up*f1_k,'g',T,up*Phi(Xpos,T,u0,up),'r');grid;
figure;
epsilon=0.035;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon*f1_k+epsilon*f1_ka+epsilon*f1_kh+epsilon*f1_hva+epsilon*f1_kca),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;
figure;
epsilon=0.035;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon*f1_k+epsilon^2*f2_k+epsilon*f1_ka+epsilon^2*f2_ka+epsilon*f1_kh+epsilon^2*f2_kh+epsilon*f1_hva+epsilon^2*f2_hva+epsilon*f1_kca+epsilon^2*f2_kca),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;
figure;
epsilon=0.035;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k+epsilon*f1_ka+epsilon^2*f2_ka+epsilon^3*f3_ka+epsilon*f1_kh+epsilon^2*f2_kh+epsilon^3*f3_kh+epsilon*f1_hva+epsilon^2*f2_hva+epsilon^3*f3_hva+epsilon*f1_kca+epsilon^2*f2_kca+epsilon^3*f3_kca),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;
figure;
epsilon=0.035;
plot(T,up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon^4*f4_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k+epsilon^4*f4_k+epsilon*f1_ka+epsilon^2*f2_ka+epsilon^3*f3_ka+epsilon^4*f4_ka+epsilon*f1_kh+epsilon^2*f2_kh+epsilon^3*f3_kh+epsilon^4*f4_kh+epsilon*f1_hva+epsilon^2*f2_hva+epsilon^3*f3_hva+epsilon^4*f4_hva+epsilon*f1_kca+epsilon^2*f2_kca+epsilon^3*f3_kca+epsilon^4*f4_kca),'b',T,up*(Phi(Xpos,T,u0,up)),'r');grid;

%Calcium Concentration

Dca=0.223; %um^2/msec
Dm=0.13; %um^2/msec
Pm=0.2; %um/msec
beta=10;

lambda_Ca=sqrt(diam*1e4*(Dca+beta*Dm)/(4*Pm))*1e-4; %units of cm
tau_Ca=diam*1e4*(1+beta)/Pm; %units of msec
Tca=T*tau/tau_Ca;
Ca_ref=2; % mMolar


for jj=1:HotSpotNum_hva
Xpos=Xi_hva(jj);

f1_na=zeros(size(T));
f2_na=zeros(size(T));
f3_na=zeros(size(T));
f4_na=zeros(size(T));

f1_k=zeros(size(T));
f2_k=zeros(size(T));
f3_k=zeros(size(T));
f4_k=zeros(size(T));

f1_ka=zeros(size(T));
f2_ka=zeros(size(T));
f3_ka=zeros(size(T));
f4_ka=zeros(size(T));

f1_kh=zeros(size(T));
f2_kh=zeros(size(T));
f3_kh=zeros(size(T));
f4_kh=zeros(size(T));

f1_hva=zeros(size(T));
f2_hva=zeros(size(T));
f3_hva=zeros(size(T));
f4_hva=zeros(size(T));

f1_kca=zeros(size(T));
f2_kca=zeros(size(T));
f3_kca=zeros(size(T));
f4_kca=zeros(size(T));

for ii=1:HotSpotNum_na
    zz1=fft(G(Xpos,Xi_na(ii),T));
    UU=Phi(Xi_na(ii),T,u0,up);
    
    zz1_na=fft(Fna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:)));
    zz_na=dT*real(ifft(zz1.*zz1_na));
    f1_na=f1_na+Gna(ii)*Rm/lambda*zz_na;

    zz2_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi1(ii,:));
    zz2=dT*real(ifft(zz1.*zz2_na));
    f2_na=f2_na+Gna(ii)*Rm/lambda*zz2;

    zz3_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi2(ii,:) ...
        +1/2*DDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).^2);
    zz3=dT*real(ifft(zz1.*zz3_na));
    f3_na=f3_na+Gna(ii)*Rm/lambda*zz3;

    zz4_na=fft(DFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:)).*Phi3(ii,:)...
        +DDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:)).*Phi1(ii,:).*Phi2(ii,:)...
        +1/6*DDDFna(UU+Er/up,up,Phi_na,Omega,mm(ii,:),hh(ii,:),dmm_dv(ii,:),dhh_dv(ii,:),d2mm_dv2(ii,:),d2hh_dv2(ii,:),d3mm_dv3(ii,:),d3hh_dv3(ii,:)).*Phi1(ii,:).^3);
    zz4=dT*real(ifft(zz1.*zz4_na));
    f4_na=f4_na+Gna(ii)*Rm/lambda*zz4;
end;


for pp=1:HotSpotNum_k
    zz1=fft(G(Xpos,Xi_k(pp),T));
    UU=Phi(Xi_k(pp),T,u0,up);
    
    zz1_k=fft(Fk(UU+Er/up,up,Phi_k,Omega,nn(pp,:)));
    zz_k=dT*real(ifft(zz1.*zz1_k));
    f1_k=f1_k+Gk(pp)*(Rm/lambda)*zz_k;
    
    zz2_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi1(ii+pp,:));
    zz2_k=dT*real(ifft(zz1.*zz2_kk));
    f2_k=f2_k+Gk(pp)*Rm/lambda*zz2_k;
    
    zz3_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi2(ii+pp,:) ...
        +1/2*DDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).^2);
    zz3_k=dT*real(ifft(zz1.*zz3_kk));
    f3_k=f3_k+Gk(pp)*Rm/lambda*zz3_k;
  
    zz4_kk=fft(DFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:)).*Phi3(ii+pp,:)...
        +DDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:)).*Phi1(ii+pp,:).*Phi2(ii+pp,:)...
        +1/6*DDDFk(UU+Er/up,up,Phi_k,Omega,nn(pp,:),dnn_dv(pp,:),d2nn_dv2(pp,:),d3nn_dv3(pp,:)).*Phi1(ii+pp,:).^3);
    zz4_k=dT*real(ifft(zz1.*zz4_kk));
    f4_k=f4_k+Gk(pp)*Rm/lambda*zz4_k;
    
end;

for qq=1:HotSpotNum_ka
    zz1=fft(G(Xpos,Xi_ka(qq),T));
    UU=Phi(Xi_ka(qq),T,u0,up);
    
    zz1_ka=fft(Fka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:)));
    zz_ka=dT*real(ifft(zz1.*zz1_ka));
    f1_ka=f1_ka+Gka(qq)*Rm/lambda*zz_ka;

    zz2_ka=fft(DFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi1(ii+pp+qq,:));
    zz2=dT*real(ifft(zz1.*zz2_ka));
    f2_ka=f2_ka+Gka(qq)*Rm/lambda*zz2;

    zz3_ka=fft(DFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi2(ii+pp+qq,:) ...
        +1/2*DDFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:)).*Phi1(ii+pp+qq,:).^2);
    zz3=dT*real(ifft(zz1.*zz3_ka));
    f3_ka=f3_ka+Gka(qq)*Rm/lambda*zz3;

    zz4_ka=fft(DFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:)).*Phi3(ii+pp+qq,:)...
        +DDFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:)).*Phi1(ii+pp+qq,:).*Phi2(ii+pp+qq,:)...
        +1/6*DDDFka(UU+Er/up,up,Phi_ka,Omega,mm_ka(qq,:),hh_ka(qq,:),dmm_ka_dv(qq,:),dhh_ka_dv(qq,:),d2mm_ka_dv2(qq,:),d2hh_ka_dv2(qq,:),d3mm_ka_dv3(qq,:),d3hh_ka_dv3(qq,:)).*Phi1(ii+pp+qq,:).^3);
    zz4=dT*real(ifft(zz1.*zz4_ka));
    f4_ka=f4_ka+Gka(qq)*Rm/lambda*zz4;
end;


for rr=1:HotSpotNum_kh
    zz1=fft(G(Xpos,Xi_k(rr),T));
    UU=Phi(Xi_k(rr),T,u0,up);
    
    zz1_kh=fft(Fkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:)));
    zz_kh=dT*real(ifft(zz1.*zz1_kh));
    f1_kh=f1_kh+Gkh(rr)*(Rm/lambda)*zz_kh;
    
    zz22_kh=fft(DFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi1(ii+pp+qq+rr,:));
    zz2_kh=dT*real(ifft(zz1.*zz22_kh));
    f2_kh=f2_kh+Gkh(rr)*Rm/lambda*zz2_kh;
    
    zz33_kh=fft(DFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi2(ii+pp+qq+rr,:) ...
        +1/2*DDFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:)).*Phi1(ii+pp+qq+rr,:).^2);
    zz3_kh=dT*real(ifft(zz1.*zz33_kh));
    f3_kh=f3_kh+Gkh(rr)*Rm/lambda*zz3_kh;
  
    zz44_kh=fft(DFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:)).*Phi3(ii+pp+qq+rr,:)...
        +DDFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:)).*Phi1(ii+pp+qq+rr,:).*Phi2(ii+pp+qq+rr,:)...
        +1/6*DDDFkh(UU+Er/up,up,Phi_kh,Omega,mm_kh(rr,:),dmm_kh_dv(rr,:),d2mm_kh_dv2(rr,:),d3mm_kh_dv3(rr,:)).*Phi1(ii+pp+qq+rr,:).^3);
    zz4_kh=dT*real(ifft(zz1.*zz44_kh));
    f4_kh=f4_kh+Gkh(rr)*Rm/lambda*zz4_kh;
    
end;

for ss=1:HotSpotNum_hva
    zz1=fft(G(Xpos,Xi_hva(ss),T));
    UU=Phi(Xi_hva(ss),T,u0,up);
    
    zz1_hva=fft(Fca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:)));
    zz_hva=dT*real(ifft(zz1.*zz1_hva));
    f1_hva=f1_hva+Ghva(ss)*Rm/lambda*zz_hva;
 
    zz22_hva=fft(DFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi1(ii+pp+qq+rr+ss,:));
    zz2_hva=dT*real(ifft(zz1.*zz22_hva));
    f2_hva=f2_hva+Ghva(ss)*(Rm/lambda)*zz2_hva;
 
    zz33_hva=fft(DFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi2(ii+pp+qq+rr+ss,:) ...
        +1/2*DDFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).^2);
    zz3_hva=dT*real(ifft(zz1.*zz33_hva));
    f3_hva=f3_hva+Ghva(ss)*Rm/lambda*zz3_hva;
   
    zz44_hva=fft(DFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:)).*Phi3(ii+pp+qq+rr+ss,:) ...
        +DDFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).*Phi2(ii+pp+qq+rr+ss,:) ...
        +1/6*DDDFca(UU+Er/up,up,Phi_ca,Omega,mm_hva(ss,:),dmm_hva_dv(ss,:),d2mm_hva_dv2(ss,:),d3mm_hva_dv3(ss,:)).*Phi1(ii+pp+qq+rr+ss,:).^3);
    zz4_hva=dT*real(ifft(zz1.*zz44_hva));
    f4_hva=f4_hva+Ghva(ss)*Rm/lambda*zz4_hva;

end;

for tt=1:HotSpotNum_kca
    zz1=fft(G(Xi_mu(jj),Xi_kca(tt),T));
    UU=Phi(Xi_kca(tt),T,u0,up);

    zz1_kca=fft(Fkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:)));
    zz_kca=dT*real(ifft(zz1.*zz1_kca));
    f1_kca=f1_kca+Gkca(tt)*(Rm/lambda)*zz_kca;
    
    zz22_kca=fft(DFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:));
    zz2_kca=dT*real(ifft(zz1.*zz22_kca));
    f2_kca=f2_kca+Gkca(tt)*(Rm/lambda)*zz2_kca;
    
     zz33_kca=fft(DFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi2(ii+pp+qq+rr+ss+tt,:) ...
        +1/2*DDFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).^2);
    zz3_kca=dT*real(ifft(zz1.*zz33_kca));
    f3_kca=f3_kca+Gkca(tt)*Rm/lambda*zz3_kca;

    
    zz4_kca=fft(DFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:)).*Phi3(ii+pp+qq+rr+ss+tt,:) ...
        +DDFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).*Phi2(ii+pp+qq+rr+ss+tt,:) ...
        +1/6*DDDFkca(UU+Er/up,up,Phi_kca,Omega,mm_kca(tt,:),dmm_kca_dv(tt,:),d2mm_kca_dv2(tt,:),d3mm_kca_dv3(tt,:)).*Phi1(ii+pp+qq+rr+ss+tt,:).^3);
    zz4_kca=dT*real(ifft(zz1.*zz4_kca));
    f4_kca=f4_kca+Gkca(tt)*Rm/lambda*zz4_kca;
    
end;

mem_pot=up*(Phi(Xpos,T,u0,up)+epsilon*f1_na+epsilon^2*f2_na+epsilon^3*f3_na+epsilon^4*f4_na+epsilon*f1_k+epsilon^2*f2_k+epsilon^3*f3_k+epsilon^4*f4_k+epsilon*f1_ka+epsilon^2*f2_ka+epsilon^3*f3_ka+epsilon^4*f4_ka+epsilon*f1_kh+epsilon^2*f2_kh+epsilon^3*f3_kh+epsilon^4*f4_kh+epsilon*f1_hva+epsilon^2*f2_hva+epsilon^3*f3_hva+epsilon^4*f4_hva+epsilon*f1_kca+epsilon^2*f2_kca+epsilon^3*f3_kca+epsilon^4*f4_kca);

Phi_VCa(jj,:)=mem_pot;

    y=Q10*alpha_hva_Ca_m(mem_pot,Er,a1_hva,b1_hva,c1_hva,u0,up);
    y2=Q10*beta_hva_Ca_m(mem_pot,Er,a2_hva,b2_hva,c2_hva,u0,up);
    yy=Q10*dalpha_hva_Ca_m(mem_pot,Er,a1_hva,b1_hva,c1_hva,u0,up);
    yy2=Q10*dbeta_hva_Ca_m(mem_pot,Er,a2_hva,b2_hva,c2_hva,u0,up);
    yyy=Q10*d2alpha_hva_Ca_m(mem_pot,Er,a1_hva,b1_hva,c1_hva,u0,up);
    yyy2=Q10*d2beta_hva_Ca_m(mem_pot,Er,a2_hva,b2_hva,c2_hva,u0,up);
    yyyy=Q10*d3alpha_hva_Ca_m(mem_pot,Er,a1_hva,b1_hva,c1_hva,u0,up);
    yyyy2=Q10*d3beta_hva_Ca_m(mem_pot,Er,a2_hva,b2_hva,c2_hva,u0,up);

    mmu_hva(1)=y(1)/(y(1)+y2(1));
    vv(1)=(yy(1)-(yy(1)+yy2(1))*mmu_hva(1))/(y(1)+y2(1));
    vv2(1)=(yyy(1)-2*vv(1)*(yy(1)+yy2(1))-mmu_hva(1)*(yyy(1)+yyy2(1)))/(y(1)+y2(1));
    vv3(1)=(yyyy(1)-3*(yy(1)+yy2(1))*vv2(1)-3*(yyy(1)+yyy2(1))*vv(1)-(yyyy(1)+yyyy2(1))*mmu_hva(1))/(y(1)+y2(1));
    
    mm_hva_trans=zeros(size(T));
    mm_hva_trans(1)=mmu_hva(1);
    dmm_hva_dV_trans=zeros(size(t));
    dmm_hva_dV_trans(1)=vv(1);
    d2mm_hva_dV2_trans=zeros(size(t));
    d2mm_hva_dV2_trans(1)=vv2(1);
    d3mm_hva_dV3_trans=zeros(size(t));
    d3mm_hva_dV3_trans(1)=vv3(1);
    
    for i=2:length(T)
        mm_hva_trans(i)=(mm_hva_trans(i-1)+dT/2*tau*(y(i-1)+y(i))-dT/2*tau*(y(i-1)+y2(i-1))*mm_hva_trans(i-1))/(1+dT/2*tau*(y(i)+y2(i)));
       
        dmm_hva_dV_trans(i)=(dmm_hva_dV_trans(i-1)+dT/2*tau*(yy(i-1)+yy(i))-dT/2*tau*(yy(i-1)+yy2(i-1))*mm_hva_trans(i-1)...
       -dT/2*tau*(yy(i)+yy2(i))*mm_hva_trans(i)-dT/2*tau*(y(i)+y2(i)).*dmm_hva_dV_trans(i-1))/...
       (1+dT/2*tau*(y(i)+y2(i)));
   
        d2mm_hva_dV2_trans(i)=(d2mm_hva_dV2_trans(i-1)+dT/2*tau*(yyy(i)+yyy(i-1))-dT*tau*(yy(i)+yy2(i)).*dmm_hva_dV_trans(i)...
            -dT*tau*(yy(i-1)+yy2(i-1))*dmm_hva_dV_trans(i-1)-dT/2*tau*(yyy(i)+yyy2(i)).*mm_hva_trans(i)...
            -dT/2*tau*(yyy(i-1)+yyy2(i-1)).*mm_hva_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d2mm_hva_dV2_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));
        
        d3mm_hva_dV3_trans(i)=(d3mm_hva_dV3_trans(i-1)+dT/2*tau*(yyyy(i)+yyyy(i-1))-3*dT/2*tau*(yyy(i)+yyy2(i)).*dmm_hva_dV_trans(i)...
            -3*dT/2*tau*(yyy(i-1)+yyy2(i-1)).*dmm_hva_dV_trans(i-1)-3*dT/2*tau*(yy(i)+yy2(i)).*d2mm_hva_dV2_trans(i)...
            -3*dT/2*tau*(yy(i-1)+yy2(i-1)).*d2mm_hva_dV2_trans(i-1)-dT/2*tau*(yyyy(i)+yyyy2(i)).*mm_hva_trans(i)...
            -dT/2*tau*(yyyy(i-1)+yyyy2(i-1)).*mm_hva_trans(i-1)-dT/2*tau*(y(i-1)+y2(i-1)).*d3mm_hva_dV3_trans(i-1))./(1+dT/2*tau*(y(i)+y2(i)));

   end;
   
    mm_hva_Ca(jj,:)=mm_hva_trans;
    dmm_hva_Ca_dv(jj,:)=dmm_hva_dV_trans;
    d2mm_hva_Ca_dv2(jj,:)=d2mm_hva_dV2_trans;
    d3mm_hva_Ca_dv3(jj,:)=d3mm_hva_dV3_trans;
%     hh_hva(ii,:)=hh_trans;
%     dhh_hva_dv(ii,:)=dhh_dV_trans;
%     d2hh_hva_dv2(ii,:)=d2hh_dV2_trans;
%     d3hh_hva_dv3(ii,:)=d3hh_dV3_trans;

Ica(jj,:)=up*Ghva(jj)*Fca(mem_pot+Er/up,up,Phi_ca,Omega,mm_hva_Ca(jj,:));
    
end;

Xpos_Ca=Xi_hva(1)*lambda/lambda_Ca;
% Xpos_Ca=250e-4/lambda_Ca; 
Phi_Ca_conc=zeros(size(T));

for jj=1:HotSpotNum_hva
    zz1=fft(GGca(Xpos_Ca,Xi_hva(jj)*lambda/lambda_Ca,Tca));
    UU=Phi_VCa(jj,:);
    
    zz1_Ica=fft(Ica(jj,:));
    zz_Ica=dT*real(ifft(zz1.*zz1_Ica));
    Phi_Ca_conc=Phi_Ca_conc+1/(2*lambda_Ca*F*Pm*(1e-4)*Ca_ref)*zz_Ica;
end;

figure;
plot(t,Phi_Ca_conc*Ca_ref*1e3)
figure;
plot(t,up*Phi(Xpos_Ca*lambda_Ca/lambda,T,u0,up),'r');
