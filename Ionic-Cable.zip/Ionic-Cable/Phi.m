function [ret] = Phi(x,t,u0,up)

% x and t are dimensionless

ret=zeros(size(t));
%z=linspace(-1,1,length(t));

idx=find(t>0);

 if (isempty(nonzeros(idx))==0) 
    ret(idx) = (50.0*u0/(up*sqrt(pi))).*(4.*x.*sqrt(t(idx)).*exp(-x.^2./(4*t(idx))).*(0.75*exp(-2*t(idx))-1.5*exp(-4*t(idx))-...
        0.05*exp(-1.2*t(idx)))+sqrt(pi)*erfc(x./(2*sqrt(t(idx)))).*((3-1.5*x.^2).*exp(-2*t(idx))-(2-3*x.^2).*exp(-4*t(idx))-...
        (1-0.1*x.^2).*exp(-1.2*t(idx))));
% The above is incorrect

%     ret(idx) = (50.0*u0/(up*sqrt(pi))).*(4.*x.*sqrt(t(idx)).*exp(-x.^2./(4*t(idx))).*(21.75*exp(-2*t(idx)*15)-29.5*exp(-4*t(idx)*15)-...
%         4.25*exp(-1.2*t(idx)*15))+sqrt(pi)*erfc(x./(2*sqrt(t(idx)))).*((3-43.5*x.^2).*exp(-2*t(idx)*15)-(2-59*x.^2).*exp(-4*t(idx)*15)-...
%         (1-8.5*x.^2).*exp(-1.2*t(idx)*15)));
    
    %ret(idx)=z(idx);
end;

% ret(ceil(length(t)/3):ceil(length(t)/2))=40/up*ones(size(t(ceil(length(t)/3):ceil(length(t)/2))));
%  end;
ret = ret-0/up;

%ret=linspace(-150,150,1500)/up;