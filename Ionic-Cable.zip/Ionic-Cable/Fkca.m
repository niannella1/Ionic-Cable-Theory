function [ret] = Fkca(UU,Up,Ukca,Omega,mm)

% Omega - factor scaling U_{peak}
% Ukca - refers to Phi_{kca} note that Phi_{kca}U_{peak} 
% is the potassium reversal or equilibrium potential
% Up - refers to U_{peak}
% UU - refers to Phi_0(x,t)

idx2=find(abs(UU)>=1e-6);
idx=find(abs(UU)<1e-6);

ret = zeros(size(UU));

if (isempty(nonzeros(idx2))==0)

     ret(idx2) = -(exp(Omega*Up*(UU(idx2)-Ukca))-1).*mm(idx2).*UU(idx2)./(exp(Omega*Up*UU(idx2))-1);

else

     ret(idx) = -(exp(Omega*Up*(UU(idx)-Ukca))-1).*mm(idx)/(Up*Omega);

end;